import require$$0 from 'node:net';
import require$$1$1 from 'node:tls';
import require$$2$1 from 'node:events';
import require$$1 from 'node:stream';
import require$$2 from 'node:util';
import os from 'os';
import fs from 'fs';
import net from 'net';
import tls from 'tls';
import crypto from 'crypto';
import Stream from 'stream';
import { performance as performance$1 } from 'perf_hooks';

var util$1;
(function (util) {
    util.assertEqual = (val) => val;
    function assertIs(_arg) { }
    util.assertIs = assertIs;
    function assertNever(_x) {
        throw new Error();
    }
    util.assertNever = assertNever;
    util.arrayToEnum = (items) => {
        const obj = {};
        for (const item of items) {
            obj[item] = item;
        }
        return obj;
    };
    util.getValidEnumValues = (obj) => {
        const validKeys = util.objectKeys(obj).filter((k) => typeof obj[obj[k]] !== "number");
        const filtered = {};
        for (const k of validKeys) {
            filtered[k] = obj[k];
        }
        return util.objectValues(filtered);
    };
    util.objectValues = (obj) => {
        return util.objectKeys(obj).map(function (e) {
            return obj[e];
        });
    };
    util.objectKeys = typeof Object.keys === "function" // eslint-disable-line ban/ban
        ? (obj) => Object.keys(obj) // eslint-disable-line ban/ban
        : (object) => {
            const keys = [];
            for (const key in object) {
                if (Object.prototype.hasOwnProperty.call(object, key)) {
                    keys.push(key);
                }
            }
            return keys;
        };
    util.find = (arr, checker) => {
        for (const item of arr) {
            if (checker(item))
                return item;
        }
        return undefined;
    };
    util.isInteger = typeof Number.isInteger === "function"
        ? (val) => Number.isInteger(val) // eslint-disable-line ban/ban
        : (val) => typeof val === "number" && isFinite(val) && Math.floor(val) === val;
    function joinValues(array, separator = " | ") {
        return array
            .map((val) => (typeof val === "string" ? `'${val}'` : val))
            .join(separator);
    }
    util.joinValues = joinValues;
    util.jsonStringifyReplacer = (_, value) => {
        if (typeof value === "bigint") {
            return value.toString();
        }
        return value;
    };
})(util$1 || (util$1 = {}));
var objectUtil;
(function (objectUtil) {
    objectUtil.mergeShapes = (first, second) => {
        return {
            ...first,
            ...second, // second overwrites first
        };
    };
})(objectUtil || (objectUtil = {}));
const ZodParsedType = util$1.arrayToEnum([
    "string",
    "nan",
    "number",
    "integer",
    "float",
    "boolean",
    "date",
    "bigint",
    "symbol",
    "function",
    "undefined",
    "null",
    "array",
    "object",
    "unknown",
    "promise",
    "void",
    "never",
    "map",
    "set",
]);
const getParsedType = (data) => {
    const t = typeof data;
    switch (t) {
        case "undefined":
            return ZodParsedType.undefined;
        case "string":
            return ZodParsedType.string;
        case "number":
            return isNaN(data) ? ZodParsedType.nan : ZodParsedType.number;
        case "boolean":
            return ZodParsedType.boolean;
        case "function":
            return ZodParsedType.function;
        case "bigint":
            return ZodParsedType.bigint;
        case "symbol":
            return ZodParsedType.symbol;
        case "object":
            if (Array.isArray(data)) {
                return ZodParsedType.array;
            }
            if (data === null) {
                return ZodParsedType.null;
            }
            if (data.then &&
                typeof data.then === "function" &&
                data.catch &&
                typeof data.catch === "function") {
                return ZodParsedType.promise;
            }
            if (typeof Map !== "undefined" && data instanceof Map) {
                return ZodParsedType.map;
            }
            if (typeof Set !== "undefined" && data instanceof Set) {
                return ZodParsedType.set;
            }
            if (typeof Date !== "undefined" && data instanceof Date) {
                return ZodParsedType.date;
            }
            return ZodParsedType.object;
        default:
            return ZodParsedType.unknown;
    }
};

const ZodIssueCode = util$1.arrayToEnum([
    "invalid_type",
    "invalid_literal",
    "custom",
    "invalid_union",
    "invalid_union_discriminator",
    "invalid_enum_value",
    "unrecognized_keys",
    "invalid_arguments",
    "invalid_return_type",
    "invalid_date",
    "invalid_string",
    "too_small",
    "too_big",
    "invalid_intersection_types",
    "not_multiple_of",
    "not_finite",
]);
const quotelessJson = (obj) => {
    const json = JSON.stringify(obj, null, 2);
    return json.replace(/"([^"]+)":/g, "$1:");
};
class ZodError extends Error {
    constructor(issues) {
        super();
        this.issues = [];
        this.addIssue = (sub) => {
            this.issues = [...this.issues, sub];
        };
        this.addIssues = (subs = []) => {
            this.issues = [...this.issues, ...subs];
        };
        const actualProto = new.target.prototype;
        if (Object.setPrototypeOf) {
            // eslint-disable-next-line ban/ban
            Object.setPrototypeOf(this, actualProto);
        }
        else {
            this.__proto__ = actualProto;
        }
        this.name = "ZodError";
        this.issues = issues;
    }
    get errors() {
        return this.issues;
    }
    format(_mapper) {
        const mapper = _mapper ||
            function (issue) {
                return issue.message;
            };
        const fieldErrors = { _errors: [] };
        const processError = (error) => {
            for (const issue of error.issues) {
                if (issue.code === "invalid_union") {
                    issue.unionErrors.map(processError);
                }
                else if (issue.code === "invalid_return_type") {
                    processError(issue.returnTypeError);
                }
                else if (issue.code === "invalid_arguments") {
                    processError(issue.argumentsError);
                }
                else if (issue.path.length === 0) {
                    fieldErrors._errors.push(mapper(issue));
                }
                else {
                    let curr = fieldErrors;
                    let i = 0;
                    while (i < issue.path.length) {
                        const el = issue.path[i];
                        const terminal = i === issue.path.length - 1;
                        if (!terminal) {
                            curr[el] = curr[el] || { _errors: [] };
                            // if (typeof el === "string") {
                            //   curr[el] = curr[el] || { _errors: [] };
                            // } else if (typeof el === "number") {
                            //   const errorArray: any = [];
                            //   errorArray._errors = [];
                            //   curr[el] = curr[el] || errorArray;
                            // }
                        }
                        else {
                            curr[el] = curr[el] || { _errors: [] };
                            curr[el]._errors.push(mapper(issue));
                        }
                        curr = curr[el];
                        i++;
                    }
                }
            }
        };
        processError(this);
        return fieldErrors;
    }
    static assert(value) {
        if (!(value instanceof ZodError)) {
            throw new Error(`Not a ZodError: ${value}`);
        }
    }
    toString() {
        return this.message;
    }
    get message() {
        return JSON.stringify(this.issues, util$1.jsonStringifyReplacer, 2);
    }
    get isEmpty() {
        return this.issues.length === 0;
    }
    flatten(mapper = (issue) => issue.message) {
        const fieldErrors = {};
        const formErrors = [];
        for (const sub of this.issues) {
            if (sub.path.length > 0) {
                fieldErrors[sub.path[0]] = fieldErrors[sub.path[0]] || [];
                fieldErrors[sub.path[0]].push(mapper(sub));
            }
            else {
                formErrors.push(mapper(sub));
            }
        }
        return { formErrors, fieldErrors };
    }
    get formErrors() {
        return this.flatten();
    }
}
ZodError.create = (issues) => {
    const error = new ZodError(issues);
    return error;
};

const errorMap = (issue, _ctx) => {
    let message;
    switch (issue.code) {
        case ZodIssueCode.invalid_type:
            if (issue.received === ZodParsedType.undefined) {
                message = "Required";
            }
            else {
                message = `Expected ${issue.expected}, received ${issue.received}`;
            }
            break;
        case ZodIssueCode.invalid_literal:
            message = `Invalid literal value, expected ${JSON.stringify(issue.expected, util$1.jsonStringifyReplacer)}`;
            break;
        case ZodIssueCode.unrecognized_keys:
            message = `Unrecognized key(s) in object: ${util$1.joinValues(issue.keys, ", ")}`;
            break;
        case ZodIssueCode.invalid_union:
            message = `Invalid input`;
            break;
        case ZodIssueCode.invalid_union_discriminator:
            message = `Invalid discriminator value. Expected ${util$1.joinValues(issue.options)}`;
            break;
        case ZodIssueCode.invalid_enum_value:
            message = `Invalid enum value. Expected ${util$1.joinValues(issue.options)}, received '${issue.received}'`;
            break;
        case ZodIssueCode.invalid_arguments:
            message = `Invalid function arguments`;
            break;
        case ZodIssueCode.invalid_return_type:
            message = `Invalid function return type`;
            break;
        case ZodIssueCode.invalid_date:
            message = `Invalid date`;
            break;
        case ZodIssueCode.invalid_string:
            if (typeof issue.validation === "object") {
                if ("includes" in issue.validation) {
                    message = `Invalid input: must include "${issue.validation.includes}"`;
                    if (typeof issue.validation.position === "number") {
                        message = `${message} at one or more positions greater than or equal to ${issue.validation.position}`;
                    }
                }
                else if ("startsWith" in issue.validation) {
                    message = `Invalid input: must start with "${issue.validation.startsWith}"`;
                }
                else if ("endsWith" in issue.validation) {
                    message = `Invalid input: must end with "${issue.validation.endsWith}"`;
                }
                else {
                    util$1.assertNever(issue.validation);
                }
            }
            else if (issue.validation !== "regex") {
                message = `Invalid ${issue.validation}`;
            }
            else {
                message = "Invalid";
            }
            break;
        case ZodIssueCode.too_small:
            if (issue.type === "array")
                message = `Array must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `more than`} ${issue.minimum} element(s)`;
            else if (issue.type === "string")
                message = `String must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `over`} ${issue.minimum} character(s)`;
            else if (issue.type === "number")
                message = `Number must be ${issue.exact
                    ? `exactly equal to `
                    : issue.inclusive
                        ? `greater than or equal to `
                        : `greater than `}${issue.minimum}`;
            else if (issue.type === "date")
                message = `Date must be ${issue.exact
                    ? `exactly equal to `
                    : issue.inclusive
                        ? `greater than or equal to `
                        : `greater than `}${new Date(Number(issue.minimum))}`;
            else
                message = "Invalid input";
            break;
        case ZodIssueCode.too_big:
            if (issue.type === "array")
                message = `Array must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `less than`} ${issue.maximum} element(s)`;
            else if (issue.type === "string")
                message = `String must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `under`} ${issue.maximum} character(s)`;
            else if (issue.type === "number")
                message = `Number must be ${issue.exact
                    ? `exactly`
                    : issue.inclusive
                        ? `less than or equal to`
                        : `less than`} ${issue.maximum}`;
            else if (issue.type === "bigint")
                message = `BigInt must be ${issue.exact
                    ? `exactly`
                    : issue.inclusive
                        ? `less than or equal to`
                        : `less than`} ${issue.maximum}`;
            else if (issue.type === "date")
                message = `Date must be ${issue.exact
                    ? `exactly`
                    : issue.inclusive
                        ? `smaller than or equal to`
                        : `smaller than`} ${new Date(Number(issue.maximum))}`;
            else
                message = "Invalid input";
            break;
        case ZodIssueCode.custom:
            message = `Invalid input`;
            break;
        case ZodIssueCode.invalid_intersection_types:
            message = `Intersection results could not be merged`;
            break;
        case ZodIssueCode.not_multiple_of:
            message = `Number must be a multiple of ${issue.multipleOf}`;
            break;
        case ZodIssueCode.not_finite:
            message = "Number must be finite";
            break;
        default:
            message = _ctx.defaultError;
            util$1.assertNever(issue);
    }
    return { message };
};

let overrideErrorMap = errorMap;
function setErrorMap(map) {
    overrideErrorMap = map;
}
function getErrorMap() {
    return overrideErrorMap;
}

const makeIssue = (params) => {
    const { data, path, errorMaps, issueData } = params;
    const fullPath = [...path, ...(issueData.path || [])];
    const fullIssue = {
        ...issueData,
        path: fullPath,
    };
    if (issueData.message !== undefined) {
        return {
            ...issueData,
            path: fullPath,
            message: issueData.message,
        };
    }
    let errorMessage = "";
    const maps = errorMaps
        .filter((m) => !!m)
        .slice()
        .reverse();
    for (const map of maps) {
        errorMessage = map(fullIssue, { data, defaultError: errorMessage }).message;
    }
    return {
        ...issueData,
        path: fullPath,
        message: errorMessage,
    };
};
const EMPTY_PATH = [];
function addIssueToContext(ctx, issueData) {
    const overrideMap = getErrorMap();
    const issue = makeIssue({
        issueData: issueData,
        data: ctx.data,
        path: ctx.path,
        errorMaps: [
            ctx.common.contextualErrorMap,
            ctx.schemaErrorMap,
            overrideMap,
            overrideMap === errorMap ? undefined : errorMap, // then global default map
        ].filter((x) => !!x),
    });
    ctx.common.issues.push(issue);
}
class ParseStatus {
    constructor() {
        this.value = "valid";
    }
    dirty() {
        if (this.value === "valid")
            this.value = "dirty";
    }
    abort() {
        if (this.value !== "aborted")
            this.value = "aborted";
    }
    static mergeArray(status, results) {
        const arrayValue = [];
        for (const s of results) {
            if (s.status === "aborted")
                return INVALID;
            if (s.status === "dirty")
                status.dirty();
            arrayValue.push(s.value);
        }
        return { status: status.value, value: arrayValue };
    }
    static async mergeObjectAsync(status, pairs) {
        const syncPairs = [];
        for (const pair of pairs) {
            const key = await pair.key;
            const value = await pair.value;
            syncPairs.push({
                key,
                value,
            });
        }
        return ParseStatus.mergeObjectSync(status, syncPairs);
    }
    static mergeObjectSync(status, pairs) {
        const finalObject = {};
        for (const pair of pairs) {
            const { key, value } = pair;
            if (key.status === "aborted")
                return INVALID;
            if (value.status === "aborted")
                return INVALID;
            if (key.status === "dirty")
                status.dirty();
            if (value.status === "dirty")
                status.dirty();
            if (key.value !== "__proto__" &&
                (typeof value.value !== "undefined" || pair.alwaysSet)) {
                finalObject[key.value] = value.value;
            }
        }
        return { status: status.value, value: finalObject };
    }
}
const INVALID = Object.freeze({
    status: "aborted",
});
const DIRTY = (value) => ({ status: "dirty", value });
const OK = (value) => ({ status: "valid", value });
const isAborted = (x) => x.status === "aborted";
const isDirty = (x) => x.status === "dirty";
const isValid = (x) => x.status === "valid";
const isAsync = (x) => typeof Promise !== "undefined" && x instanceof Promise;

/******************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */

function __classPrivateFieldGet(receiver, state, kind, f) {
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return state.get(receiver);
}

function __classPrivateFieldSet(receiver, state, value, kind, f) {
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return (state.set(receiver, value)), value;
}

typeof SuppressedError === "function" ? SuppressedError : function (error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
};

var errorUtil;
(function (errorUtil) {
    errorUtil.errToObj = (message) => typeof message === "string" ? { message } : message || {};
    errorUtil.toString = (message) => typeof message === "string" ? message : message === null || message === void 0 ? void 0 : message.message;
})(errorUtil || (errorUtil = {}));

var _ZodEnum_cache, _ZodNativeEnum_cache;
class ParseInputLazyPath {
    constructor(parent, value, path, key) {
        this._cachedPath = [];
        this.parent = parent;
        this.data = value;
        this._path = path;
        this._key = key;
    }
    get path() {
        if (!this._cachedPath.length) {
            if (this._key instanceof Array) {
                this._cachedPath.push(...this._path, ...this._key);
            }
            else {
                this._cachedPath.push(...this._path, this._key);
            }
        }
        return this._cachedPath;
    }
}
const handleResult = (ctx, result) => {
    if (isValid(result)) {
        return { success: true, data: result.value };
    }
    else {
        if (!ctx.common.issues.length) {
            throw new Error("Validation failed but no issues detected.");
        }
        return {
            success: false,
            get error() {
                if (this._error)
                    return this._error;
                const error = new ZodError(ctx.common.issues);
                this._error = error;
                return this._error;
            },
        };
    }
};
function processCreateParams(params) {
    if (!params)
        return {};
    const { errorMap, invalid_type_error, required_error, description } = params;
    if (errorMap && (invalid_type_error || required_error)) {
        throw new Error(`Can't use "invalid_type_error" or "required_error" in conjunction with custom error map.`);
    }
    if (errorMap)
        return { errorMap: errorMap, description };
    const customMap = (iss, ctx) => {
        var _a, _b;
        const { message } = params;
        if (iss.code === "invalid_enum_value") {
            return { message: message !== null && message !== void 0 ? message : ctx.defaultError };
        }
        if (typeof ctx.data === "undefined") {
            return { message: (_a = message !== null && message !== void 0 ? message : required_error) !== null && _a !== void 0 ? _a : ctx.defaultError };
        }
        if (iss.code !== "invalid_type")
            return { message: ctx.defaultError };
        return { message: (_b = message !== null && message !== void 0 ? message : invalid_type_error) !== null && _b !== void 0 ? _b : ctx.defaultError };
    };
    return { errorMap: customMap, description };
}
class ZodType {
    constructor(def) {
        /** Alias of safeParseAsync */
        this.spa = this.safeParseAsync;
        this._def = def;
        this.parse = this.parse.bind(this);
        this.safeParse = this.safeParse.bind(this);
        this.parseAsync = this.parseAsync.bind(this);
        this.safeParseAsync = this.safeParseAsync.bind(this);
        this.spa = this.spa.bind(this);
        this.refine = this.refine.bind(this);
        this.refinement = this.refinement.bind(this);
        this.superRefine = this.superRefine.bind(this);
        this.optional = this.optional.bind(this);
        this.nullable = this.nullable.bind(this);
        this.nullish = this.nullish.bind(this);
        this.array = this.array.bind(this);
        this.promise = this.promise.bind(this);
        this.or = this.or.bind(this);
        this.and = this.and.bind(this);
        this.transform = this.transform.bind(this);
        this.brand = this.brand.bind(this);
        this.default = this.default.bind(this);
        this.catch = this.catch.bind(this);
        this.describe = this.describe.bind(this);
        this.pipe = this.pipe.bind(this);
        this.readonly = this.readonly.bind(this);
        this.isNullable = this.isNullable.bind(this);
        this.isOptional = this.isOptional.bind(this);
    }
    get description() {
        return this._def.description;
    }
    _getType(input) {
        return getParsedType(input.data);
    }
    _getOrReturnCtx(input, ctx) {
        return (ctx || {
            common: input.parent.common,
            data: input.data,
            parsedType: getParsedType(input.data),
            schemaErrorMap: this._def.errorMap,
            path: input.path,
            parent: input.parent,
        });
    }
    _processInputParams(input) {
        return {
            status: new ParseStatus(),
            ctx: {
                common: input.parent.common,
                data: input.data,
                parsedType: getParsedType(input.data),
                schemaErrorMap: this._def.errorMap,
                path: input.path,
                parent: input.parent,
            },
        };
    }
    _parseSync(input) {
        const result = this._parse(input);
        if (isAsync(result)) {
            throw new Error("Synchronous parse encountered promise.");
        }
        return result;
    }
    _parseAsync(input) {
        const result = this._parse(input);
        return Promise.resolve(result);
    }
    parse(data, params) {
        const result = this.safeParse(data, params);
        if (result.success)
            return result.data;
        throw result.error;
    }
    safeParse(data, params) {
        var _a;
        const ctx = {
            common: {
                issues: [],
                async: (_a = params === null || params === void 0 ? void 0 : params.async) !== null && _a !== void 0 ? _a : false,
                contextualErrorMap: params === null || params === void 0 ? void 0 : params.errorMap,
            },
            path: (params === null || params === void 0 ? void 0 : params.path) || [],
            schemaErrorMap: this._def.errorMap,
            parent: null,
            data,
            parsedType: getParsedType(data),
        };
        const result = this._parseSync({ data, path: ctx.path, parent: ctx });
        return handleResult(ctx, result);
    }
    async parseAsync(data, params) {
        const result = await this.safeParseAsync(data, params);
        if (result.success)
            return result.data;
        throw result.error;
    }
    async safeParseAsync(data, params) {
        const ctx = {
            common: {
                issues: [],
                contextualErrorMap: params === null || params === void 0 ? void 0 : params.errorMap,
                async: true,
            },
            path: (params === null || params === void 0 ? void 0 : params.path) || [],
            schemaErrorMap: this._def.errorMap,
            parent: null,
            data,
            parsedType: getParsedType(data),
        };
        const maybeAsyncResult = this._parse({ data, path: ctx.path, parent: ctx });
        const result = await (isAsync(maybeAsyncResult)
            ? maybeAsyncResult
            : Promise.resolve(maybeAsyncResult));
        return handleResult(ctx, result);
    }
    refine(check, message) {
        const getIssueProperties = (val) => {
            if (typeof message === "string" || typeof message === "undefined") {
                return { message };
            }
            else if (typeof message === "function") {
                return message(val);
            }
            else {
                return message;
            }
        };
        return this._refinement((val, ctx) => {
            const result = check(val);
            const setError = () => ctx.addIssue({
                code: ZodIssueCode.custom,
                ...getIssueProperties(val),
            });
            if (typeof Promise !== "undefined" && result instanceof Promise) {
                return result.then((data) => {
                    if (!data) {
                        setError();
                        return false;
                    }
                    else {
                        return true;
                    }
                });
            }
            if (!result) {
                setError();
                return false;
            }
            else {
                return true;
            }
        });
    }
    refinement(check, refinementData) {
        return this._refinement((val, ctx) => {
            if (!check(val)) {
                ctx.addIssue(typeof refinementData === "function"
                    ? refinementData(val, ctx)
                    : refinementData);
                return false;
            }
            else {
                return true;
            }
        });
    }
    _refinement(refinement) {
        return new ZodEffects({
            schema: this,
            typeName: ZodFirstPartyTypeKind.ZodEffects,
            effect: { type: "refinement", refinement },
        });
    }
    superRefine(refinement) {
        return this._refinement(refinement);
    }
    optional() {
        return ZodOptional.create(this, this._def);
    }
    nullable() {
        return ZodNullable.create(this, this._def);
    }
    nullish() {
        return this.nullable().optional();
    }
    array() {
        return ZodArray.create(this, this._def);
    }
    promise() {
        return ZodPromise.create(this, this._def);
    }
    or(option) {
        return ZodUnion.create([this, option], this._def);
    }
    and(incoming) {
        return ZodIntersection.create(this, incoming, this._def);
    }
    transform(transform) {
        return new ZodEffects({
            ...processCreateParams(this._def),
            schema: this,
            typeName: ZodFirstPartyTypeKind.ZodEffects,
            effect: { type: "transform", transform },
        });
    }
    default(def) {
        const defaultValueFunc = typeof def === "function" ? def : () => def;
        return new ZodDefault({
            ...processCreateParams(this._def),
            innerType: this,
            defaultValue: defaultValueFunc,
            typeName: ZodFirstPartyTypeKind.ZodDefault,
        });
    }
    brand() {
        return new ZodBranded({
            typeName: ZodFirstPartyTypeKind.ZodBranded,
            type: this,
            ...processCreateParams(this._def),
        });
    }
    catch(def) {
        const catchValueFunc = typeof def === "function" ? def : () => def;
        return new ZodCatch({
            ...processCreateParams(this._def),
            innerType: this,
            catchValue: catchValueFunc,
            typeName: ZodFirstPartyTypeKind.ZodCatch,
        });
    }
    describe(description) {
        const This = this.constructor;
        return new This({
            ...this._def,
            description,
        });
    }
    pipe(target) {
        return ZodPipeline.create(this, target);
    }
    readonly() {
        return ZodReadonly.create(this);
    }
    isOptional() {
        return this.safeParse(undefined).success;
    }
    isNullable() {
        return this.safeParse(null).success;
    }
}
const cuidRegex = /^c[^\s-]{8,}$/i;
const cuid2Regex = /^[0-9a-z]+$/;
const ulidRegex = /^[0-9A-HJKMNP-TV-Z]{26}$/;
// const uuidRegex =
//   /^([a-f0-9]{8}-[a-f0-9]{4}-[1-5][a-f0-9]{3}-[a-f0-9]{4}-[a-f0-9]{12}|00000000-0000-0000-0000-000000000000)$/i;
const uuidRegex = /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/i;
const nanoidRegex = /^[a-z0-9_-]{21}$/i;
const durationRegex = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/;
// from https://stackoverflow.com/a/46181/1550155
// old version: too slow, didn't support unicode
// const emailRegex = /^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))$/i;
//old email regex
// const emailRegex = /^(([^<>()[\].,;:\s@"]+(\.[^<>()[\].,;:\s@"]+)*)|(".+"))@((?!-)([^<>()[\].,;:\s@"]+\.)+[^<>()[\].,;:\s@"]{1,})[^-<>()[\].,;:\s@"]$/i;
// eslint-disable-next-line
// const emailRegex =
//   /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[(((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2}))\.){3}((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2}))\])|(\[IPv6:(([a-f0-9]{1,4}:){7}|::([a-f0-9]{1,4}:){0,6}|([a-f0-9]{1,4}:){1}:([a-f0-9]{1,4}:){0,5}|([a-f0-9]{1,4}:){2}:([a-f0-9]{1,4}:){0,4}|([a-f0-9]{1,4}:){3}:([a-f0-9]{1,4}:){0,3}|([a-f0-9]{1,4}:){4}:([a-f0-9]{1,4}:){0,2}|([a-f0-9]{1,4}:){5}:([a-f0-9]{1,4}:){0,1})([a-f0-9]{1,4}|(((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2}))\.){3}((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2})))\])|([A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])*(\.[A-Za-z]{2,})+))$/;
// const emailRegex =
//   /^[a-zA-Z0-9\.\!\#\$\%\&\'\*\+\/\=\?\^\_\`\{\|\}\~\-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
// const emailRegex =
//   /^(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])$/i;
const emailRegex = /^(?!\.)(?!.*\.\.)([A-Z0-9_'+\-\.]*)[A-Z0-9_+-]@([A-Z0-9][A-Z0-9\-]*\.)+[A-Z]{2,}$/i;
// const emailRegex =
//   /^[a-z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-z0-9-]+(?:\.[a-z0-9\-]+)*$/i;
// from https://thekevinscott.com/emojis-in-javascript/#writing-a-regular-expression
const _emojiRegex = `^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$`;
let emojiRegex;
// faster, simpler, safer
const ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/;
const ipv6Regex = /^(([a-f0-9]{1,4}:){7}|::([a-f0-9]{1,4}:){0,6}|([a-f0-9]{1,4}:){1}:([a-f0-9]{1,4}:){0,5}|([a-f0-9]{1,4}:){2}:([a-f0-9]{1,4}:){0,4}|([a-f0-9]{1,4}:){3}:([a-f0-9]{1,4}:){0,3}|([a-f0-9]{1,4}:){4}:([a-f0-9]{1,4}:){0,2}|([a-f0-9]{1,4}:){5}:([a-f0-9]{1,4}:){0,1})([a-f0-9]{1,4}|(((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2}))\.){3}((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2})))$/;
// https://stackoverflow.com/questions/7860392/determine-if-string-is-in-base64-using-javascript
const base64Regex = /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;
// simple
// const dateRegexSource = `\\d{4}-\\d{2}-\\d{2}`;
// no leap year validation
// const dateRegexSource = `\\d{4}-((0[13578]|10|12)-31|(0[13-9]|1[0-2])-30|(0[1-9]|1[0-2])-(0[1-9]|1\\d|2\\d))`;
// with leap year validation
const dateRegexSource = `((\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-((0[13578]|1[02])-(0[1-9]|[12]\\d|3[01])|(0[469]|11)-(0[1-9]|[12]\\d|30)|(02)-(0[1-9]|1\\d|2[0-8])))`;
const dateRegex = new RegExp(`^${dateRegexSource}$`);
function timeRegexSource(args) {
    // let regex = `\\d{2}:\\d{2}:\\d{2}`;
    let regex = `([01]\\d|2[0-3]):[0-5]\\d:[0-5]\\d`;
    if (args.precision) {
        regex = `${regex}\\.\\d{${args.precision}}`;
    }
    else if (args.precision == null) {
        regex = `${regex}(\\.\\d+)?`;
    }
    return regex;
}
function timeRegex(args) {
    return new RegExp(`^${timeRegexSource(args)}$`);
}
// Adapted from https://stackoverflow.com/a/3143231
function datetimeRegex(args) {
    let regex = `${dateRegexSource}T${timeRegexSource(args)}`;
    const opts = [];
    opts.push(args.local ? `Z?` : `Z`);
    if (args.offset)
        opts.push(`([+-]\\d{2}:?\\d{2})`);
    regex = `${regex}(${opts.join("|")})`;
    return new RegExp(`^${regex}$`);
}
function isValidIP(ip, version) {
    if ((version === "v4" || !version) && ipv4Regex.test(ip)) {
        return true;
    }
    if ((version === "v6" || !version) && ipv6Regex.test(ip)) {
        return true;
    }
    return false;
}
class ZodString extends ZodType {
    _parse(input) {
        if (this._def.coerce) {
            input.data = String(input.data);
        }
        const parsedType = this._getType(input);
        if (parsedType !== ZodParsedType.string) {
            const ctx = this._getOrReturnCtx(input);
            addIssueToContext(ctx, {
                code: ZodIssueCode.invalid_type,
                expected: ZodParsedType.string,
                received: ctx.parsedType,
            });
            return INVALID;
        }
        const status = new ParseStatus();
        let ctx = undefined;
        for (const check of this._def.checks) {
            if (check.kind === "min") {
                if (input.data.length < check.value) {
                    ctx = this._getOrReturnCtx(input, ctx);
                    addIssueToContext(ctx, {
                        code: ZodIssueCode.too_small,
                        minimum: check.value,
                        type: "string",
                        inclusive: true,
                        exact: false,
                        message: check.message,
                    });
                    status.dirty();
                }
            }
            else if (check.kind === "max") {
                if (input.data.length > check.value) {
                    ctx = this._getOrReturnCtx(input, ctx);
                    addIssueToContext(ctx, {
                        code: ZodIssueCode.too_big,
                        maximum: check.value,
                        type: "string",
                        inclusive: true,
                        exact: false,
                        message: check.message,
                    });
                    status.dirty();
                }
            }
            else if (check.kind === "length") {
                const tooBig = input.data.length > check.value;
                const tooSmall = input.data.length < check.value;
                if (tooBig || tooSmall) {
                    ctx = this._getOrReturnCtx(input, ctx);
                    if (tooBig) {
                        addIssueToContext(ctx, {
                            code: ZodIssueCode.too_big,
                            maximum: check.value,
                            type: "string",
                            inclusive: true,
                            exact: true,
                            message: check.message,
                        });
                    }
                    else if (tooSmall) {
                        addIssueToContext(ctx, {
                            code: ZodIssueCode.too_small,
                            minimum: check.value,
                            type: "string",
                            inclusive: true,
                            exact: true,
                            message: check.message,
                        });
                    }
                    status.dirty();
                }
            }
            else if (check.kind === "email") {
                if (!emailRegex.test(input.data)) {
                    ctx = this._getOrReturnCtx(input, ctx);
                    addIssueToContext(ctx, {
                        validation: "email",
                        code: ZodIssueCode.invalid_string,
                        message: check.message,
                    });
                    status.dirty();
                }
            }
            else if (check.kind === "emoji") {
                if (!emojiRegex) {
                    emojiRegex = new RegExp(_emojiRegex, "u");
                }
                if (!emojiRegex.test(input.data)) {
                    ctx = this._getOrReturnCtx(input, ctx);
                    addIssueToContext(ctx, {
                        validation: "emoji",
                        code: ZodIssueCode.invalid_string,
                        message: check.message,
                    });
                    status.dirty();
                }
            }
            else if (check.kind === "uuid") {
                if (!uuidRegex.test(input.data)) {
                    ctx = this._getOrReturnCtx(input, ctx);
                    addIssueToContext(ctx, {
                        validation: "uuid",
                        code: ZodIssueCode.invalid_string,
                        message: check.message,
                    });
                    status.dirty();
                }
            }
            else if (check.kind === "nanoid") {
                if (!nanoidRegex.test(input.data)) {
                    ctx = this._getOrReturnCtx(input, ctx);
                    addIssueToContext(ctx, {
                        validation: "nanoid",
                        code: ZodIssueCode.invalid_string,
                        message: check.message,
                    });
                    status.dirty();
                }
            }
            else if (check.kind === "cuid") {
                if (!cuidRegex.test(input.data)) {
                    ctx = this._getOrReturnCtx(input, ctx);
                    addIssueToContext(ctx, {
                        validation: "cuid",
                        code: ZodIssueCode.invalid_string,
                        message: check.message,
                    });
                    status.dirty();
                }
            }
            else if (check.kind === "cuid2") {
                if (!cuid2Regex.test(input.data)) {
                    ctx = this._getOrReturnCtx(input, ctx);
                    addIssueToContext(ctx, {
                        validation: "cuid2",
                        code: ZodIssueCode.invalid_string,
                        message: check.message,
                    });
                    status.dirty();
                }
            }
            else if (check.kind === "ulid") {
                if (!ulidRegex.test(input.data)) {
                    ctx = this._getOrReturnCtx(input, ctx);
                    addIssueToContext(ctx, {
                        validation: "ulid",
                        code: ZodIssueCode.invalid_string,
                        message: check.message,
                    });
                    status.dirty();
                }
            }
            else if (check.kind === "url") {
                try {
                    new URL(input.data);
                }
                catch (_a) {
                    ctx = this._getOrReturnCtx(input, ctx);
                    addIssueToContext(ctx, {
                        validation: "url",
                        code: ZodIssueCode.invalid_string,
                        message: check.message,
                    });
                    status.dirty();
                }
            }
            else if (check.kind === "regex") {
                check.regex.lastIndex = 0;
                const testResult = check.regex.test(input.data);
                if (!testResult) {
                    ctx = this._getOrReturnCtx(input, ctx);
                    addIssueToContext(ctx, {
                        validation: "regex",
                        code: ZodIssueCode.invalid_string,
                        message: check.message,
                    });
                    status.dirty();
                }
            }
            else if (check.kind === "trim") {
                input.data = input.data.trim();
            }
            else if (check.kind === "includes") {
                if (!input.data.includes(check.value, check.position)) {
                    ctx = this._getOrReturnCtx(input, ctx);
                    addIssueToContext(ctx, {
                        code: ZodIssueCode.invalid_string,
                        validation: { includes: check.value, position: check.position },
                        message: check.message,
                    });
                    status.dirty();
                }
            }
            else if (check.kind === "toLowerCase") {
                input.data = input.data.toLowerCase();
            }
            else if (check.kind === "toUpperCase") {
                input.data = input.data.toUpperCase();
            }
            else if (check.kind === "startsWith") {
                if (!input.data.startsWith(check.value)) {
                    ctx = this._getOrReturnCtx(input, ctx);
                    addIssueToContext(ctx, {
                        code: ZodIssueCode.invalid_string,
                        validation: { startsWith: check.value },
                        message: check.message,
                    });
                    status.dirty();
                }
            }
            else if (check.kind === "endsWith") {
                if (!input.data.endsWith(check.value)) {
                    ctx = this._getOrReturnCtx(input, ctx);
                    addIssueToContext(ctx, {
                        code: ZodIssueCode.invalid_string,
                        validation: { endsWith: check.value },
                        message: check.message,
                    });
                    status.dirty();
                }
            }
            else if (check.kind === "datetime") {
                const regex = datetimeRegex(check);
                if (!regex.test(input.data)) {
                    ctx = this._getOrReturnCtx(input, ctx);
                    addIssueToContext(ctx, {
                        code: ZodIssueCode.invalid_string,
                        validation: "datetime",
                        message: check.message,
                    });
                    status.dirty();
                }
            }
            else if (check.kind === "date") {
                const regex = dateRegex;
                if (!regex.test(input.data)) {
                    ctx = this._getOrReturnCtx(input, ctx);
                    addIssueToContext(ctx, {
                        code: ZodIssueCode.invalid_string,
                        validation: "date",
                        message: check.message,
                    });
                    status.dirty();
                }
            }
            else if (check.kind === "time") {
                const regex = timeRegex(check);
                if (!regex.test(input.data)) {
                    ctx = this._getOrReturnCtx(input, ctx);
                    addIssueToContext(ctx, {
                        code: ZodIssueCode.invalid_string,
                        validation: "time",
                        message: check.message,
                    });
                    status.dirty();
                }
            }
            else if (check.kind === "duration") {
                if (!durationRegex.test(input.data)) {
                    ctx = this._getOrReturnCtx(input, ctx);
                    addIssueToContext(ctx, {
                        validation: "duration",
                        code: ZodIssueCode.invalid_string,
                        message: check.message,
                    });
                    status.dirty();
                }
            }
            else if (check.kind === "ip") {
                if (!isValidIP(input.data, check.version)) {
                    ctx = this._getOrReturnCtx(input, ctx);
                    addIssueToContext(ctx, {
                        validation: "ip",
                        code: ZodIssueCode.invalid_string,
                        message: check.message,
                    });
                    status.dirty();
                }
            }
            else if (check.kind === "base64") {
                if (!base64Regex.test(input.data)) {
                    ctx = this._getOrReturnCtx(input, ctx);
                    addIssueToContext(ctx, {
                        validation: "base64",
                        code: ZodIssueCode.invalid_string,
                        message: check.message,
                    });
                    status.dirty();
                }
            }
            else {
                util$1.assertNever(check);
            }
        }
        return { status: status.value, value: input.data };
    }
    _regex(regex, validation, message) {
        return this.refinement((data) => regex.test(data), {
            validation,
            code: ZodIssueCode.invalid_string,
            ...errorUtil.errToObj(message),
        });
    }
    _addCheck(check) {
        return new ZodString({
            ...this._def,
            checks: [...this._def.checks, check],
        });
    }
    email(message) {
        return this._addCheck({ kind: "email", ...errorUtil.errToObj(message) });
    }
    url(message) {
        return this._addCheck({ kind: "url", ...errorUtil.errToObj(message) });
    }
    emoji(message) {
        return this._addCheck({ kind: "emoji", ...errorUtil.errToObj(message) });
    }
    uuid(message) {
        return this._addCheck({ kind: "uuid", ...errorUtil.errToObj(message) });
    }
    nanoid(message) {
        return this._addCheck({ kind: "nanoid", ...errorUtil.errToObj(message) });
    }
    cuid(message) {
        return this._addCheck({ kind: "cuid", ...errorUtil.errToObj(message) });
    }
    cuid2(message) {
        return this._addCheck({ kind: "cuid2", ...errorUtil.errToObj(message) });
    }
    ulid(message) {
        return this._addCheck({ kind: "ulid", ...errorUtil.errToObj(message) });
    }
    base64(message) {
        return this._addCheck({ kind: "base64", ...errorUtil.errToObj(message) });
    }
    ip(options) {
        return this._addCheck({ kind: "ip", ...errorUtil.errToObj(options) });
    }
    datetime(options) {
        var _a, _b;
        if (typeof options === "string") {
            return this._addCheck({
                kind: "datetime",
                precision: null,
                offset: false,
                local: false,
                message: options,
            });
        }
        return this._addCheck({
            kind: "datetime",
            precision: typeof (options === null || options === void 0 ? void 0 : options.precision) === "undefined" ? null : options === null || options === void 0 ? void 0 : options.precision,
            offset: (_a = options === null || options === void 0 ? void 0 : options.offset) !== null && _a !== void 0 ? _a : false,
            local: (_b = options === null || options === void 0 ? void 0 : options.local) !== null && _b !== void 0 ? _b : false,
            ...errorUtil.errToObj(options === null || options === void 0 ? void 0 : options.message),
        });
    }
    date(message) {
        return this._addCheck({ kind: "date", message });
    }
    time(options) {
        if (typeof options === "string") {
            return this._addCheck({
                kind: "time",
                precision: null,
                message: options,
            });
        }
        return this._addCheck({
            kind: "time",
            precision: typeof (options === null || options === void 0 ? void 0 : options.precision) === "undefined" ? null : options === null || options === void 0 ? void 0 : options.precision,
            ...errorUtil.errToObj(options === null || options === void 0 ? void 0 : options.message),
        });
    }
    duration(message) {
        return this._addCheck({ kind: "duration", ...errorUtil.errToObj(message) });
    }
    regex(regex, message) {
        return this._addCheck({
            kind: "regex",
            regex: regex,
            ...errorUtil.errToObj(message),
        });
    }
    includes(value, options) {
        return this._addCheck({
            kind: "includes",
            value: value,
            position: options === null || options === void 0 ? void 0 : options.position,
            ...errorUtil.errToObj(options === null || options === void 0 ? void 0 : options.message),
        });
    }
    startsWith(value, message) {
        return this._addCheck({
            kind: "startsWith",
            value: value,
            ...errorUtil.errToObj(message),
        });
    }
    endsWith(value, message) {
        return this._addCheck({
            kind: "endsWith",
            value: value,
            ...errorUtil.errToObj(message),
        });
    }
    min(minLength, message) {
        return this._addCheck({
            kind: "min",
            value: minLength,
            ...errorUtil.errToObj(message),
        });
    }
    max(maxLength, message) {
        return this._addCheck({
            kind: "max",
            value: maxLength,
            ...errorUtil.errToObj(message),
        });
    }
    length(len, message) {
        return this._addCheck({
            kind: "length",
            value: len,
            ...errorUtil.errToObj(message),
        });
    }
    /**
     * @deprecated Use z.string().min(1) instead.
     * @see {@link ZodString.min}
     */
    nonempty(message) {
        return this.min(1, errorUtil.errToObj(message));
    }
    trim() {
        return new ZodString({
            ...this._def,
            checks: [...this._def.checks, { kind: "trim" }],
        });
    }
    toLowerCase() {
        return new ZodString({
            ...this._def,
            checks: [...this._def.checks, { kind: "toLowerCase" }],
        });
    }
    toUpperCase() {
        return new ZodString({
            ...this._def,
            checks: [...this._def.checks, { kind: "toUpperCase" }],
        });
    }
    get isDatetime() {
        return !!this._def.checks.find((ch) => ch.kind === "datetime");
    }
    get isDate() {
        return !!this._def.checks.find((ch) => ch.kind === "date");
    }
    get isTime() {
        return !!this._def.checks.find((ch) => ch.kind === "time");
    }
    get isDuration() {
        return !!this._def.checks.find((ch) => ch.kind === "duration");
    }
    get isEmail() {
        return !!this._def.checks.find((ch) => ch.kind === "email");
    }
    get isURL() {
        return !!this._def.checks.find((ch) => ch.kind === "url");
    }
    get isEmoji() {
        return !!this._def.checks.find((ch) => ch.kind === "emoji");
    }
    get isUUID() {
        return !!this._def.checks.find((ch) => ch.kind === "uuid");
    }
    get isNANOID() {
        return !!this._def.checks.find((ch) => ch.kind === "nanoid");
    }
    get isCUID() {
        return !!this._def.checks.find((ch) => ch.kind === "cuid");
    }
    get isCUID2() {
        return !!this._def.checks.find((ch) => ch.kind === "cuid2");
    }
    get isULID() {
        return !!this._def.checks.find((ch) => ch.kind === "ulid");
    }
    get isIP() {
        return !!this._def.checks.find((ch) => ch.kind === "ip");
    }
    get isBase64() {
        return !!this._def.checks.find((ch) => ch.kind === "base64");
    }
    get minLength() {
        let min = null;
        for (const ch of this._def.checks) {
            if (ch.kind === "min") {
                if (min === null || ch.value > min)
                    min = ch.value;
            }
        }
        return min;
    }
    get maxLength() {
        let max = null;
        for (const ch of this._def.checks) {
            if (ch.kind === "max") {
                if (max === null || ch.value < max)
                    max = ch.value;
            }
        }
        return max;
    }
}
ZodString.create = (params) => {
    var _a;
    return new ZodString({
        checks: [],
        typeName: ZodFirstPartyTypeKind.ZodString,
        coerce: (_a = params === null || params === void 0 ? void 0 : params.coerce) !== null && _a !== void 0 ? _a : false,
        ...processCreateParams(params),
    });
};
// https://stackoverflow.com/questions/3966484/why-does-modulus-operator-return-fractional-number-in-javascript/31711034#31711034
function floatSafeRemainder(val, step) {
    const valDecCount = (val.toString().split(".")[1] || "").length;
    const stepDecCount = (step.toString().split(".")[1] || "").length;
    const decCount = valDecCount > stepDecCount ? valDecCount : stepDecCount;
    const valInt = parseInt(val.toFixed(decCount).replace(".", ""));
    const stepInt = parseInt(step.toFixed(decCount).replace(".", ""));
    return (valInt % stepInt) / Math.pow(10, decCount);
}
class ZodNumber extends ZodType {
    constructor() {
        super(...arguments);
        this.min = this.gte;
        this.max = this.lte;
        this.step = this.multipleOf;
    }
    _parse(input) {
        if (this._def.coerce) {
            input.data = Number(input.data);
        }
        const parsedType = this._getType(input);
        if (parsedType !== ZodParsedType.number) {
            const ctx = this._getOrReturnCtx(input);
            addIssueToContext(ctx, {
                code: ZodIssueCode.invalid_type,
                expected: ZodParsedType.number,
                received: ctx.parsedType,
            });
            return INVALID;
        }
        let ctx = undefined;
        const status = new ParseStatus();
        for (const check of this._def.checks) {
            if (check.kind === "int") {
                if (!util$1.isInteger(input.data)) {
                    ctx = this._getOrReturnCtx(input, ctx);
                    addIssueToContext(ctx, {
                        code: ZodIssueCode.invalid_type,
                        expected: "integer",
                        received: "float",
                        message: check.message,
                    });
                    status.dirty();
                }
            }
            else if (check.kind === "min") {
                const tooSmall = check.inclusive
                    ? input.data < check.value
                    : input.data <= check.value;
                if (tooSmall) {
                    ctx = this._getOrReturnCtx(input, ctx);
                    addIssueToContext(ctx, {
                        code: ZodIssueCode.too_small,
                        minimum: check.value,
                        type: "number",
                        inclusive: check.inclusive,
                        exact: false,
                        message: check.message,
                    });
                    status.dirty();
                }
            }
            else if (check.kind === "max") {
                const tooBig = check.inclusive
                    ? input.data > check.value
                    : input.data >= check.value;
                if (tooBig) {
                    ctx = this._getOrReturnCtx(input, ctx);
                    addIssueToContext(ctx, {
                        code: ZodIssueCode.too_big,
                        maximum: check.value,
                        type: "number",
                        inclusive: check.inclusive,
                        exact: false,
                        message: check.message,
                    });
                    status.dirty();
                }
            }
            else if (check.kind === "multipleOf") {
                if (floatSafeRemainder(input.data, check.value) !== 0) {
                    ctx = this._getOrReturnCtx(input, ctx);
                    addIssueToContext(ctx, {
                        code: ZodIssueCode.not_multiple_of,
                        multipleOf: check.value,
                        message: check.message,
                    });
                    status.dirty();
                }
            }
            else if (check.kind === "finite") {
                if (!Number.isFinite(input.data)) {
                    ctx = this._getOrReturnCtx(input, ctx);
                    addIssueToContext(ctx, {
                        code: ZodIssueCode.not_finite,
                        message: check.message,
                    });
                    status.dirty();
                }
            }
            else {
                util$1.assertNever(check);
            }
        }
        return { status: status.value, value: input.data };
    }
    gte(value, message) {
        return this.setLimit("min", value, true, errorUtil.toString(message));
    }
    gt(value, message) {
        return this.setLimit("min", value, false, errorUtil.toString(message));
    }
    lte(value, message) {
        return this.setLimit("max", value, true, errorUtil.toString(message));
    }
    lt(value, message) {
        return this.setLimit("max", value, false, errorUtil.toString(message));
    }
    setLimit(kind, value, inclusive, message) {
        return new ZodNumber({
            ...this._def,
            checks: [
                ...this._def.checks,
                {
                    kind,
                    value,
                    inclusive,
                    message: errorUtil.toString(message),
                },
            ],
        });
    }
    _addCheck(check) {
        return new ZodNumber({
            ...this._def,
            checks: [...this._def.checks, check],
        });
    }
    int(message) {
        return this._addCheck({
            kind: "int",
            message: errorUtil.toString(message),
        });
    }
    positive(message) {
        return this._addCheck({
            kind: "min",
            value: 0,
            inclusive: false,
            message: errorUtil.toString(message),
        });
    }
    negative(message) {
        return this._addCheck({
            kind: "max",
            value: 0,
            inclusive: false,
            message: errorUtil.toString(message),
        });
    }
    nonpositive(message) {
        return this._addCheck({
            kind: "max",
            value: 0,
            inclusive: true,
            message: errorUtil.toString(message),
        });
    }
    nonnegative(message) {
        return this._addCheck({
            kind: "min",
            value: 0,
            inclusive: true,
            message: errorUtil.toString(message),
        });
    }
    multipleOf(value, message) {
        return this._addCheck({
            kind: "multipleOf",
            value: value,
            message: errorUtil.toString(message),
        });
    }
    finite(message) {
        return this._addCheck({
            kind: "finite",
            message: errorUtil.toString(message),
        });
    }
    safe(message) {
        return this._addCheck({
            kind: "min",
            inclusive: true,
            value: Number.MIN_SAFE_INTEGER,
            message: errorUtil.toString(message),
        })._addCheck({
            kind: "max",
            inclusive: true,
            value: Number.MAX_SAFE_INTEGER,
            message: errorUtil.toString(message),
        });
    }
    get minValue() {
        let min = null;
        for (const ch of this._def.checks) {
            if (ch.kind === "min") {
                if (min === null || ch.value > min)
                    min = ch.value;
            }
        }
        return min;
    }
    get maxValue() {
        let max = null;
        for (const ch of this._def.checks) {
            if (ch.kind === "max") {
                if (max === null || ch.value < max)
                    max = ch.value;
            }
        }
        return max;
    }
    get isInt() {
        return !!this._def.checks.find((ch) => ch.kind === "int" ||
            (ch.kind === "multipleOf" && util$1.isInteger(ch.value)));
    }
    get isFinite() {
        let max = null, min = null;
        for (const ch of this._def.checks) {
            if (ch.kind === "finite" ||
                ch.kind === "int" ||
                ch.kind === "multipleOf") {
                return true;
            }
            else if (ch.kind === "min") {
                if (min === null || ch.value > min)
                    min = ch.value;
            }
            else if (ch.kind === "max") {
                if (max === null || ch.value < max)
                    max = ch.value;
            }
        }
        return Number.isFinite(min) && Number.isFinite(max);
    }
}
ZodNumber.create = (params) => {
    return new ZodNumber({
        checks: [],
        typeName: ZodFirstPartyTypeKind.ZodNumber,
        coerce: (params === null || params === void 0 ? void 0 : params.coerce) || false,
        ...processCreateParams(params),
    });
};
class ZodBigInt extends ZodType {
    constructor() {
        super(...arguments);
        this.min = this.gte;
        this.max = this.lte;
    }
    _parse(input) {
        if (this._def.coerce) {
            input.data = BigInt(input.data);
        }
        const parsedType = this._getType(input);
        if (parsedType !== ZodParsedType.bigint) {
            const ctx = this._getOrReturnCtx(input);
            addIssueToContext(ctx, {
                code: ZodIssueCode.invalid_type,
                expected: ZodParsedType.bigint,
                received: ctx.parsedType,
            });
            return INVALID;
        }
        let ctx = undefined;
        const status = new ParseStatus();
        for (const check of this._def.checks) {
            if (check.kind === "min") {
                const tooSmall = check.inclusive
                    ? input.data < check.value
                    : input.data <= check.value;
                if (tooSmall) {
                    ctx = this._getOrReturnCtx(input, ctx);
                    addIssueToContext(ctx, {
                        code: ZodIssueCode.too_small,
                        type: "bigint",
                        minimum: check.value,
                        inclusive: check.inclusive,
                        message: check.message,
                    });
                    status.dirty();
                }
            }
            else if (check.kind === "max") {
                const tooBig = check.inclusive
                    ? input.data > check.value
                    : input.data >= check.value;
                if (tooBig) {
                    ctx = this._getOrReturnCtx(input, ctx);
                    addIssueToContext(ctx, {
                        code: ZodIssueCode.too_big,
                        type: "bigint",
                        maximum: check.value,
                        inclusive: check.inclusive,
                        message: check.message,
                    });
                    status.dirty();
                }
            }
            else if (check.kind === "multipleOf") {
                if (input.data % check.value !== BigInt(0)) {
                    ctx = this._getOrReturnCtx(input, ctx);
                    addIssueToContext(ctx, {
                        code: ZodIssueCode.not_multiple_of,
                        multipleOf: check.value,
                        message: check.message,
                    });
                    status.dirty();
                }
            }
            else {
                util$1.assertNever(check);
            }
        }
        return { status: status.value, value: input.data };
    }
    gte(value, message) {
        return this.setLimit("min", value, true, errorUtil.toString(message));
    }
    gt(value, message) {
        return this.setLimit("min", value, false, errorUtil.toString(message));
    }
    lte(value, message) {
        return this.setLimit("max", value, true, errorUtil.toString(message));
    }
    lt(value, message) {
        return this.setLimit("max", value, false, errorUtil.toString(message));
    }
    setLimit(kind, value, inclusive, message) {
        return new ZodBigInt({
            ...this._def,
            checks: [
                ...this._def.checks,
                {
                    kind,
                    value,
                    inclusive,
                    message: errorUtil.toString(message),
                },
            ],
        });
    }
    _addCheck(check) {
        return new ZodBigInt({
            ...this._def,
            checks: [...this._def.checks, check],
        });
    }
    positive(message) {
        return this._addCheck({
            kind: "min",
            value: BigInt(0),
            inclusive: false,
            message: errorUtil.toString(message),
        });
    }
    negative(message) {
        return this._addCheck({
            kind: "max",
            value: BigInt(0),
            inclusive: false,
            message: errorUtil.toString(message),
        });
    }
    nonpositive(message) {
        return this._addCheck({
            kind: "max",
            value: BigInt(0),
            inclusive: true,
            message: errorUtil.toString(message),
        });
    }
    nonnegative(message) {
        return this._addCheck({
            kind: "min",
            value: BigInt(0),
            inclusive: true,
            message: errorUtil.toString(message),
        });
    }
    multipleOf(value, message) {
        return this._addCheck({
            kind: "multipleOf",
            value,
            message: errorUtil.toString(message),
        });
    }
    get minValue() {
        let min = null;
        for (const ch of this._def.checks) {
            if (ch.kind === "min") {
                if (min === null || ch.value > min)
                    min = ch.value;
            }
        }
        return min;
    }
    get maxValue() {
        let max = null;
        for (const ch of this._def.checks) {
            if (ch.kind === "max") {
                if (max === null || ch.value < max)
                    max = ch.value;
            }
        }
        return max;
    }
}
ZodBigInt.create = (params) => {
    var _a;
    return new ZodBigInt({
        checks: [],
        typeName: ZodFirstPartyTypeKind.ZodBigInt,
        coerce: (_a = params === null || params === void 0 ? void 0 : params.coerce) !== null && _a !== void 0 ? _a : false,
        ...processCreateParams(params),
    });
};
class ZodBoolean extends ZodType {
    _parse(input) {
        if (this._def.coerce) {
            input.data = Boolean(input.data);
        }
        const parsedType = this._getType(input);
        if (parsedType !== ZodParsedType.boolean) {
            const ctx = this._getOrReturnCtx(input);
            addIssueToContext(ctx, {
                code: ZodIssueCode.invalid_type,
                expected: ZodParsedType.boolean,
                received: ctx.parsedType,
            });
            return INVALID;
        }
        return OK(input.data);
    }
}
ZodBoolean.create = (params) => {
    return new ZodBoolean({
        typeName: ZodFirstPartyTypeKind.ZodBoolean,
        coerce: (params === null || params === void 0 ? void 0 : params.coerce) || false,
        ...processCreateParams(params),
    });
};
class ZodDate extends ZodType {
    _parse(input) {
        if (this._def.coerce) {
            input.data = new Date(input.data);
        }
        const parsedType = this._getType(input);
        if (parsedType !== ZodParsedType.date) {
            const ctx = this._getOrReturnCtx(input);
            addIssueToContext(ctx, {
                code: ZodIssueCode.invalid_type,
                expected: ZodParsedType.date,
                received: ctx.parsedType,
            });
            return INVALID;
        }
        if (isNaN(input.data.getTime())) {
            const ctx = this._getOrReturnCtx(input);
            addIssueToContext(ctx, {
                code: ZodIssueCode.invalid_date,
            });
            return INVALID;
        }
        const status = new ParseStatus();
        let ctx = undefined;
        for (const check of this._def.checks) {
            if (check.kind === "min") {
                if (input.data.getTime() < check.value) {
                    ctx = this._getOrReturnCtx(input, ctx);
                    addIssueToContext(ctx, {
                        code: ZodIssueCode.too_small,
                        message: check.message,
                        inclusive: true,
                        exact: false,
                        minimum: check.value,
                        type: "date",
                    });
                    status.dirty();
                }
            }
            else if (check.kind === "max") {
                if (input.data.getTime() > check.value) {
                    ctx = this._getOrReturnCtx(input, ctx);
                    addIssueToContext(ctx, {
                        code: ZodIssueCode.too_big,
                        message: check.message,
                        inclusive: true,
                        exact: false,
                        maximum: check.value,
                        type: "date",
                    });
                    status.dirty();
                }
            }
            else {
                util$1.assertNever(check);
            }
        }
        return {
            status: status.value,
            value: new Date(input.data.getTime()),
        };
    }
    _addCheck(check) {
        return new ZodDate({
            ...this._def,
            checks: [...this._def.checks, check],
        });
    }
    min(minDate, message) {
        return this._addCheck({
            kind: "min",
            value: minDate.getTime(),
            message: errorUtil.toString(message),
        });
    }
    max(maxDate, message) {
        return this._addCheck({
            kind: "max",
            value: maxDate.getTime(),
            message: errorUtil.toString(message),
        });
    }
    get minDate() {
        let min = null;
        for (const ch of this._def.checks) {
            if (ch.kind === "min") {
                if (min === null || ch.value > min)
                    min = ch.value;
            }
        }
        return min != null ? new Date(min) : null;
    }
    get maxDate() {
        let max = null;
        for (const ch of this._def.checks) {
            if (ch.kind === "max") {
                if (max === null || ch.value < max)
                    max = ch.value;
            }
        }
        return max != null ? new Date(max) : null;
    }
}
ZodDate.create = (params) => {
    return new ZodDate({
        checks: [],
        coerce: (params === null || params === void 0 ? void 0 : params.coerce) || false,
        typeName: ZodFirstPartyTypeKind.ZodDate,
        ...processCreateParams(params),
    });
};
class ZodSymbol extends ZodType {
    _parse(input) {
        const parsedType = this._getType(input);
        if (parsedType !== ZodParsedType.symbol) {
            const ctx = this._getOrReturnCtx(input);
            addIssueToContext(ctx, {
                code: ZodIssueCode.invalid_type,
                expected: ZodParsedType.symbol,
                received: ctx.parsedType,
            });
            return INVALID;
        }
        return OK(input.data);
    }
}
ZodSymbol.create = (params) => {
    return new ZodSymbol({
        typeName: ZodFirstPartyTypeKind.ZodSymbol,
        ...processCreateParams(params),
    });
};
class ZodUndefined extends ZodType {
    _parse(input) {
        const parsedType = this._getType(input);
        if (parsedType !== ZodParsedType.undefined) {
            const ctx = this._getOrReturnCtx(input);
            addIssueToContext(ctx, {
                code: ZodIssueCode.invalid_type,
                expected: ZodParsedType.undefined,
                received: ctx.parsedType,
            });
            return INVALID;
        }
        return OK(input.data);
    }
}
ZodUndefined.create = (params) => {
    return new ZodUndefined({
        typeName: ZodFirstPartyTypeKind.ZodUndefined,
        ...processCreateParams(params),
    });
};
class ZodNull extends ZodType {
    _parse(input) {
        const parsedType = this._getType(input);
        if (parsedType !== ZodParsedType.null) {
            const ctx = this._getOrReturnCtx(input);
            addIssueToContext(ctx, {
                code: ZodIssueCode.invalid_type,
                expected: ZodParsedType.null,
                received: ctx.parsedType,
            });
            return INVALID;
        }
        return OK(input.data);
    }
}
ZodNull.create = (params) => {
    return new ZodNull({
        typeName: ZodFirstPartyTypeKind.ZodNull,
        ...processCreateParams(params),
    });
};
class ZodAny extends ZodType {
    constructor() {
        super(...arguments);
        // to prevent instances of other classes from extending ZodAny. this causes issues with catchall in ZodObject.
        this._any = true;
    }
    _parse(input) {
        return OK(input.data);
    }
}
ZodAny.create = (params) => {
    return new ZodAny({
        typeName: ZodFirstPartyTypeKind.ZodAny,
        ...processCreateParams(params),
    });
};
class ZodUnknown extends ZodType {
    constructor() {
        super(...arguments);
        // required
        this._unknown = true;
    }
    _parse(input) {
        return OK(input.data);
    }
}
ZodUnknown.create = (params) => {
    return new ZodUnknown({
        typeName: ZodFirstPartyTypeKind.ZodUnknown,
        ...processCreateParams(params),
    });
};
class ZodNever extends ZodType {
    _parse(input) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_type,
            expected: ZodParsedType.never,
            received: ctx.parsedType,
        });
        return INVALID;
    }
}
ZodNever.create = (params) => {
    return new ZodNever({
        typeName: ZodFirstPartyTypeKind.ZodNever,
        ...processCreateParams(params),
    });
};
class ZodVoid extends ZodType {
    _parse(input) {
        const parsedType = this._getType(input);
        if (parsedType !== ZodParsedType.undefined) {
            const ctx = this._getOrReturnCtx(input);
            addIssueToContext(ctx, {
                code: ZodIssueCode.invalid_type,
                expected: ZodParsedType.void,
                received: ctx.parsedType,
            });
            return INVALID;
        }
        return OK(input.data);
    }
}
ZodVoid.create = (params) => {
    return new ZodVoid({
        typeName: ZodFirstPartyTypeKind.ZodVoid,
        ...processCreateParams(params),
    });
};
class ZodArray extends ZodType {
    _parse(input) {
        const { ctx, status } = this._processInputParams(input);
        const def = this._def;
        if (ctx.parsedType !== ZodParsedType.array) {
            addIssueToContext(ctx, {
                code: ZodIssueCode.invalid_type,
                expected: ZodParsedType.array,
                received: ctx.parsedType,
            });
            return INVALID;
        }
        if (def.exactLength !== null) {
            const tooBig = ctx.data.length > def.exactLength.value;
            const tooSmall = ctx.data.length < def.exactLength.value;
            if (tooBig || tooSmall) {
                addIssueToContext(ctx, {
                    code: tooBig ? ZodIssueCode.too_big : ZodIssueCode.too_small,
                    minimum: (tooSmall ? def.exactLength.value : undefined),
                    maximum: (tooBig ? def.exactLength.value : undefined),
                    type: "array",
                    inclusive: true,
                    exact: true,
                    message: def.exactLength.message,
                });
                status.dirty();
            }
        }
        if (def.minLength !== null) {
            if (ctx.data.length < def.minLength.value) {
                addIssueToContext(ctx, {
                    code: ZodIssueCode.too_small,
                    minimum: def.minLength.value,
                    type: "array",
                    inclusive: true,
                    exact: false,
                    message: def.minLength.message,
                });
                status.dirty();
            }
        }
        if (def.maxLength !== null) {
            if (ctx.data.length > def.maxLength.value) {
                addIssueToContext(ctx, {
                    code: ZodIssueCode.too_big,
                    maximum: def.maxLength.value,
                    type: "array",
                    inclusive: true,
                    exact: false,
                    message: def.maxLength.message,
                });
                status.dirty();
            }
        }
        if (ctx.common.async) {
            return Promise.all([...ctx.data].map((item, i) => {
                return def.type._parseAsync(new ParseInputLazyPath(ctx, item, ctx.path, i));
            })).then((result) => {
                return ParseStatus.mergeArray(status, result);
            });
        }
        const result = [...ctx.data].map((item, i) => {
            return def.type._parseSync(new ParseInputLazyPath(ctx, item, ctx.path, i));
        });
        return ParseStatus.mergeArray(status, result);
    }
    get element() {
        return this._def.type;
    }
    min(minLength, message) {
        return new ZodArray({
            ...this._def,
            minLength: { value: minLength, message: errorUtil.toString(message) },
        });
    }
    max(maxLength, message) {
        return new ZodArray({
            ...this._def,
            maxLength: { value: maxLength, message: errorUtil.toString(message) },
        });
    }
    length(len, message) {
        return new ZodArray({
            ...this._def,
            exactLength: { value: len, message: errorUtil.toString(message) },
        });
    }
    nonempty(message) {
        return this.min(1, message);
    }
}
ZodArray.create = (schema, params) => {
    return new ZodArray({
        type: schema,
        minLength: null,
        maxLength: null,
        exactLength: null,
        typeName: ZodFirstPartyTypeKind.ZodArray,
        ...processCreateParams(params),
    });
};
function deepPartialify(schema) {
    if (schema instanceof ZodObject) {
        const newShape = {};
        for (const key in schema.shape) {
            const fieldSchema = schema.shape[key];
            newShape[key] = ZodOptional.create(deepPartialify(fieldSchema));
        }
        return new ZodObject({
            ...schema._def,
            shape: () => newShape,
        });
    }
    else if (schema instanceof ZodArray) {
        return new ZodArray({
            ...schema._def,
            type: deepPartialify(schema.element),
        });
    }
    else if (schema instanceof ZodOptional) {
        return ZodOptional.create(deepPartialify(schema.unwrap()));
    }
    else if (schema instanceof ZodNullable) {
        return ZodNullable.create(deepPartialify(schema.unwrap()));
    }
    else if (schema instanceof ZodTuple) {
        return ZodTuple.create(schema.items.map((item) => deepPartialify(item)));
    }
    else {
        return schema;
    }
}
class ZodObject extends ZodType {
    constructor() {
        super(...arguments);
        this._cached = null;
        /**
         * @deprecated In most cases, this is no longer needed - unknown properties are now silently stripped.
         * If you want to pass through unknown properties, use `.passthrough()` instead.
         */
        this.nonstrict = this.passthrough;
        // extend<
        //   Augmentation extends ZodRawShape,
        //   NewOutput extends util.flatten<{
        //     [k in keyof Augmentation | keyof Output]: k extends keyof Augmentation
        //       ? Augmentation[k]["_output"]
        //       : k extends keyof Output
        //       ? Output[k]
        //       : never;
        //   }>,
        //   NewInput extends util.flatten<{
        //     [k in keyof Augmentation | keyof Input]: k extends keyof Augmentation
        //       ? Augmentation[k]["_input"]
        //       : k extends keyof Input
        //       ? Input[k]
        //       : never;
        //   }>
        // >(
        //   augmentation: Augmentation
        // ): ZodObject<
        //   extendShape<T, Augmentation>,
        //   UnknownKeys,
        //   Catchall,
        //   NewOutput,
        //   NewInput
        // > {
        //   return new ZodObject({
        //     ...this._def,
        //     shape: () => ({
        //       ...this._def.shape(),
        //       ...augmentation,
        //     }),
        //   }) as any;
        // }
        /**
         * @deprecated Use `.extend` instead
         *  */
        this.augment = this.extend;
    }
    _getCached() {
        if (this._cached !== null)
            return this._cached;
        const shape = this._def.shape();
        const keys = util$1.objectKeys(shape);
        return (this._cached = { shape, keys });
    }
    _parse(input) {
        const parsedType = this._getType(input);
        if (parsedType !== ZodParsedType.object) {
            const ctx = this._getOrReturnCtx(input);
            addIssueToContext(ctx, {
                code: ZodIssueCode.invalid_type,
                expected: ZodParsedType.object,
                received: ctx.parsedType,
            });
            return INVALID;
        }
        const { status, ctx } = this._processInputParams(input);
        const { shape, keys: shapeKeys } = this._getCached();
        const extraKeys = [];
        if (!(this._def.catchall instanceof ZodNever &&
            this._def.unknownKeys === "strip")) {
            for (const key in ctx.data) {
                if (!shapeKeys.includes(key)) {
                    extraKeys.push(key);
                }
            }
        }
        const pairs = [];
        for (const key of shapeKeys) {
            const keyValidator = shape[key];
            const value = ctx.data[key];
            pairs.push({
                key: { status: "valid", value: key },
                value: keyValidator._parse(new ParseInputLazyPath(ctx, value, ctx.path, key)),
                alwaysSet: key in ctx.data,
            });
        }
        if (this._def.catchall instanceof ZodNever) {
            const unknownKeys = this._def.unknownKeys;
            if (unknownKeys === "passthrough") {
                for (const key of extraKeys) {
                    pairs.push({
                        key: { status: "valid", value: key },
                        value: { status: "valid", value: ctx.data[key] },
                    });
                }
            }
            else if (unknownKeys === "strict") {
                if (extraKeys.length > 0) {
                    addIssueToContext(ctx, {
                        code: ZodIssueCode.unrecognized_keys,
                        keys: extraKeys,
                    });
                    status.dirty();
                }
            }
            else if (unknownKeys === "strip") ;
            else {
                throw new Error(`Internal ZodObject error: invalid unknownKeys value.`);
            }
        }
        else {
            // run catchall validation
            const catchall = this._def.catchall;
            for (const key of extraKeys) {
                const value = ctx.data[key];
                pairs.push({
                    key: { status: "valid", value: key },
                    value: catchall._parse(new ParseInputLazyPath(ctx, value, ctx.path, key) //, ctx.child(key), value, getParsedType(value)
                    ),
                    alwaysSet: key in ctx.data,
                });
            }
        }
        if (ctx.common.async) {
            return Promise.resolve()
                .then(async () => {
                const syncPairs = [];
                for (const pair of pairs) {
                    const key = await pair.key;
                    const value = await pair.value;
                    syncPairs.push({
                        key,
                        value,
                        alwaysSet: pair.alwaysSet,
                    });
                }
                return syncPairs;
            })
                .then((syncPairs) => {
                return ParseStatus.mergeObjectSync(status, syncPairs);
            });
        }
        else {
            return ParseStatus.mergeObjectSync(status, pairs);
        }
    }
    get shape() {
        return this._def.shape();
    }
    strict(message) {
        errorUtil.errToObj;
        return new ZodObject({
            ...this._def,
            unknownKeys: "strict",
            ...(message !== undefined
                ? {
                    errorMap: (issue, ctx) => {
                        var _a, _b, _c, _d;
                        const defaultError = (_c = (_b = (_a = this._def).errorMap) === null || _b === void 0 ? void 0 : _b.call(_a, issue, ctx).message) !== null && _c !== void 0 ? _c : ctx.defaultError;
                        if (issue.code === "unrecognized_keys")
                            return {
                                message: (_d = errorUtil.errToObj(message).message) !== null && _d !== void 0 ? _d : defaultError,
                            };
                        return {
                            message: defaultError,
                        };
                    },
                }
                : {}),
        });
    }
    strip() {
        return new ZodObject({
            ...this._def,
            unknownKeys: "strip",
        });
    }
    passthrough() {
        return new ZodObject({
            ...this._def,
            unknownKeys: "passthrough",
        });
    }
    // const AugmentFactory =
    //   <Def extends ZodObjectDef>(def: Def) =>
    //   <Augmentation extends ZodRawShape>(
    //     augmentation: Augmentation
    //   ): ZodObject<
    //     extendShape<ReturnType<Def["shape"]>, Augmentation>,
    //     Def["unknownKeys"],
    //     Def["catchall"]
    //   > => {
    //     return new ZodObject({
    //       ...def,
    //       shape: () => ({
    //         ...def.shape(),
    //         ...augmentation,
    //       }),
    //     }) as any;
    //   };
    extend(augmentation) {
        return new ZodObject({
            ...this._def,
            shape: () => ({
                ...this._def.shape(),
                ...augmentation,
            }),
        });
    }
    /**
     * Prior to zod@1.0.12 there was a bug in the
     * inferred type of merged objects. Please
     * upgrade if you are experiencing issues.
     */
    merge(merging) {
        const merged = new ZodObject({
            unknownKeys: merging._def.unknownKeys,
            catchall: merging._def.catchall,
            shape: () => ({
                ...this._def.shape(),
                ...merging._def.shape(),
            }),
            typeName: ZodFirstPartyTypeKind.ZodObject,
        });
        return merged;
    }
    // merge<
    //   Incoming extends AnyZodObject,
    //   Augmentation extends Incoming["shape"],
    //   NewOutput extends {
    //     [k in keyof Augmentation | keyof Output]: k extends keyof Augmentation
    //       ? Augmentation[k]["_output"]
    //       : k extends keyof Output
    //       ? Output[k]
    //       : never;
    //   },
    //   NewInput extends {
    //     [k in keyof Augmentation | keyof Input]: k extends keyof Augmentation
    //       ? Augmentation[k]["_input"]
    //       : k extends keyof Input
    //       ? Input[k]
    //       : never;
    //   }
    // >(
    //   merging: Incoming
    // ): ZodObject<
    //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
    //   Incoming["_def"]["unknownKeys"],
    //   Incoming["_def"]["catchall"],
    //   NewOutput,
    //   NewInput
    // > {
    //   const merged: any = new ZodObject({
    //     unknownKeys: merging._def.unknownKeys,
    //     catchall: merging._def.catchall,
    //     shape: () =>
    //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
    //     typeName: ZodFirstPartyTypeKind.ZodObject,
    //   }) as any;
    //   return merged;
    // }
    setKey(key, schema) {
        return this.augment({ [key]: schema });
    }
    // merge<Incoming extends AnyZodObject>(
    //   merging: Incoming
    // ): //ZodObject<T & Incoming["_shape"], UnknownKeys, Catchall> = (merging) => {
    // ZodObject<
    //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
    //   Incoming["_def"]["unknownKeys"],
    //   Incoming["_def"]["catchall"]
    // > {
    //   // const mergedShape = objectUtil.mergeShapes(
    //   //   this._def.shape(),
    //   //   merging._def.shape()
    //   // );
    //   const merged: any = new ZodObject({
    //     unknownKeys: merging._def.unknownKeys,
    //     catchall: merging._def.catchall,
    //     shape: () =>
    //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
    //     typeName: ZodFirstPartyTypeKind.ZodObject,
    //   }) as any;
    //   return merged;
    // }
    catchall(index) {
        return new ZodObject({
            ...this._def,
            catchall: index,
        });
    }
    pick(mask) {
        const shape = {};
        util$1.objectKeys(mask).forEach((key) => {
            if (mask[key] && this.shape[key]) {
                shape[key] = this.shape[key];
            }
        });
        return new ZodObject({
            ...this._def,
            shape: () => shape,
        });
    }
    omit(mask) {
        const shape = {};
        util$1.objectKeys(this.shape).forEach((key) => {
            if (!mask[key]) {
                shape[key] = this.shape[key];
            }
        });
        return new ZodObject({
            ...this._def,
            shape: () => shape,
        });
    }
    /**
     * @deprecated
     */
    deepPartial() {
        return deepPartialify(this);
    }
    partial(mask) {
        const newShape = {};
        util$1.objectKeys(this.shape).forEach((key) => {
            const fieldSchema = this.shape[key];
            if (mask && !mask[key]) {
                newShape[key] = fieldSchema;
            }
            else {
                newShape[key] = fieldSchema.optional();
            }
        });
        return new ZodObject({
            ...this._def,
            shape: () => newShape,
        });
    }
    required(mask) {
        const newShape = {};
        util$1.objectKeys(this.shape).forEach((key) => {
            if (mask && !mask[key]) {
                newShape[key] = this.shape[key];
            }
            else {
                const fieldSchema = this.shape[key];
                let newField = fieldSchema;
                while (newField instanceof ZodOptional) {
                    newField = newField._def.innerType;
                }
                newShape[key] = newField;
            }
        });
        return new ZodObject({
            ...this._def,
            shape: () => newShape,
        });
    }
    keyof() {
        return createZodEnum(util$1.objectKeys(this.shape));
    }
}
ZodObject.create = (shape, params) => {
    return new ZodObject({
        shape: () => shape,
        unknownKeys: "strip",
        catchall: ZodNever.create(),
        typeName: ZodFirstPartyTypeKind.ZodObject,
        ...processCreateParams(params),
    });
};
ZodObject.strictCreate = (shape, params) => {
    return new ZodObject({
        shape: () => shape,
        unknownKeys: "strict",
        catchall: ZodNever.create(),
        typeName: ZodFirstPartyTypeKind.ZodObject,
        ...processCreateParams(params),
    });
};
ZodObject.lazycreate = (shape, params) => {
    return new ZodObject({
        shape,
        unknownKeys: "strip",
        catchall: ZodNever.create(),
        typeName: ZodFirstPartyTypeKind.ZodObject,
        ...processCreateParams(params),
    });
};
class ZodUnion extends ZodType {
    _parse(input) {
        const { ctx } = this._processInputParams(input);
        const options = this._def.options;
        function handleResults(results) {
            // return first issue-free validation if it exists
            for (const result of results) {
                if (result.result.status === "valid") {
                    return result.result;
                }
            }
            for (const result of results) {
                if (result.result.status === "dirty") {
                    // add issues from dirty option
                    ctx.common.issues.push(...result.ctx.common.issues);
                    return result.result;
                }
            }
            // return invalid
            const unionErrors = results.map((result) => new ZodError(result.ctx.common.issues));
            addIssueToContext(ctx, {
                code: ZodIssueCode.invalid_union,
                unionErrors,
            });
            return INVALID;
        }
        if (ctx.common.async) {
            return Promise.all(options.map(async (option) => {
                const childCtx = {
                    ...ctx,
                    common: {
                        ...ctx.common,
                        issues: [],
                    },
                    parent: null,
                };
                return {
                    result: await option._parseAsync({
                        data: ctx.data,
                        path: ctx.path,
                        parent: childCtx,
                    }),
                    ctx: childCtx,
                };
            })).then(handleResults);
        }
        else {
            let dirty = undefined;
            const issues = [];
            for (const option of options) {
                const childCtx = {
                    ...ctx,
                    common: {
                        ...ctx.common,
                        issues: [],
                    },
                    parent: null,
                };
                const result = option._parseSync({
                    data: ctx.data,
                    path: ctx.path,
                    parent: childCtx,
                });
                if (result.status === "valid") {
                    return result;
                }
                else if (result.status === "dirty" && !dirty) {
                    dirty = { result, ctx: childCtx };
                }
                if (childCtx.common.issues.length) {
                    issues.push(childCtx.common.issues);
                }
            }
            if (dirty) {
                ctx.common.issues.push(...dirty.ctx.common.issues);
                return dirty.result;
            }
            const unionErrors = issues.map((issues) => new ZodError(issues));
            addIssueToContext(ctx, {
                code: ZodIssueCode.invalid_union,
                unionErrors,
            });
            return INVALID;
        }
    }
    get options() {
        return this._def.options;
    }
}
ZodUnion.create = (types, params) => {
    return new ZodUnion({
        options: types,
        typeName: ZodFirstPartyTypeKind.ZodUnion,
        ...processCreateParams(params),
    });
};
/////////////////////////////////////////////////////
/////////////////////////////////////////////////////
//////////                                 //////////
//////////      ZodDiscriminatedUnion      //////////
//////////                                 //////////
/////////////////////////////////////////////////////
/////////////////////////////////////////////////////
const getDiscriminator = (type) => {
    if (type instanceof ZodLazy) {
        return getDiscriminator(type.schema);
    }
    else if (type instanceof ZodEffects) {
        return getDiscriminator(type.innerType());
    }
    else if (type instanceof ZodLiteral) {
        return [type.value];
    }
    else if (type instanceof ZodEnum) {
        return type.options;
    }
    else if (type instanceof ZodNativeEnum) {
        // eslint-disable-next-line ban/ban
        return util$1.objectValues(type.enum);
    }
    else if (type instanceof ZodDefault) {
        return getDiscriminator(type._def.innerType);
    }
    else if (type instanceof ZodUndefined) {
        return [undefined];
    }
    else if (type instanceof ZodNull) {
        return [null];
    }
    else if (type instanceof ZodOptional) {
        return [undefined, ...getDiscriminator(type.unwrap())];
    }
    else if (type instanceof ZodNullable) {
        return [null, ...getDiscriminator(type.unwrap())];
    }
    else if (type instanceof ZodBranded) {
        return getDiscriminator(type.unwrap());
    }
    else if (type instanceof ZodReadonly) {
        return getDiscriminator(type.unwrap());
    }
    else if (type instanceof ZodCatch) {
        return getDiscriminator(type._def.innerType);
    }
    else {
        return [];
    }
};
class ZodDiscriminatedUnion extends ZodType {
    _parse(input) {
        const { ctx } = this._processInputParams(input);
        if (ctx.parsedType !== ZodParsedType.object) {
            addIssueToContext(ctx, {
                code: ZodIssueCode.invalid_type,
                expected: ZodParsedType.object,
                received: ctx.parsedType,
            });
            return INVALID;
        }
        const discriminator = this.discriminator;
        const discriminatorValue = ctx.data[discriminator];
        const option = this.optionsMap.get(discriminatorValue);
        if (!option) {
            addIssueToContext(ctx, {
                code: ZodIssueCode.invalid_union_discriminator,
                options: Array.from(this.optionsMap.keys()),
                path: [discriminator],
            });
            return INVALID;
        }
        if (ctx.common.async) {
            return option._parseAsync({
                data: ctx.data,
                path: ctx.path,
                parent: ctx,
            });
        }
        else {
            return option._parseSync({
                data: ctx.data,
                path: ctx.path,
                parent: ctx,
            });
        }
    }
    get discriminator() {
        return this._def.discriminator;
    }
    get options() {
        return this._def.options;
    }
    get optionsMap() {
        return this._def.optionsMap;
    }
    /**
     * The constructor of the discriminated union schema. Its behaviour is very similar to that of the normal z.union() constructor.
     * However, it only allows a union of objects, all of which need to share a discriminator property. This property must
     * have a different value for each object in the union.
     * @param discriminator the name of the discriminator property
     * @param types an array of object schemas
     * @param params
     */
    static create(discriminator, options, params) {
        // Get all the valid discriminator values
        const optionsMap = new Map();
        // try {
        for (const type of options) {
            const discriminatorValues = getDiscriminator(type.shape[discriminator]);
            if (!discriminatorValues.length) {
                throw new Error(`A discriminator value for key \`${discriminator}\` could not be extracted from all schema options`);
            }
            for (const value of discriminatorValues) {
                if (optionsMap.has(value)) {
                    throw new Error(`Discriminator property ${String(discriminator)} has duplicate value ${String(value)}`);
                }
                optionsMap.set(value, type);
            }
        }
        return new ZodDiscriminatedUnion({
            typeName: ZodFirstPartyTypeKind.ZodDiscriminatedUnion,
            discriminator,
            options,
            optionsMap,
            ...processCreateParams(params),
        });
    }
}
function mergeValues(a, b) {
    const aType = getParsedType(a);
    const bType = getParsedType(b);
    if (a === b) {
        return { valid: true, data: a };
    }
    else if (aType === ZodParsedType.object && bType === ZodParsedType.object) {
        const bKeys = util$1.objectKeys(b);
        const sharedKeys = util$1
            .objectKeys(a)
            .filter((key) => bKeys.indexOf(key) !== -1);
        const newObj = { ...a, ...b };
        for (const key of sharedKeys) {
            const sharedValue = mergeValues(a[key], b[key]);
            if (!sharedValue.valid) {
                return { valid: false };
            }
            newObj[key] = sharedValue.data;
        }
        return { valid: true, data: newObj };
    }
    else if (aType === ZodParsedType.array && bType === ZodParsedType.array) {
        if (a.length !== b.length) {
            return { valid: false };
        }
        const newArray = [];
        for (let index = 0; index < a.length; index++) {
            const itemA = a[index];
            const itemB = b[index];
            const sharedValue = mergeValues(itemA, itemB);
            if (!sharedValue.valid) {
                return { valid: false };
            }
            newArray.push(sharedValue.data);
        }
        return { valid: true, data: newArray };
    }
    else if (aType === ZodParsedType.date &&
        bType === ZodParsedType.date &&
        +a === +b) {
        return { valid: true, data: a };
    }
    else {
        return { valid: false };
    }
}
class ZodIntersection extends ZodType {
    _parse(input) {
        const { status, ctx } = this._processInputParams(input);
        const handleParsed = (parsedLeft, parsedRight) => {
            if (isAborted(parsedLeft) || isAborted(parsedRight)) {
                return INVALID;
            }
            const merged = mergeValues(parsedLeft.value, parsedRight.value);
            if (!merged.valid) {
                addIssueToContext(ctx, {
                    code: ZodIssueCode.invalid_intersection_types,
                });
                return INVALID;
            }
            if (isDirty(parsedLeft) || isDirty(parsedRight)) {
                status.dirty();
            }
            return { status: status.value, value: merged.data };
        };
        if (ctx.common.async) {
            return Promise.all([
                this._def.left._parseAsync({
                    data: ctx.data,
                    path: ctx.path,
                    parent: ctx,
                }),
                this._def.right._parseAsync({
                    data: ctx.data,
                    path: ctx.path,
                    parent: ctx,
                }),
            ]).then(([left, right]) => handleParsed(left, right));
        }
        else {
            return handleParsed(this._def.left._parseSync({
                data: ctx.data,
                path: ctx.path,
                parent: ctx,
            }), this._def.right._parseSync({
                data: ctx.data,
                path: ctx.path,
                parent: ctx,
            }));
        }
    }
}
ZodIntersection.create = (left, right, params) => {
    return new ZodIntersection({
        left: left,
        right: right,
        typeName: ZodFirstPartyTypeKind.ZodIntersection,
        ...processCreateParams(params),
    });
};
class ZodTuple extends ZodType {
    _parse(input) {
        const { status, ctx } = this._processInputParams(input);
        if (ctx.parsedType !== ZodParsedType.array) {
            addIssueToContext(ctx, {
                code: ZodIssueCode.invalid_type,
                expected: ZodParsedType.array,
                received: ctx.parsedType,
            });
            return INVALID;
        }
        if (ctx.data.length < this._def.items.length) {
            addIssueToContext(ctx, {
                code: ZodIssueCode.too_small,
                minimum: this._def.items.length,
                inclusive: true,
                exact: false,
                type: "array",
            });
            return INVALID;
        }
        const rest = this._def.rest;
        if (!rest && ctx.data.length > this._def.items.length) {
            addIssueToContext(ctx, {
                code: ZodIssueCode.too_big,
                maximum: this._def.items.length,
                inclusive: true,
                exact: false,
                type: "array",
            });
            status.dirty();
        }
        const items = [...ctx.data]
            .map((item, itemIndex) => {
            const schema = this._def.items[itemIndex] || this._def.rest;
            if (!schema)
                return null;
            return schema._parse(new ParseInputLazyPath(ctx, item, ctx.path, itemIndex));
        })
            .filter((x) => !!x); // filter nulls
        if (ctx.common.async) {
            return Promise.all(items).then((results) => {
                return ParseStatus.mergeArray(status, results);
            });
        }
        else {
            return ParseStatus.mergeArray(status, items);
        }
    }
    get items() {
        return this._def.items;
    }
    rest(rest) {
        return new ZodTuple({
            ...this._def,
            rest,
        });
    }
}
ZodTuple.create = (schemas, params) => {
    if (!Array.isArray(schemas)) {
        throw new Error("You must pass an array of schemas to z.tuple([ ... ])");
    }
    return new ZodTuple({
        items: schemas,
        typeName: ZodFirstPartyTypeKind.ZodTuple,
        rest: null,
        ...processCreateParams(params),
    });
};
class ZodRecord extends ZodType {
    get keySchema() {
        return this._def.keyType;
    }
    get valueSchema() {
        return this._def.valueType;
    }
    _parse(input) {
        const { status, ctx } = this._processInputParams(input);
        if (ctx.parsedType !== ZodParsedType.object) {
            addIssueToContext(ctx, {
                code: ZodIssueCode.invalid_type,
                expected: ZodParsedType.object,
                received: ctx.parsedType,
            });
            return INVALID;
        }
        const pairs = [];
        const keyType = this._def.keyType;
        const valueType = this._def.valueType;
        for (const key in ctx.data) {
            pairs.push({
                key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, key)),
                value: valueType._parse(new ParseInputLazyPath(ctx, ctx.data[key], ctx.path, key)),
                alwaysSet: key in ctx.data,
            });
        }
        if (ctx.common.async) {
            return ParseStatus.mergeObjectAsync(status, pairs);
        }
        else {
            return ParseStatus.mergeObjectSync(status, pairs);
        }
    }
    get element() {
        return this._def.valueType;
    }
    static create(first, second, third) {
        if (second instanceof ZodType) {
            return new ZodRecord({
                keyType: first,
                valueType: second,
                typeName: ZodFirstPartyTypeKind.ZodRecord,
                ...processCreateParams(third),
            });
        }
        return new ZodRecord({
            keyType: ZodString.create(),
            valueType: first,
            typeName: ZodFirstPartyTypeKind.ZodRecord,
            ...processCreateParams(second),
        });
    }
}
class ZodMap extends ZodType {
    get keySchema() {
        return this._def.keyType;
    }
    get valueSchema() {
        return this._def.valueType;
    }
    _parse(input) {
        const { status, ctx } = this._processInputParams(input);
        if (ctx.parsedType !== ZodParsedType.map) {
            addIssueToContext(ctx, {
                code: ZodIssueCode.invalid_type,
                expected: ZodParsedType.map,
                received: ctx.parsedType,
            });
            return INVALID;
        }
        const keyType = this._def.keyType;
        const valueType = this._def.valueType;
        const pairs = [...ctx.data.entries()].map(([key, value], index) => {
            return {
                key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, [index, "key"])),
                value: valueType._parse(new ParseInputLazyPath(ctx, value, ctx.path, [index, "value"])),
            };
        });
        if (ctx.common.async) {
            const finalMap = new Map();
            return Promise.resolve().then(async () => {
                for (const pair of pairs) {
                    const key = await pair.key;
                    const value = await pair.value;
                    if (key.status === "aborted" || value.status === "aborted") {
                        return INVALID;
                    }
                    if (key.status === "dirty" || value.status === "dirty") {
                        status.dirty();
                    }
                    finalMap.set(key.value, value.value);
                }
                return { status: status.value, value: finalMap };
            });
        }
        else {
            const finalMap = new Map();
            for (const pair of pairs) {
                const key = pair.key;
                const value = pair.value;
                if (key.status === "aborted" || value.status === "aborted") {
                    return INVALID;
                }
                if (key.status === "dirty" || value.status === "dirty") {
                    status.dirty();
                }
                finalMap.set(key.value, value.value);
            }
            return { status: status.value, value: finalMap };
        }
    }
}
ZodMap.create = (keyType, valueType, params) => {
    return new ZodMap({
        valueType,
        keyType,
        typeName: ZodFirstPartyTypeKind.ZodMap,
        ...processCreateParams(params),
    });
};
class ZodSet extends ZodType {
    _parse(input) {
        const { status, ctx } = this._processInputParams(input);
        if (ctx.parsedType !== ZodParsedType.set) {
            addIssueToContext(ctx, {
                code: ZodIssueCode.invalid_type,
                expected: ZodParsedType.set,
                received: ctx.parsedType,
            });
            return INVALID;
        }
        const def = this._def;
        if (def.minSize !== null) {
            if (ctx.data.size < def.minSize.value) {
                addIssueToContext(ctx, {
                    code: ZodIssueCode.too_small,
                    minimum: def.minSize.value,
                    type: "set",
                    inclusive: true,
                    exact: false,
                    message: def.minSize.message,
                });
                status.dirty();
            }
        }
        if (def.maxSize !== null) {
            if (ctx.data.size > def.maxSize.value) {
                addIssueToContext(ctx, {
                    code: ZodIssueCode.too_big,
                    maximum: def.maxSize.value,
                    type: "set",
                    inclusive: true,
                    exact: false,
                    message: def.maxSize.message,
                });
                status.dirty();
            }
        }
        const valueType = this._def.valueType;
        function finalizeSet(elements) {
            const parsedSet = new Set();
            for (const element of elements) {
                if (element.status === "aborted")
                    return INVALID;
                if (element.status === "dirty")
                    status.dirty();
                parsedSet.add(element.value);
            }
            return { status: status.value, value: parsedSet };
        }
        const elements = [...ctx.data.values()].map((item, i) => valueType._parse(new ParseInputLazyPath(ctx, item, ctx.path, i)));
        if (ctx.common.async) {
            return Promise.all(elements).then((elements) => finalizeSet(elements));
        }
        else {
            return finalizeSet(elements);
        }
    }
    min(minSize, message) {
        return new ZodSet({
            ...this._def,
            minSize: { value: minSize, message: errorUtil.toString(message) },
        });
    }
    max(maxSize, message) {
        return new ZodSet({
            ...this._def,
            maxSize: { value: maxSize, message: errorUtil.toString(message) },
        });
    }
    size(size, message) {
        return this.min(size, message).max(size, message);
    }
    nonempty(message) {
        return this.min(1, message);
    }
}
ZodSet.create = (valueType, params) => {
    return new ZodSet({
        valueType,
        minSize: null,
        maxSize: null,
        typeName: ZodFirstPartyTypeKind.ZodSet,
        ...processCreateParams(params),
    });
};
class ZodFunction extends ZodType {
    constructor() {
        super(...arguments);
        this.validate = this.implement;
    }
    _parse(input) {
        const { ctx } = this._processInputParams(input);
        if (ctx.parsedType !== ZodParsedType.function) {
            addIssueToContext(ctx, {
                code: ZodIssueCode.invalid_type,
                expected: ZodParsedType.function,
                received: ctx.parsedType,
            });
            return INVALID;
        }
        function makeArgsIssue(args, error) {
            return makeIssue({
                data: args,
                path: ctx.path,
                errorMaps: [
                    ctx.common.contextualErrorMap,
                    ctx.schemaErrorMap,
                    getErrorMap(),
                    errorMap,
                ].filter((x) => !!x),
                issueData: {
                    code: ZodIssueCode.invalid_arguments,
                    argumentsError: error,
                },
            });
        }
        function makeReturnsIssue(returns, error) {
            return makeIssue({
                data: returns,
                path: ctx.path,
                errorMaps: [
                    ctx.common.contextualErrorMap,
                    ctx.schemaErrorMap,
                    getErrorMap(),
                    errorMap,
                ].filter((x) => !!x),
                issueData: {
                    code: ZodIssueCode.invalid_return_type,
                    returnTypeError: error,
                },
            });
        }
        const params = { errorMap: ctx.common.contextualErrorMap };
        const fn = ctx.data;
        if (this._def.returns instanceof ZodPromise) {
            // Would love a way to avoid disabling this rule, but we need
            // an alias (using an arrow function was what caused 2651).
            // eslint-disable-next-line @typescript-eslint/no-this-alias
            const me = this;
            return OK(async function (...args) {
                const error = new ZodError([]);
                const parsedArgs = await me._def.args
                    .parseAsync(args, params)
                    .catch((e) => {
                    error.addIssue(makeArgsIssue(args, e));
                    throw error;
                });
                const result = await Reflect.apply(fn, this, parsedArgs);
                const parsedReturns = await me._def.returns._def.type
                    .parseAsync(result, params)
                    .catch((e) => {
                    error.addIssue(makeReturnsIssue(result, e));
                    throw error;
                });
                return parsedReturns;
            });
        }
        else {
            // Would love a way to avoid disabling this rule, but we need
            // an alias (using an arrow function was what caused 2651).
            // eslint-disable-next-line @typescript-eslint/no-this-alias
            const me = this;
            return OK(function (...args) {
                const parsedArgs = me._def.args.safeParse(args, params);
                if (!parsedArgs.success) {
                    throw new ZodError([makeArgsIssue(args, parsedArgs.error)]);
                }
                const result = Reflect.apply(fn, this, parsedArgs.data);
                const parsedReturns = me._def.returns.safeParse(result, params);
                if (!parsedReturns.success) {
                    throw new ZodError([makeReturnsIssue(result, parsedReturns.error)]);
                }
                return parsedReturns.data;
            });
        }
    }
    parameters() {
        return this._def.args;
    }
    returnType() {
        return this._def.returns;
    }
    args(...items) {
        return new ZodFunction({
            ...this._def,
            args: ZodTuple.create(items).rest(ZodUnknown.create()),
        });
    }
    returns(returnType) {
        return new ZodFunction({
            ...this._def,
            returns: returnType,
        });
    }
    implement(func) {
        const validatedFunc = this.parse(func);
        return validatedFunc;
    }
    strictImplement(func) {
        const validatedFunc = this.parse(func);
        return validatedFunc;
    }
    static create(args, returns, params) {
        return new ZodFunction({
            args: (args
                ? args
                : ZodTuple.create([]).rest(ZodUnknown.create())),
            returns: returns || ZodUnknown.create(),
            typeName: ZodFirstPartyTypeKind.ZodFunction,
            ...processCreateParams(params),
        });
    }
}
class ZodLazy extends ZodType {
    get schema() {
        return this._def.getter();
    }
    _parse(input) {
        const { ctx } = this._processInputParams(input);
        const lazySchema = this._def.getter();
        return lazySchema._parse({ data: ctx.data, path: ctx.path, parent: ctx });
    }
}
ZodLazy.create = (getter, params) => {
    return new ZodLazy({
        getter: getter,
        typeName: ZodFirstPartyTypeKind.ZodLazy,
        ...processCreateParams(params),
    });
};
class ZodLiteral extends ZodType {
    _parse(input) {
        if (input.data !== this._def.value) {
            const ctx = this._getOrReturnCtx(input);
            addIssueToContext(ctx, {
                received: ctx.data,
                code: ZodIssueCode.invalid_literal,
                expected: this._def.value,
            });
            return INVALID;
        }
        return { status: "valid", value: input.data };
    }
    get value() {
        return this._def.value;
    }
}
ZodLiteral.create = (value, params) => {
    return new ZodLiteral({
        value: value,
        typeName: ZodFirstPartyTypeKind.ZodLiteral,
        ...processCreateParams(params),
    });
};
function createZodEnum(values, params) {
    return new ZodEnum({
        values,
        typeName: ZodFirstPartyTypeKind.ZodEnum,
        ...processCreateParams(params),
    });
}
class ZodEnum extends ZodType {
    constructor() {
        super(...arguments);
        _ZodEnum_cache.set(this, void 0);
    }
    _parse(input) {
        if (typeof input.data !== "string") {
            const ctx = this._getOrReturnCtx(input);
            const expectedValues = this._def.values;
            addIssueToContext(ctx, {
                expected: util$1.joinValues(expectedValues),
                received: ctx.parsedType,
                code: ZodIssueCode.invalid_type,
            });
            return INVALID;
        }
        if (!__classPrivateFieldGet(this, _ZodEnum_cache)) {
            __classPrivateFieldSet(this, _ZodEnum_cache, new Set(this._def.values));
        }
        if (!__classPrivateFieldGet(this, _ZodEnum_cache).has(input.data)) {
            const ctx = this._getOrReturnCtx(input);
            const expectedValues = this._def.values;
            addIssueToContext(ctx, {
                received: ctx.data,
                code: ZodIssueCode.invalid_enum_value,
                options: expectedValues,
            });
            return INVALID;
        }
        return OK(input.data);
    }
    get options() {
        return this._def.values;
    }
    get enum() {
        const enumValues = {};
        for (const val of this._def.values) {
            enumValues[val] = val;
        }
        return enumValues;
    }
    get Values() {
        const enumValues = {};
        for (const val of this._def.values) {
            enumValues[val] = val;
        }
        return enumValues;
    }
    get Enum() {
        const enumValues = {};
        for (const val of this._def.values) {
            enumValues[val] = val;
        }
        return enumValues;
    }
    extract(values, newDef = this._def) {
        return ZodEnum.create(values, {
            ...this._def,
            ...newDef,
        });
    }
    exclude(values, newDef = this._def) {
        return ZodEnum.create(this.options.filter((opt) => !values.includes(opt)), {
            ...this._def,
            ...newDef,
        });
    }
}
_ZodEnum_cache = new WeakMap();
ZodEnum.create = createZodEnum;
class ZodNativeEnum extends ZodType {
    constructor() {
        super(...arguments);
        _ZodNativeEnum_cache.set(this, void 0);
    }
    _parse(input) {
        const nativeEnumValues = util$1.getValidEnumValues(this._def.values);
        const ctx = this._getOrReturnCtx(input);
        if (ctx.parsedType !== ZodParsedType.string &&
            ctx.parsedType !== ZodParsedType.number) {
            const expectedValues = util$1.objectValues(nativeEnumValues);
            addIssueToContext(ctx, {
                expected: util$1.joinValues(expectedValues),
                received: ctx.parsedType,
                code: ZodIssueCode.invalid_type,
            });
            return INVALID;
        }
        if (!__classPrivateFieldGet(this, _ZodNativeEnum_cache)) {
            __classPrivateFieldSet(this, _ZodNativeEnum_cache, new Set(util$1.getValidEnumValues(this._def.values)));
        }
        if (!__classPrivateFieldGet(this, _ZodNativeEnum_cache).has(input.data)) {
            const expectedValues = util$1.objectValues(nativeEnumValues);
            addIssueToContext(ctx, {
                received: ctx.data,
                code: ZodIssueCode.invalid_enum_value,
                options: expectedValues,
            });
            return INVALID;
        }
        return OK(input.data);
    }
    get enum() {
        return this._def.values;
    }
}
_ZodNativeEnum_cache = new WeakMap();
ZodNativeEnum.create = (values, params) => {
    return new ZodNativeEnum({
        values: values,
        typeName: ZodFirstPartyTypeKind.ZodNativeEnum,
        ...processCreateParams(params),
    });
};
class ZodPromise extends ZodType {
    unwrap() {
        return this._def.type;
    }
    _parse(input) {
        const { ctx } = this._processInputParams(input);
        if (ctx.parsedType !== ZodParsedType.promise &&
            ctx.common.async === false) {
            addIssueToContext(ctx, {
                code: ZodIssueCode.invalid_type,
                expected: ZodParsedType.promise,
                received: ctx.parsedType,
            });
            return INVALID;
        }
        const promisified = ctx.parsedType === ZodParsedType.promise
            ? ctx.data
            : Promise.resolve(ctx.data);
        return OK(promisified.then((data) => {
            return this._def.type.parseAsync(data, {
                path: ctx.path,
                errorMap: ctx.common.contextualErrorMap,
            });
        }));
    }
}
ZodPromise.create = (schema, params) => {
    return new ZodPromise({
        type: schema,
        typeName: ZodFirstPartyTypeKind.ZodPromise,
        ...processCreateParams(params),
    });
};
class ZodEffects extends ZodType {
    innerType() {
        return this._def.schema;
    }
    sourceType() {
        return this._def.schema._def.typeName === ZodFirstPartyTypeKind.ZodEffects
            ? this._def.schema.sourceType()
            : this._def.schema;
    }
    _parse(input) {
        const { status, ctx } = this._processInputParams(input);
        const effect = this._def.effect || null;
        const checkCtx = {
            addIssue: (arg) => {
                addIssueToContext(ctx, arg);
                if (arg.fatal) {
                    status.abort();
                }
                else {
                    status.dirty();
                }
            },
            get path() {
                return ctx.path;
            },
        };
        checkCtx.addIssue = checkCtx.addIssue.bind(checkCtx);
        if (effect.type === "preprocess") {
            const processed = effect.transform(ctx.data, checkCtx);
            if (ctx.common.async) {
                return Promise.resolve(processed).then(async (processed) => {
                    if (status.value === "aborted")
                        return INVALID;
                    const result = await this._def.schema._parseAsync({
                        data: processed,
                        path: ctx.path,
                        parent: ctx,
                    });
                    if (result.status === "aborted")
                        return INVALID;
                    if (result.status === "dirty")
                        return DIRTY(result.value);
                    if (status.value === "dirty")
                        return DIRTY(result.value);
                    return result;
                });
            }
            else {
                if (status.value === "aborted")
                    return INVALID;
                const result = this._def.schema._parseSync({
                    data: processed,
                    path: ctx.path,
                    parent: ctx,
                });
                if (result.status === "aborted")
                    return INVALID;
                if (result.status === "dirty")
                    return DIRTY(result.value);
                if (status.value === "dirty")
                    return DIRTY(result.value);
                return result;
            }
        }
        if (effect.type === "refinement") {
            const executeRefinement = (acc) => {
                const result = effect.refinement(acc, checkCtx);
                if (ctx.common.async) {
                    return Promise.resolve(result);
                }
                if (result instanceof Promise) {
                    throw new Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");
                }
                return acc;
            };
            if (ctx.common.async === false) {
                const inner = this._def.schema._parseSync({
                    data: ctx.data,
                    path: ctx.path,
                    parent: ctx,
                });
                if (inner.status === "aborted")
                    return INVALID;
                if (inner.status === "dirty")
                    status.dirty();
                // return value is ignored
                executeRefinement(inner.value);
                return { status: status.value, value: inner.value };
            }
            else {
                return this._def.schema
                    ._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx })
                    .then((inner) => {
                    if (inner.status === "aborted")
                        return INVALID;
                    if (inner.status === "dirty")
                        status.dirty();
                    return executeRefinement(inner.value).then(() => {
                        return { status: status.value, value: inner.value };
                    });
                });
            }
        }
        if (effect.type === "transform") {
            if (ctx.common.async === false) {
                const base = this._def.schema._parseSync({
                    data: ctx.data,
                    path: ctx.path,
                    parent: ctx,
                });
                if (!isValid(base))
                    return base;
                const result = effect.transform(base.value, checkCtx);
                if (result instanceof Promise) {
                    throw new Error(`Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.`);
                }
                return { status: status.value, value: result };
            }
            else {
                return this._def.schema
                    ._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx })
                    .then((base) => {
                    if (!isValid(base))
                        return base;
                    return Promise.resolve(effect.transform(base.value, checkCtx)).then((result) => ({ status: status.value, value: result }));
                });
            }
        }
        util$1.assertNever(effect);
    }
}
ZodEffects.create = (schema, effect, params) => {
    return new ZodEffects({
        schema,
        typeName: ZodFirstPartyTypeKind.ZodEffects,
        effect,
        ...processCreateParams(params),
    });
};
ZodEffects.createWithPreprocess = (preprocess, schema, params) => {
    return new ZodEffects({
        schema,
        effect: { type: "preprocess", transform: preprocess },
        typeName: ZodFirstPartyTypeKind.ZodEffects,
        ...processCreateParams(params),
    });
};
class ZodOptional extends ZodType {
    _parse(input) {
        const parsedType = this._getType(input);
        if (parsedType === ZodParsedType.undefined) {
            return OK(undefined);
        }
        return this._def.innerType._parse(input);
    }
    unwrap() {
        return this._def.innerType;
    }
}
ZodOptional.create = (type, params) => {
    return new ZodOptional({
        innerType: type,
        typeName: ZodFirstPartyTypeKind.ZodOptional,
        ...processCreateParams(params),
    });
};
class ZodNullable extends ZodType {
    _parse(input) {
        const parsedType = this._getType(input);
        if (parsedType === ZodParsedType.null) {
            return OK(null);
        }
        return this._def.innerType._parse(input);
    }
    unwrap() {
        return this._def.innerType;
    }
}
ZodNullable.create = (type, params) => {
    return new ZodNullable({
        innerType: type,
        typeName: ZodFirstPartyTypeKind.ZodNullable,
        ...processCreateParams(params),
    });
};
class ZodDefault extends ZodType {
    _parse(input) {
        const { ctx } = this._processInputParams(input);
        let data = ctx.data;
        if (ctx.parsedType === ZodParsedType.undefined) {
            data = this._def.defaultValue();
        }
        return this._def.innerType._parse({
            data,
            path: ctx.path,
            parent: ctx,
        });
    }
    removeDefault() {
        return this._def.innerType;
    }
}
ZodDefault.create = (type, params) => {
    return new ZodDefault({
        innerType: type,
        typeName: ZodFirstPartyTypeKind.ZodDefault,
        defaultValue: typeof params.default === "function"
            ? params.default
            : () => params.default,
        ...processCreateParams(params),
    });
};
class ZodCatch extends ZodType {
    _parse(input) {
        const { ctx } = this._processInputParams(input);
        // newCtx is used to not collect issues from inner types in ctx
        const newCtx = {
            ...ctx,
            common: {
                ...ctx.common,
                issues: [],
            },
        };
        const result = this._def.innerType._parse({
            data: newCtx.data,
            path: newCtx.path,
            parent: {
                ...newCtx,
            },
        });
        if (isAsync(result)) {
            return result.then((result) => {
                return {
                    status: "valid",
                    value: result.status === "valid"
                        ? result.value
                        : this._def.catchValue({
                            get error() {
                                return new ZodError(newCtx.common.issues);
                            },
                            input: newCtx.data,
                        }),
                };
            });
        }
        else {
            return {
                status: "valid",
                value: result.status === "valid"
                    ? result.value
                    : this._def.catchValue({
                        get error() {
                            return new ZodError(newCtx.common.issues);
                        },
                        input: newCtx.data,
                    }),
            };
        }
    }
    removeCatch() {
        return this._def.innerType;
    }
}
ZodCatch.create = (type, params) => {
    return new ZodCatch({
        innerType: type,
        typeName: ZodFirstPartyTypeKind.ZodCatch,
        catchValue: typeof params.catch === "function" ? params.catch : () => params.catch,
        ...processCreateParams(params),
    });
};
class ZodNaN extends ZodType {
    _parse(input) {
        const parsedType = this._getType(input);
        if (parsedType !== ZodParsedType.nan) {
            const ctx = this._getOrReturnCtx(input);
            addIssueToContext(ctx, {
                code: ZodIssueCode.invalid_type,
                expected: ZodParsedType.nan,
                received: ctx.parsedType,
            });
            return INVALID;
        }
        return { status: "valid", value: input.data };
    }
}
ZodNaN.create = (params) => {
    return new ZodNaN({
        typeName: ZodFirstPartyTypeKind.ZodNaN,
        ...processCreateParams(params),
    });
};
const BRAND = Symbol("zod_brand");
class ZodBranded extends ZodType {
    _parse(input) {
        const { ctx } = this._processInputParams(input);
        const data = ctx.data;
        return this._def.type._parse({
            data,
            path: ctx.path,
            parent: ctx,
        });
    }
    unwrap() {
        return this._def.type;
    }
}
class ZodPipeline extends ZodType {
    _parse(input) {
        const { status, ctx } = this._processInputParams(input);
        if (ctx.common.async) {
            const handleAsync = async () => {
                const inResult = await this._def.in._parseAsync({
                    data: ctx.data,
                    path: ctx.path,
                    parent: ctx,
                });
                if (inResult.status === "aborted")
                    return INVALID;
                if (inResult.status === "dirty") {
                    status.dirty();
                    return DIRTY(inResult.value);
                }
                else {
                    return this._def.out._parseAsync({
                        data: inResult.value,
                        path: ctx.path,
                        parent: ctx,
                    });
                }
            };
            return handleAsync();
        }
        else {
            const inResult = this._def.in._parseSync({
                data: ctx.data,
                path: ctx.path,
                parent: ctx,
            });
            if (inResult.status === "aborted")
                return INVALID;
            if (inResult.status === "dirty") {
                status.dirty();
                return {
                    status: "dirty",
                    value: inResult.value,
                };
            }
            else {
                return this._def.out._parseSync({
                    data: inResult.value,
                    path: ctx.path,
                    parent: ctx,
                });
            }
        }
    }
    static create(a, b) {
        return new ZodPipeline({
            in: a,
            out: b,
            typeName: ZodFirstPartyTypeKind.ZodPipeline,
        });
    }
}
class ZodReadonly extends ZodType {
    _parse(input) {
        const result = this._def.innerType._parse(input);
        const freeze = (data) => {
            if (isValid(data)) {
                data.value = Object.freeze(data.value);
            }
            return data;
        };
        return isAsync(result)
            ? result.then((data) => freeze(data))
            : freeze(result);
    }
    unwrap() {
        return this._def.innerType;
    }
}
ZodReadonly.create = (type, params) => {
    return new ZodReadonly({
        innerType: type,
        typeName: ZodFirstPartyTypeKind.ZodReadonly,
        ...processCreateParams(params),
    });
};
function custom(check, params = {}, 
/**
 * @deprecated
 *
 * Pass `fatal` into the params object instead:
 *
 * ```ts
 * z.string().custom((val) => val.length > 5, { fatal: false })
 * ```
 *
 */
fatal) {
    if (check)
        return ZodAny.create().superRefine((data, ctx) => {
            var _a, _b;
            if (!check(data)) {
                const p = typeof params === "function"
                    ? params(data)
                    : typeof params === "string"
                        ? { message: params }
                        : params;
                const _fatal = (_b = (_a = p.fatal) !== null && _a !== void 0 ? _a : fatal) !== null && _b !== void 0 ? _b : true;
                const p2 = typeof p === "string" ? { message: p } : p;
                ctx.addIssue({ code: "custom", ...p2, fatal: _fatal });
            }
        });
    return ZodAny.create();
}
const late = {
    object: ZodObject.lazycreate,
};
var ZodFirstPartyTypeKind;
(function (ZodFirstPartyTypeKind) {
    ZodFirstPartyTypeKind["ZodString"] = "ZodString";
    ZodFirstPartyTypeKind["ZodNumber"] = "ZodNumber";
    ZodFirstPartyTypeKind["ZodNaN"] = "ZodNaN";
    ZodFirstPartyTypeKind["ZodBigInt"] = "ZodBigInt";
    ZodFirstPartyTypeKind["ZodBoolean"] = "ZodBoolean";
    ZodFirstPartyTypeKind["ZodDate"] = "ZodDate";
    ZodFirstPartyTypeKind["ZodSymbol"] = "ZodSymbol";
    ZodFirstPartyTypeKind["ZodUndefined"] = "ZodUndefined";
    ZodFirstPartyTypeKind["ZodNull"] = "ZodNull";
    ZodFirstPartyTypeKind["ZodAny"] = "ZodAny";
    ZodFirstPartyTypeKind["ZodUnknown"] = "ZodUnknown";
    ZodFirstPartyTypeKind["ZodNever"] = "ZodNever";
    ZodFirstPartyTypeKind["ZodVoid"] = "ZodVoid";
    ZodFirstPartyTypeKind["ZodArray"] = "ZodArray";
    ZodFirstPartyTypeKind["ZodObject"] = "ZodObject";
    ZodFirstPartyTypeKind["ZodUnion"] = "ZodUnion";
    ZodFirstPartyTypeKind["ZodDiscriminatedUnion"] = "ZodDiscriminatedUnion";
    ZodFirstPartyTypeKind["ZodIntersection"] = "ZodIntersection";
    ZodFirstPartyTypeKind["ZodTuple"] = "ZodTuple";
    ZodFirstPartyTypeKind["ZodRecord"] = "ZodRecord";
    ZodFirstPartyTypeKind["ZodMap"] = "ZodMap";
    ZodFirstPartyTypeKind["ZodSet"] = "ZodSet";
    ZodFirstPartyTypeKind["ZodFunction"] = "ZodFunction";
    ZodFirstPartyTypeKind["ZodLazy"] = "ZodLazy";
    ZodFirstPartyTypeKind["ZodLiteral"] = "ZodLiteral";
    ZodFirstPartyTypeKind["ZodEnum"] = "ZodEnum";
    ZodFirstPartyTypeKind["ZodEffects"] = "ZodEffects";
    ZodFirstPartyTypeKind["ZodNativeEnum"] = "ZodNativeEnum";
    ZodFirstPartyTypeKind["ZodOptional"] = "ZodOptional";
    ZodFirstPartyTypeKind["ZodNullable"] = "ZodNullable";
    ZodFirstPartyTypeKind["ZodDefault"] = "ZodDefault";
    ZodFirstPartyTypeKind["ZodCatch"] = "ZodCatch";
    ZodFirstPartyTypeKind["ZodPromise"] = "ZodPromise";
    ZodFirstPartyTypeKind["ZodBranded"] = "ZodBranded";
    ZodFirstPartyTypeKind["ZodPipeline"] = "ZodPipeline";
    ZodFirstPartyTypeKind["ZodReadonly"] = "ZodReadonly";
})(ZodFirstPartyTypeKind || (ZodFirstPartyTypeKind = {}));
const instanceOfType = (
// const instanceOfType = <T extends new (...args: any[]) => any>(
cls, params = {
    message: `Input not instance of ${cls.name}`,
}) => custom((data) => data instanceof cls, params);
const stringType = ZodString.create;
const numberType = ZodNumber.create;
const nanType = ZodNaN.create;
const bigIntType = ZodBigInt.create;
const booleanType = ZodBoolean.create;
const dateType = ZodDate.create;
const symbolType = ZodSymbol.create;
const undefinedType = ZodUndefined.create;
const nullType = ZodNull.create;
const anyType = ZodAny.create;
const unknownType = ZodUnknown.create;
const neverType = ZodNever.create;
const voidType = ZodVoid.create;
const arrayType = ZodArray.create;
const objectType = ZodObject.create;
const strictObjectType = ZodObject.strictCreate;
const unionType = ZodUnion.create;
const discriminatedUnionType = ZodDiscriminatedUnion.create;
const intersectionType = ZodIntersection.create;
const tupleType = ZodTuple.create;
const recordType = ZodRecord.create;
const mapType = ZodMap.create;
const setType = ZodSet.create;
const functionType = ZodFunction.create;
const lazyType = ZodLazy.create;
const literalType = ZodLiteral.create;
const enumType = ZodEnum.create;
const nativeEnumType = ZodNativeEnum.create;
const promiseType = ZodPromise.create;
const effectsType = ZodEffects.create;
const optionalType = ZodOptional.create;
const nullableType = ZodNullable.create;
const preprocessType = ZodEffects.createWithPreprocess;
const pipelineType = ZodPipeline.create;
const ostring = () => stringType().optional();
const onumber = () => numberType().optional();
const oboolean = () => booleanType().optional();
const coerce = {
    string: ((arg) => ZodString.create({ ...arg, coerce: true })),
    number: ((arg) => ZodNumber.create({ ...arg, coerce: true })),
    boolean: ((arg) => ZodBoolean.create({
        ...arg,
        coerce: true,
    })),
    bigint: ((arg) => ZodBigInt.create({ ...arg, coerce: true })),
    date: ((arg) => ZodDate.create({ ...arg, coerce: true })),
};
const NEVER = INVALID;

var z = /*#__PURE__*/Object.freeze({
    __proto__: null,
    defaultErrorMap: errorMap,
    setErrorMap: setErrorMap,
    getErrorMap: getErrorMap,
    makeIssue: makeIssue,
    EMPTY_PATH: EMPTY_PATH,
    addIssueToContext: addIssueToContext,
    ParseStatus: ParseStatus,
    INVALID: INVALID,
    DIRTY: DIRTY,
    OK: OK,
    isAborted: isAborted,
    isDirty: isDirty,
    isValid: isValid,
    isAsync: isAsync,
    get util () { return util$1; },
    get objectUtil () { return objectUtil; },
    ZodParsedType: ZodParsedType,
    getParsedType: getParsedType,
    ZodType: ZodType,
    datetimeRegex: datetimeRegex,
    ZodString: ZodString,
    ZodNumber: ZodNumber,
    ZodBigInt: ZodBigInt,
    ZodBoolean: ZodBoolean,
    ZodDate: ZodDate,
    ZodSymbol: ZodSymbol,
    ZodUndefined: ZodUndefined,
    ZodNull: ZodNull,
    ZodAny: ZodAny,
    ZodUnknown: ZodUnknown,
    ZodNever: ZodNever,
    ZodVoid: ZodVoid,
    ZodArray: ZodArray,
    ZodObject: ZodObject,
    ZodUnion: ZodUnion,
    ZodDiscriminatedUnion: ZodDiscriminatedUnion,
    ZodIntersection: ZodIntersection,
    ZodTuple: ZodTuple,
    ZodRecord: ZodRecord,
    ZodMap: ZodMap,
    ZodSet: ZodSet,
    ZodFunction: ZodFunction,
    ZodLazy: ZodLazy,
    ZodLiteral: ZodLiteral,
    ZodEnum: ZodEnum,
    ZodNativeEnum: ZodNativeEnum,
    ZodPromise: ZodPromise,
    ZodEffects: ZodEffects,
    ZodTransformer: ZodEffects,
    ZodOptional: ZodOptional,
    ZodNullable: ZodNullable,
    ZodDefault: ZodDefault,
    ZodCatch: ZodCatch,
    ZodNaN: ZodNaN,
    BRAND: BRAND,
    ZodBranded: ZodBranded,
    ZodPipeline: ZodPipeline,
    ZodReadonly: ZodReadonly,
    custom: custom,
    Schema: ZodType,
    ZodSchema: ZodType,
    late: late,
    get ZodFirstPartyTypeKind () { return ZodFirstPartyTypeKind; },
    coerce: coerce,
    any: anyType,
    array: arrayType,
    bigint: bigIntType,
    boolean: booleanType,
    date: dateType,
    discriminatedUnion: discriminatedUnionType,
    effect: effectsType,
    'enum': enumType,
    'function': functionType,
    'instanceof': instanceOfType,
    intersection: intersectionType,
    lazy: lazyType,
    literal: literalType,
    map: mapType,
    nan: nanType,
    nativeEnum: nativeEnumType,
    never: neverType,
    'null': nullType,
    nullable: nullableType,
    number: numberType,
    object: objectType,
    oboolean: oboolean,
    onumber: onumber,
    optional: optionalType,
    ostring: ostring,
    pipeline: pipelineType,
    preprocess: preprocessType,
    promise: promiseType,
    record: recordType,
    set: setType,
    strictObject: strictObjectType,
    string: stringType,
    symbol: symbolType,
    transformer: effectsType,
    tuple: tupleType,
    'undefined': undefinedType,
    union: unionType,
    unknown: unknownType,
    'void': voidType,
    NEVER: NEVER,
    ZodIssueCode: ZodIssueCode,
    quotelessJson: quotelessJson,
    ZodError: ZodError
});

var commonjsGlobal = typeof globalThis !== 'undefined' ? globalThis : typeof window !== 'undefined' ? window : typeof global !== 'undefined' ? global : typeof self !== 'undefined' ? self : {};

var lib = {};

var Connection$2 = {};

var exception = {};

Object.defineProperty(exception, "__esModule", { value: true });
exception.AMQPChannelError = exception.AMQPConnectionError = exception.AMQPError = void 0;
/** Low severity, e.g. nack'd message */
class AMQPError extends Error {
    code;
    /** @internal */
    constructor(code, message) {
        super(message);
        this.name = 'AMQPError';
        this.code = code;
    }
}
exception.AMQPError = AMQPError;
/** Medium severity. The channel is closed. */
class AMQPChannelError extends AMQPError {
    /** @internal */
    name = 'AMQPChannelError';
}
exception.AMQPChannelError = AMQPChannelError;
/** High severity. All pending actions are rejected and all channels are closed. The connection is reset. */
class AMQPConnectionError extends AMQPChannelError {
    /** @internal */
    name = 'AMQPConnectionError';
}
exception.AMQPConnectionError = AMQPConnectionError;

var util = {};

Object.defineProperty(util, "__esModule", { value: true });
util.recaptureAndThrow = util.expectEvent = util.EncoderStream = util.createAsyncReader = util.camelCase = util.pick = util.expBackoff = util.createDeferred = util.READY_STATE = void 0;
const exception_1$4 = exception;
const node_stream_1 = require$$1;
const node_util_1 = require$$2;
/** @internal */
var READY_STATE;
(function (READY_STATE) {
    READY_STATE[READY_STATE["CONNECTING"] = 0] = "CONNECTING";
    READY_STATE[READY_STATE["OPEN"] = 1] = "OPEN";
    READY_STATE[READY_STATE["CLOSING"] = 2] = "CLOSING";
    READY_STATE[READY_STATE["CLOSED"] = 3] = "CLOSED";
})(READY_STATE || (util.READY_STATE = READY_STATE = {}));
/** @internal */
function createDeferred(noUncaught) {
    let dfd = {};
    dfd.promise = new Promise((resolve, reject) => {
        dfd.resolve = resolve;
        dfd.reject = reject;
    });
    if (noUncaught)
        dfd.promise.catch(() => { });
    return dfd;
}
util.createDeferred = createDeferred;
/**
 * Calculate exponential backoff/retry delay.
 * Where attempts >= 1, exp > 1
 * @example expBackoff(1000, 30000, attempts)
 *   ---------------------------------
 *    attempts | possible delay
 *   ----------+----------------------
 *        1    | 1000 to 2000
 *        2    | 1000 to 4000
 *        3    | 1000 to 8000
 *        4    | 1000 to 16000
 *        5    | 1000 to 30000
 *   ---------------------------------
 * Attempts required before max delay is possible = Math.ceil(Math.log(high/step) / Math.log(exp))
 * @internal
 */
function expBackoff(step, high, attempts, exp = 2) {
    const slots = Math.ceil(Math.min(high / step, Math.pow(exp, attempts)));
    const max = Math.min(slots * step, high);
    return Math.floor(Math.random() * (max - step) + step);
}
util.expBackoff = expBackoff;
/** @internal */
function pick(src, keys) {
    let dest = {};
    for (let key of keys) {
        dest[key] = src[key];
    }
    return dest;
}
util.pick = pick;
/** @internal */
function camelCase(string) {
    const parts = string.match(/[^.|-]+/g);
    if (!parts)
        return string;
    return parts.reduce((acc, word, index) => {
        return acc + (index ? word.charAt(0).toUpperCase() + word.slice(1) : word);
    });
}
util.camelCase = camelCase;
/**
 * Wrap Readable.read() to ensure that it either resolves with a Buffer of the
 * requested length, waiting for more data when necessary, or is rejected.
 * Assumes only a single pending read at a time.
 * See also: https://nodejs.org/api/stream.html#readablereadsize
 * @internal
 */
function createAsyncReader(socket) {
    let bytes;
    let cb;
    function _read() {
        if (!cb)
            return;
        const buf = socket.read(bytes);
        if (!buf && socket.readable)
            return; // wait for readable OR close
        if (buf?.byteLength !== bytes) {
            cb(new exception_1$4.AMQPConnectionError('READ_END', 'stream ended before all bytes received'), buf);
        }
        else {
            cb(null, buf);
        }
        cb = undefined;
    }
    socket.on('close', _read);
    socket.on('readable', _read);
    return (0, node_util_1.promisify)((_bytes, _cb) => {
        bytes = _bytes;
        cb = _cb;
        _read();
    });
}
util.createAsyncReader = createAsyncReader;
/**
 * Consumes Iterators (like from a generator-fn).
 * Writes Buffers (or whatever the iterators produce) to the output stream
 * @internal
 */
class EncoderStream extends node_stream_1.Writable {
    _cur;
    _out;
    constructor(out) {
        super({ objectMode: true });
        this._out = out;
        this._loop = this._loop.bind(this);
        out.on('drain', this._loop);
    }
    writeAsync = (0, node_util_1.promisify)(this.write);
    _destroy(err, cb) {
        this._out.removeListener('drain', this._loop);
        if (this._cur) {
            this._cur[1](err);
            this._cur = undefined;
        }
        cb(err);
    }
    _write(it, enc, cb) {
        this._cur = [it, cb];
        this._loop();
    }
    /** Squeeze the current iterator until it's empty, but respect back-pressure. */
    _loop() {
        if (!this._cur)
            return;
        const [it, cb] = this._cur;
        let res;
        // @ts-ignore Added in node v15.2.0, v14.17.0
        let ok = !this._out.writableNeedDrain;
        try {
            // if Nagle's algorithm is enabled, this will reduce latency
            this._out.cork();
            while (ok && (res = it.next()) && !res.done)
                ok = this._out.write(res.value);
        }
        catch (err) {
            return cb(err);
        }
        finally {
            this._out.uncork();
            // TODO consider this:
            //process.nextTick(() => this._out.uncork())
        }
        if (res?.done) {
            this._cur = undefined;
            cb();
        }
    }
}
util.EncoderStream = EncoderStream;
/** @internal */
function expectEvent(emitter, name) {
    return new Promise((resolve) => { emitter.once(name, resolve); });
}
util.expectEvent = expectEvent;
/** @internal */
function recaptureAndThrow(err) {
    Error.captureStackTrace(err, recaptureAndThrow);
    throw err;
}
util.recaptureAndThrow = recaptureAndThrow;

var codec = {};

Object.defineProperty(codec, "__esModule", { value: true });
codec.genContentFrames = codec.genFrame = codec.encodeFrame = codec.decodeFrame = codec.ReplyCode = codec.FrameType = codec.Cmd = codec.HEARTBEAT_FRAME = codec.PROTOCOL_HEADER = void 0;
/*
 * This module encodes to, and decodes from, the AMQP binary protocol
 */
const exception_1$3 = exception;
/** @internal AMQP 0091 */
codec.PROTOCOL_HEADER = Buffer.from([65, 77, 81, 80, 0, 0, 9, 1]);
/** @internal */
codec.HEARTBEAT_FRAME = Buffer.from([8, 0, 0, 0, 0, 0, 0, 206]);
/** @ignore */
var Cmd;
(function (Cmd) {
    /** @internal */
    Cmd[Cmd["ConnectionStart"] = 655370] = "ConnectionStart";
    /** @internal */
    Cmd[Cmd["ConnectionStartOK"] = 655371] = "ConnectionStartOK";
    /** @internal */
    Cmd[Cmd["ConnectionSecure"] = 655380] = "ConnectionSecure";
    /** @internal */
    Cmd[Cmd["ConnectionSecureOK"] = 655381] = "ConnectionSecureOK";
    /** @internal */
    Cmd[Cmd["ConnectionTune"] = 655390] = "ConnectionTune";
    /** @internal */
    Cmd[Cmd["ConnectionTuneOK"] = 655391] = "ConnectionTuneOK";
    /** @internal */
    Cmd[Cmd["ConnectionOpen"] = 655400] = "ConnectionOpen";
    /** @internal */
    Cmd[Cmd["ConnectionOpenOK"] = 655401] = "ConnectionOpenOK";
    /** @internal */
    Cmd[Cmd["ConnectionClose"] = 655410] = "ConnectionClose";
    /** @internal */
    Cmd[Cmd["ConnectionCloseOK"] = 655411] = "ConnectionCloseOK";
    /** @internal */
    Cmd[Cmd["ConnectionBlocked"] = 655420] = "ConnectionBlocked";
    /** @internal */
    Cmd[Cmd["ConnectionUnblocked"] = 655421] = "ConnectionUnblocked";
    /** @internal */
    Cmd[Cmd["ChannelOpen"] = 1310730] = "ChannelOpen";
    /** @internal */
    Cmd[Cmd["ChannelOpenOK"] = 1310731] = "ChannelOpenOK";
    /** @internal */
    Cmd[Cmd["ChannelClose"] = 1310760] = "ChannelClose";
    /** @internal */
    Cmd[Cmd["ChannelCloseOK"] = 1310761] = "ChannelCloseOK";
    Cmd[Cmd["ExchangeDeclare"] = 2621450] = "ExchangeDeclare";
    Cmd[Cmd["ExchangeDeclareOK"] = 2621451] = "ExchangeDeclareOK";
    Cmd[Cmd["ExchangeDelete"] = 2621460] = "ExchangeDelete";
    Cmd[Cmd["ExchangeDeleteOK"] = 2621461] = "ExchangeDeleteOK";
    Cmd[Cmd["ExchangeBind"] = 2621470] = "ExchangeBind";
    Cmd[Cmd["ExchangeBindOK"] = 2621471] = "ExchangeBindOK";
    Cmd[Cmd["ExchangeUnbind"] = 2621480] = "ExchangeUnbind";
    Cmd[Cmd["ExchangeUnbindOK"] = 2621491] = "ExchangeUnbindOK";
    Cmd[Cmd["QueueDeclare"] = 3276810] = "QueueDeclare";
    Cmd[Cmd["QueueDeclareOK"] = 3276811] = "QueueDeclareOK";
    Cmd[Cmd["QueueBind"] = 3276820] = "QueueBind";
    Cmd[Cmd["QueueBindOK"] = 3276821] = "QueueBindOK";
    Cmd[Cmd["QueuePurge"] = 3276830] = "QueuePurge";
    Cmd[Cmd["QueuePurgeOK"] = 3276831] = "QueuePurgeOK";
    Cmd[Cmd["QueueDelete"] = 3276840] = "QueueDelete";
    Cmd[Cmd["QueueDeleteOK"] = 3276841] = "QueueDeleteOK";
    Cmd[Cmd["QueueUnbind"] = 3276850] = "QueueUnbind";
    Cmd[Cmd["QueueUnbindOK"] = 3276851] = "QueueUnbindOK";
    Cmd[Cmd["BasicQos"] = 3932170] = "BasicQos";
    Cmd[Cmd["BasicQosOK"] = 3932171] = "BasicQosOK";
    Cmd[Cmd["BasicConsume"] = 3932180] = "BasicConsume";
    Cmd[Cmd["BasicConsumeOK"] = 3932181] = "BasicConsumeOK";
    Cmd[Cmd["BasicCancel"] = 3932190] = "BasicCancel";
    Cmd[Cmd["BasicCancelOK"] = 3932191] = "BasicCancelOK";
    Cmd[Cmd["BasicPublish"] = 3932200] = "BasicPublish";
    Cmd[Cmd["BasicReturn"] = 3932210] = "BasicReturn";
    Cmd[Cmd["BasicDeliver"] = 3932220] = "BasicDeliver";
    Cmd[Cmd["BasicGet"] = 3932230] = "BasicGet";
    Cmd[Cmd["BasicGetOK"] = 3932231] = "BasicGetOK";
    Cmd[Cmd["BasicGetEmpty"] = 3932232] = "BasicGetEmpty";
    Cmd[Cmd["BasicAck"] = 3932240] = "BasicAck";
    Cmd[Cmd["BasicReject"] = 3932250] = "BasicReject";
    Cmd[Cmd["BasicRecover"] = 3932270] = "BasicRecover";
    Cmd[Cmd["BasicRecoverOK"] = 3932271] = "BasicRecoverOK";
    Cmd[Cmd["BasicNack"] = 3932280] = "BasicNack";
    Cmd[Cmd["ConfirmSelect"] = 5570570] = "ConfirmSelect";
    Cmd[Cmd["ConfirmSelectOK"] = 5570571] = "ConfirmSelectOK";
    Cmd[Cmd["TxSelect"] = 5898250] = "TxSelect";
    Cmd[Cmd["TxSelectOK"] = 5898251] = "TxSelectOK";
    Cmd[Cmd["TxCommit"] = 5898260] = "TxCommit";
    Cmd[Cmd["TxCommitOK"] = 5898261] = "TxCommitOK";
    Cmd[Cmd["TxRollback"] = 5898270] = "TxRollback";
    Cmd[Cmd["TxRollbackOK"] = 5898271] = "TxRollbackOK";
})(Cmd || (codec.Cmd = Cmd = {}));
/** @internal */
var FrameType;
(function (FrameType) {
    FrameType[FrameType["METHOD"] = 1] = "METHOD";
    FrameType[FrameType["HEADER"] = 2] = "HEADER";
    FrameType[FrameType["BODY"] = 3] = "BODY";
    FrameType[FrameType["HEARTBEAT"] = 8] = "HEARTBEAT";
})(FrameType || (codec.FrameType = FrameType = {}));
/** @internal */
var ReplyCode;
(function (ReplyCode) {
    ReplyCode[ReplyCode["OK"] = 200] = "OK";
    ReplyCode[ReplyCode["CONTENT_TOO_LARGE"] = 311] = "CONTENT_TOO_LARGE";
    ReplyCode[ReplyCode["NO_ROUTE"] = 312] = "NO_ROUTE";
    ReplyCode[ReplyCode["NO_CONSUMERS"] = 313] = "NO_CONSUMERS";
    ReplyCode[ReplyCode["ACCESS_REFUSED"] = 403] = "ACCESS_REFUSED";
    ReplyCode[ReplyCode["NOT_FOUND"] = 404] = "NOT_FOUND";
    ReplyCode[ReplyCode["RESOURCE_LOCKED"] = 405] = "RESOURCE_LOCKED";
    ReplyCode[ReplyCode["PRECONDITION_FAILED"] = 406] = "PRECONDITION_FAILED";
    ReplyCode[ReplyCode["CONNECTION_FORCED"] = 320] = "CONNECTION_FORCED";
    ReplyCode[ReplyCode["INVALID_PATH"] = 402] = "INVALID_PATH";
    ReplyCode[ReplyCode["FRAME_ERROR"] = 501] = "FRAME_ERROR";
    ReplyCode[ReplyCode["SYNTAX_ERROR"] = 502] = "SYNTAX_ERROR";
    ReplyCode[ReplyCode["COMMAND_INVALID"] = 503] = "COMMAND_INVALID";
    ReplyCode[ReplyCode["CHANNEL_ERROR"] = 504] = "CHANNEL_ERROR";
    ReplyCode[ReplyCode["UNEXPECTED_FRAME"] = 505] = "UNEXPECTED_FRAME";
    ReplyCode[ReplyCode["RESOURCE_ERROR"] = 506] = "RESOURCE_ERROR";
    ReplyCode[ReplyCode["NOT_ALLOWED"] = 530] = "NOT_ALLOWED";
    ReplyCode[ReplyCode["NOT_IMPLEMENTED"] = 540] = "NOT_IMPLEMENTED";
    ReplyCode[ReplyCode["INTERNAL_ERROR"] = 541] = "INTERNAL_ERROR";
})(ReplyCode || (codec.ReplyCode = ReplyCode = {}));
const FRAME_END = 206;
/** Represents a list of boolean properties, encoded as a bitfield */
const BITS = (...keys) => {
    const totalBytes = Math.ceil(keys.length / 8);
    return {
        sizeof() {
            return totalBytes;
        },
        decode(src, offset) {
            const res = {};
            for (let byteIndex = 0; byteIndex < totalBytes; byteIndex++) {
                const byte = src.readUInt8(offset + byteIndex);
                for (let bitIndex = 0; bitIndex < 8 && (byteIndex * 8 + bitIndex) < keys.length; bitIndex++) {
                    res[keys[(byteIndex * 8) + bitIndex]] = !!((1 << bitIndex) & byte);
                }
            }
            return [res, offset + totalBytes];
        },
        encode(out, props, offset) {
            let byteIndex, bitIndex, key, byte;
            for (byteIndex = 0; byteIndex < totalBytes; byteIndex++) {
                byte = 0;
                for (bitIndex = 0; bitIndex < 8; bitIndex++) {
                    key = keys[(byteIndex * 8) + bitIndex];
                    if (props[key])
                        byte += 1 << bitIndex;
                }
                out.writeUInt8(byte, offset + byteIndex);
            }
            return offset + totalBytes;
        }
    };
};
/** Represents AMQP methods parameters, which are non-null values encoded in a particular order. */
const STRUCT = (def) => ({
    sizeof(props) {
        let size = 0; // 12
        let field, key, ptype;
        for (field of def) {
            if (Array.isArray(field)) {
                [key, ptype] = field;
                // TODO check for undefined props at a higher level
                size += ptype.sizeof(props[key]);
            }
            else {
                size += field.sizeof(props);
            }
        }
        return size;
    },
    decode(src, offset) {
        let result = {};
        let field, key, ptype, props;
        for (field of def) {
            if (Array.isArray(field)) {
                [key, ptype] = field;
                [props, offset] = ptype.decode(src, offset);
                result[key] = props;
            }
            else {
                [props, offset] = field.decode(src, offset);
                Object.assign(result, props);
            }
        }
        return [result, offset];
    },
    encode(out, props, offset) {
        let field, key, ptype;
        if (props)
            for (field of def) {
                if (Array.isArray(field)) {
                    [key, ptype] = field;
                    offset = ptype.encode(out, props[key], offset);
                }
                else {
                    offset = field.encode(out, props, offset);
                }
            }
        return offset;
    }
});
/** The AMQP spec says: TABLE field names MUST start with a letter, '$' or '#' and
 * may continue with letters, '$' or '#', digits, or underlines, to a maximum
 * length of 128 characters.
 *
 * RabbitMQ, however, does not seem to enforce this. */
const SHORTSTR = {
    sizeof(val) {
        const str = val == null ? '' : String(val); // cast from Number
        const len = Math.min(Buffer.byteLength(str), 255);
        return 1 + len;
    },
    decode(src, offset) {
        const total = offset + 1 + src.readUInt8(offset);
        const val = src.toString('utf8', offset + 1, total);
        return [val, total];
    },
    encode(out, val, offset) {
        const str = val == null ? '' : String(val); // cast from Number
        // truncate long strings
        const len = Math.min(Buffer.byteLength(str), 255);
        out.writeUInt8(len, offset);
        out.write(str, offset + 1, len, 'utf8');
        return 1 + offset + len;
    }
};
const TYPE = {
    UINT8: { id: 66,
        sizeof() { return 1; },
        decode(src, offset) {
            return [src.readUInt8(offset), offset + 1];
        },
        encode(out, val, offset) {
            return out.writeUInt8(val == null ? 0 : val, offset);
        }
    },
    UINT16: { id: 66,
        sizeof() { return 2; },
        decode(src, offset) {
            return [src.readUInt16BE(offset), offset + 2];
        },
        encode(out, val, offset) {
            return out.writeUInt16BE(val == null ? 0 : val, offset);
        }
    },
    UINT32: { id: 105,
        sizeof() { return 4; },
        decode(src, offset) {
            return [src.readUInt32BE(offset), offset + 4];
        },
        encode(out, val, offset) {
            return out.writeUInt32BE(val == null ? 0 : val, offset);
        }
    },
    UINT64: { id: 84,
        sizeof() { return 8; },
        decode(src, offset) {
            return [Number(src.readBigUint64BE(offset)), offset + 8];
        },
        encode(out, val, offset) {
            return out.writeBigUint64BE(BigInt(val == null ? 0 : val), offset);
        }
    },
    INT8: { id: 98,
        sizeof() { return 1; },
        decode(src, offset) {
            return [src.readInt8(offset), offset + 1];
        },
        encode(out, val, offset) {
            return out.writeInt8(val == null ? 0 : val, offset);
        }
    },
    INT16: { id: 115,
        sizeof() { return 2; },
        decode(src, offset) {
            return [src.readInt16BE(offset), offset + 2];
        },
        encode(out, val, offset) {
            return out.writeInt16BE(val == null ? 0 : val, offset);
        }
    },
    INT32: { id: 73,
        sizeof() { return 4; },
        decode(src, offset) {
            return [src.readInt32BE(offset), offset + 4];
        },
        encode(out, val, offset) {
            return out.writeInt32BE(val == null ? 0 : val, offset);
        }
    },
    INT64: { id: 108,
        sizeof() { return 8; },
        decode(src, offset) {
            return [Number(src.readBigInt64BE(offset)), offset + 8];
        },
        encode(out, val, offset) {
            return out.writeBigInt64BE(BigInt(val == null ? 0 : val), offset);
        }
    },
    FLOAT: { id: 102,
        sizeof() { return 4; },
        decode(src, offset) {
            return [src.readFloatBE(offset), offset + 4];
        },
        encode(out, val, offset) {
            return out.writeFloatBE(val, offset);
        }
    },
    DOUBLE: { id: 100,
        sizeof() { return 8; },
        decode(src, offset) {
            return [src.readDoubleBE(offset), offset + 8];
        },
        encode(out, val, offset) {
            //       NaN: 0x7ff80000 00000000
            //  Infinity: 0x7ff00000 00000000
            // -Infinity: 0xfff00000 00000000
            //        -0: 0x80000000 00000000
            return out.writeDoubleBE(val, offset);
        }
    },
    VARBIN32: { id: 120,
        sizeof(val) {
            const len = val ? Buffer.byteLength(val) : 0;
            return 4 + len;
        },
        decode(src, offset) {
            let total = offset + 4 + src.readUInt32BE(offset);
            let val = src.slice(offset + 4, total);
            return [val, total];
        },
        encode(out, val, offset) {
            if (val) {
                const len = Buffer.byteLength(val);
                offset = out.writeUInt32BE(len, offset);
                if (len > 0)
                    out.fill(val, offset, offset + len);
                return offset + len;
            }
            return out.writeUInt32BE(0, offset);
        }
    },
    DECIMAL: { id: 68,
        sizeof() { return 5; },
        decode(src, offset) {
            return [{
                    scale: src.readUInt8(offset),
                    value: src.readInt32BE(offset + 1)
                }, offset + 5];
        },
        encode(out, val, offset) {
            out.writeUInt8(val.scale, offset);
            return out.writeInt32BE(val.value, offset + 1);
        }
    },
    BOOL: { id: 116,
        sizeof() { return 1; },
        decode(src, offset) {
            return [src.readUInt8(offset) === 1, offset + 1];
        },
        encode(out, val, offset) {
            return out.writeUInt8(val ? 1 : 0, offset);
        }
    },
    STRING: { id: 83,
        sizeof(val) {
            if (val == null)
                val = '';
            const len = Math.min(Buffer.byteLength(val), 0xffffffff);
            return 4 + len;
        },
        decode(src, offset) {
            let total = offset + 4 + src.readUInt32BE(offset);
            let val = src.toString('utf8', offset + 4, total);
            return [val, total];
        },
        encode(out, val, offset) {
            if (val == null)
                val = '';
            // truncate really long strings
            let len = Math.min(Buffer.byteLength(val), 0xffffffff);
            out.writeUInt32BE(len, offset);
            out.write(val, offset + 4, len, 'utf8');
            return 4 + offset + len;
        }
    },
    VOID: { id: 86,
        sizeof() { return 0; },
        decode(src, offset) {
            return [null, offset];
        },
        encode(out, val, offset) {
            return offset;
        }
    },
    ARRAY: { id: 65,
        sizeof(arr) {
            let bytes = 4;
            for (let el of arr) {
                const etype = getBestType(el);
                if (!etype)
                    continue; // not encodable
                bytes += 1 + etype.sizeof(el);
            }
            return bytes;
        },
        decode(src, offset) {
            const [data, nextOffset] = TYPE.VARBIN32.decode(src, offset);
            const items = [];
            const total = data.length;
            let index = 0;
            let val;
            while (index < total) {
                [val, index] = readSimpleType(data, index);
                items.push(val);
            }
            return [items, nextOffset];
        },
        encode(out, val, offset) {
            const start = offset;
            offset += 4;
            for (let index = 0; index < val.length; index++) {
                const etype = getBestType(val[index]);
                if (!etype)
                    continue; // not encodable
                offset = out.writeUInt8(etype.id, offset);
                offset = etype.encode(out, val[index], offset);
            }
            out.writeUInt32BE(offset - start - 4, start);
            return offset;
        }
    },
    TABLE: { id: 70,
        sizeof(props) {
            let bytes = 4;
            const it = props instanceof Map ? props.entries()
                : props != null ? Object.entries(props) : [];
            for (const [k, v] of it) {
                if (typeof v != 'undefined') {
                    const etype = getBestType(v);
                    if (!etype)
                        continue; // not encodable
                    bytes += SHORTSTR.sizeof(String(k)) + 1 + etype.sizeof(v);
                }
            }
            return bytes;
        },
        decode(src, offset) {
            const [data, nextOffset] = TYPE.VARBIN32.decode(src, offset);
            const total = data.length;
            const table = {};
            let index = 0;
            let key, val;
            while (index < total) {
                [key, index] = SHORTSTR.decode(data, index);
                [val, index] = readSimpleType(data, index);
                table[key] = val;
            }
            return [table, nextOffset];
        },
        encode(out, val, offset) {
            let start = offset;
            offset += 4;
            const it = val instanceof Map ? val.entries()
                : val != null ? Object.entries(val) : [];
            for (const [k, v] of it) {
                if (typeof v != 'undefined') {
                    const etype = getBestType(v);
                    if (!etype)
                        continue; // not encodable
                    offset = SHORTSTR.encode(out, String(k), offset);
                    offset = out.writeUInt8(etype.id, offset);
                    offset = etype.encode(out, v, offset);
                }
            }
            out.writeUInt32BE(offset - start - 4, start);
            return offset;
        }
    }
};
// http://www.rabbitmq.com/amqp-0-9-1-errata.html#section_3
const TYPE_BY_ID = new Map(Object.values(TYPE).map(el => [el.id, el]));
const COMMAND_CODECS = [
    { id: Cmd.ConnectionStart, ...STRUCT([
            ['versionMajor', TYPE.UINT8],
            ['versionMinor', TYPE.UINT8],
            ['serverProperties', TYPE.TABLE],
            ['mechanisms', TYPE.STRING],
            ['locales', TYPE.STRING]
        ]) },
    { id: Cmd.ConnectionStartOK, ...STRUCT([
            ['clientProperties', TYPE.TABLE],
            ['mechanism', SHORTSTR],
            ['response', TYPE.STRING],
            ['locale', SHORTSTR]
        ]) },
    { id: Cmd.ConnectionSecure, ...STRUCT([
            ['challenge', TYPE.STRING]
        ]) },
    { id: Cmd.ConnectionSecureOK, ...STRUCT([
            ['response', TYPE.STRING]
        ]) },
    { id: Cmd.ConnectionTune, ...STRUCT([
            ['channelMax', TYPE.UINT16],
            ['frameMax', TYPE.INT32],
            ['heartbeat', TYPE.UINT16]
        ]) },
    { id: Cmd.ConnectionTuneOK, ...STRUCT([
            ['channelMax', TYPE.UINT16], // 0
            ['frameMax', TYPE.INT32], // 0
            ['heartbeat', TYPE.UINT16]
        ]) }, // 0
    { id: Cmd.ConnectionOpen, ...STRUCT([
            ['virtualHost', SHORTSTR], // "/"
            ['rsvp1', SHORTSTR], // ""
            ['rsvp2', TYPE.BOOL]
        ]) },
    { id: Cmd.ConnectionOpenOK, ...STRUCT([
            ['knownHosts', SHORTSTR]
        ]) }, // ""
    { id: Cmd.ConnectionClose, ...STRUCT([
            ['replyCode', TYPE.UINT16],
            ['replyText', SHORTSTR], // ''
            ['methodId', TYPE.UINT32]
        ]) },
    { id: Cmd.ConnectionCloseOK, ...STRUCT([]) },
    { id: Cmd.ConnectionBlocked, ...STRUCT([
            ['reason', SHORTSTR]
        ]) }, // ""
    { id: Cmd.ConnectionUnblocked, ...STRUCT([]) },
    { id: Cmd.ChannelOpen, ...STRUCT([
            ['rsvp1', SHORTSTR]
        ]) }, // ""
    { id: Cmd.ChannelOpenOK, ...STRUCT([
            ['rsvp1', TYPE.STRING]
        ]) }, // ""
    { id: Cmd.ChannelClose, ...STRUCT([
            ['replyCode', TYPE.UINT16],
            ['replyText', SHORTSTR], // ""
            ['methodId', TYPE.UINT32]
        ]) },
    { id: Cmd.ChannelCloseOK, ...STRUCT([]) },
    { id: Cmd.ExchangeDeclare, ...STRUCT([
            ['rsvp1', TYPE.UINT16], // 0
            ['exchange', SHORTSTR],
            ['type', SHORTSTR], // direct
            BITS('passive', 'durable', 'autoDelete', 'internal', 'nowait'),
            ['arguments', TYPE.TABLE]
        ]) }, // {}
    { id: Cmd.ExchangeDeclareOK, ...STRUCT([]) },
    { id: Cmd.ExchangeDelete, ...STRUCT([
            ['rsvp1', TYPE.UINT16], // 0
            ['exchange', SHORTSTR],
            BITS('ifUnused', 'nowait')
        ]) },
    { id: Cmd.ExchangeDeleteOK, ...STRUCT([]) },
    { id: Cmd.ExchangeBind, ...STRUCT([
            ['rsvp1', TYPE.UINT16], // 0
            ['destination', SHORTSTR],
            ['source', SHORTSTR],
            ['routingKey', SHORTSTR], // ""
            ['nowait', TYPE.BOOL],
            ['arguments', TYPE.TABLE]
        ]) }, // {}
    { id: Cmd.ExchangeBindOK, ...STRUCT([]) },
    { id: Cmd.ExchangeUnbind, ...STRUCT([
            ['rsvp1', TYPE.UINT16], // 0
            ['destination', SHORTSTR],
            ['source', SHORTSTR],
            ['routingKey', SHORTSTR], // ""
            ['nowait', TYPE.BOOL],
            ['arguments', TYPE.TABLE]
        ]) }, // {}
    { id: Cmd.ExchangeUnbindOK, ...STRUCT([]) },
    { id: Cmd.QueueDeclare, ...STRUCT([
            ['rsvp1', TYPE.UINT16], // 0
            ['queue', SHORTSTR], // ""
            BITS('passive', 'durable', 'exclusive', 'autoDelete', 'nowait'),
            ['arguments', TYPE.TABLE]
        ]) }, // {}
    { id: Cmd.QueueDeclareOK, ...STRUCT([
            ['queue', SHORTSTR],
            ['messageCount', TYPE.INT32],
            ['consumerCount', TYPE.INT32]
        ]) },
    { id: Cmd.QueueBind, ...STRUCT([
            ['rsvp1', TYPE.UINT16], // 0
            ['queue', SHORTSTR], // ""
            ['exchange', SHORTSTR],
            ['routingKey', SHORTSTR], // ""
            ['nowait', TYPE.BOOL],
            ['arguments', TYPE.TABLE]
        ]) }, // {}
    { id: Cmd.QueueBindOK, ...STRUCT([]) },
    { id: Cmd.QueuePurge, ...STRUCT([
            ['rsvp1', TYPE.UINT16], // 0
            ['queue', SHORTSTR], // ""
            ['nowait', TYPE.BOOL]
        ]) },
    { id: Cmd.QueuePurgeOK, ...STRUCT([
            ['messageCount', TYPE.INT32]
        ]) },
    { id: Cmd.QueueDelete, ...STRUCT([
            ['rsvp1', TYPE.UINT16], // 0
            ['queue', SHORTSTR], // ""
            BITS('ifUnused', 'ifEmpty', 'nowait')
        ]) },
    { id: Cmd.QueueDeleteOK, ...STRUCT([
            ['messageCount', TYPE.INT32]
        ]) },
    { id: Cmd.QueueUnbind, ...STRUCT([
            ['rsvp1', TYPE.UINT16], // 0
            ['queue', SHORTSTR], // ""
            ['exchange', SHORTSTR],
            ['routingKey', SHORTSTR], // ""
            ['arguments', TYPE.TABLE]
        ]) }, // {}
    { id: Cmd.QueueUnbindOK, ...STRUCT([]) },
    { id: Cmd.BasicQos, ...STRUCT([
            ['prefetchSize', TYPE.INT32], // 0
            ['prefetchCount', TYPE.UINT16], // 0
            ['global', TYPE.BOOL]
        ]) },
    { id: Cmd.BasicQosOK, ...STRUCT([]) },
    { id: Cmd.BasicConsume, ...STRUCT([
            ['rsvp1', TYPE.UINT16], // 0
            ['queue', SHORTSTR], // ""
            ['consumerTag', SHORTSTR], // ""
            BITS('noLocal', 'noAck', 'exclusive', 'nowait'),
            ['arguments', TYPE.TABLE]
        ]) }, // {}
    { id: Cmd.BasicConsumeOK, ...STRUCT([
            ['consumerTag', SHORTSTR]
        ]) },
    { id: Cmd.BasicCancel, ...STRUCT([
            ['consumerTag', SHORTSTR],
            ['nowait', TYPE.BOOL]
        ]) },
    { id: Cmd.BasicCancelOK, ...STRUCT([
            ['consumerTag', SHORTSTR]
        ]) },
    { id: Cmd.BasicPublish, ...STRUCT([
            ['rsvp1', TYPE.UINT16], // 0
            ['exchange', SHORTSTR], // ""
            ['routingKey', SHORTSTR], // ""
            BITS('mandatory', 'immediate')
        ]) },
    { id: Cmd.BasicReturn, ...STRUCT([
            ['replyCode', TYPE.UINT16],
            ['replyText', SHORTSTR], // ""
            ['exchange', SHORTSTR],
            ['routingKey', SHORTSTR]
        ]) },
    { id: Cmd.BasicDeliver, ...STRUCT([
            ['consumerTag', SHORTSTR],
            ['deliveryTag', TYPE.INT64],
            ['redelivered', TYPE.BOOL],
            ['exchange', SHORTSTR],
            ['routingKey', SHORTSTR]
        ]) },
    { id: Cmd.BasicGet, ...STRUCT([
            ['rsvp1', TYPE.UINT16], // 0
            ['queue', SHORTSTR], // ""
            ['noAck', TYPE.BOOL]
        ]) },
    { id: Cmd.BasicGetOK, ...STRUCT([
            ['deliveryTag', TYPE.INT64],
            ['redelivered', TYPE.BOOL],
            ['exchange', SHORTSTR],
            ['routingKey', SHORTSTR],
            ['messageCount', TYPE.INT32]
        ]) },
    { id: Cmd.BasicGetEmpty, ...STRUCT([
            ['rsvp1', SHORTSTR]
        ]) }, // ""
    { id: Cmd.BasicAck, ...STRUCT([
            ['deliveryTag', TYPE.INT64],
            ['multiple', TYPE.BOOL]
        ]) },
    { id: Cmd.BasicReject, ...STRUCT([
            ['deliveryTag', TYPE.INT64],
            ['requeue', TYPE.BOOL]
        ]) }, // true
    { id: Cmd.BasicRecover, ...STRUCT([
            ['requeue', TYPE.BOOL]
        ]) },
    { id: Cmd.BasicRecoverOK, ...STRUCT([]) },
    { id: Cmd.BasicNack, ...STRUCT([
            ['deliveryTag', TYPE.INT64], // 0
            BITS('multiple', 'requeue')
        ]) }, // true
    { id: Cmd.ConfirmSelect, ...STRUCT([
            ['nowait', TYPE.BOOL]
        ]) },
    { id: Cmd.ConfirmSelectOK, ...STRUCT([]) },
    { id: Cmd.TxSelect, ...STRUCT([]) },
    { id: Cmd.TxSelectOK, ...STRUCT([]) },
    { id: Cmd.TxCommit, ...STRUCT([]) },
    { id: Cmd.TxCommitOK, ...STRUCT([]) },
    { id: Cmd.TxRollback, ...STRUCT([]) },
    { id: Cmd.TxRollbackOK, ...STRUCT([]) },
];
const CMD_CODEC_BY_ID = new Map(COMMAND_CODECS.map(struct => [struct.id, struct]));
const CONTENT_PROPS = [
    ['contentType', SHORTSTR, 0x8000],
    ['contentEncoding', SHORTSTR, 0x4000],
    ['headers', TYPE.TABLE, 0x2000],
    ['deliveryMode', TYPE.UINT8, 0x1000],
    ['priority', TYPE.UINT8, 0x0800],
    ['correlationId', SHORTSTR, 0x0400],
    ['replyTo', SHORTSTR, 0x0200],
    ['expiration', SHORTSTR, 0x0100],
    ['messageId', SHORTSTR, 0x0080],
    ['timestamp', TYPE.UINT64, 0x0040],
    ['type', SHORTSTR, 0x0020],
    ['userId', SHORTSTR, 0x0010],
    ['appId', SHORTSTR, 0x0008],
    ['clusterId', SHORTSTR, 0x0004],
];
/** @internal */
async function decodeFrame(read) {
    const chunk = await read(7);
    const frameTypeId = chunk.readUint8(0);
    const channelId = chunk.readUint16BE(1);
    const frameSize = chunk.readUint32BE(3);
    const payloadBuffer = await read(frameSize + 1);
    if (payloadBuffer[frameSize] !== FRAME_END)
        throw new exception_1$3.AMQPConnectionError('FRAME_ERROR', 'invalid FRAME_END octet: ' + payloadBuffer[frameSize]);
    if (frameTypeId === FrameType.METHOD) {
        const id = payloadBuffer.readUInt32BE(0);
        const def = CMD_CODEC_BY_ID.get(id);
        if (def == null) {
            throw new exception_1$3.AMQPConnectionError('CODEC', 'invalid AMQP method id: ' + id);
        }
        const res = def.decode(payloadBuffer, 4);
        return {
            type: FrameType.METHOD,
            channelId: channelId,
            methodId: id,
            params: res[0]
        };
    }
    else if (frameTypeId === FrameType.HEADER) {
        // skip 4 bytes
        const bodySize = Number(payloadBuffer.readBigUint64BE(4));
        const bits = payloadBuffer.readUInt16BE(12);
        let offset = 14;
        let fields = {};
        let key, ptype, mask, val;
        for ([key, ptype, mask] of CONTENT_PROPS) {
            if (bits & mask) {
                [val, offset] = ptype.decode(payloadBuffer, offset);
                fields[key] = val;
            }
        }
        return {
            type: FrameType.HEADER,
            channelId: channelId,
            bodySize: bodySize,
            fields: fields
        };
    }
    else if (frameTypeId === FrameType.BODY) {
        return { type: FrameType.BODY, channelId, payload: payloadBuffer.slice(0, -1) };
    }
    else if (frameTypeId === FrameType.HEARTBEAT) {
        return { type: FrameType.HEARTBEAT, channelId: 0 };
    }
    else {
        throw new exception_1$3.AMQPConnectionError('FRAME_ERROR', 'invalid data frame');
    }
}
codec.decodeFrame = decodeFrame;
/** @internal */
function encodeFrame(data, maxSize = Infinity) {
    if (data.type === FrameType.METHOD) {
        const def = CMD_CODEC_BY_ID.get(data.methodId);
        if (def == null) {
            throw new exception_1$3.AMQPConnectionError('CODEC', 'unknown AMQP method id: ' + data.methodId);
        }
        const paramSize = data.params == null ? 0 : def.sizeof(data.params);
        const frameSize = 4 + paramSize;
        if (frameSize > maxSize) {
            throw new exception_1$3.AMQPChannelError('CODEC', `frame size of ${frameSize} bytes exceeds maximum of ${maxSize}`);
        }
        const buf = Buffer.allocUnsafe(12 + paramSize);
        let offset = buf.writeUInt8(FrameType.METHOD, 0);
        offset = buf.writeUInt16BE(data.channelId, offset);
        offset = buf.writeUInt32BE(frameSize, offset);
        offset = buf.writeUInt32BE(data.methodId, offset);
        if (data.params != null)
            offset = def.encode(buf, data.params, offset);
        buf.writeUInt8(FRAME_END, offset);
        return buf;
    }
    else if (data.type === FrameType.HEADER) {
        let paramSize = 0;
        let bits = 0;
        let key, ptype, mask, val;
        for ([key, ptype, mask] of CONTENT_PROPS) {
            val = data.fields[key];
            if (val != null) {
                paramSize += ptype.sizeof(val);
                bits |= mask;
            }
        }
        const frameSize = 14 + paramSize;
        if (frameSize > maxSize) {
            throw new exception_1$3.AMQPChannelError('CODEC', `frame size of ${frameSize} bytes exceeds maximum of ${maxSize}`);
        }
        const buf = Buffer.allocUnsafe(22 + paramSize);
        let offset = buf.writeUInt8(FrameType.HEADER, 0);
        offset = buf.writeUInt16BE(data.channelId, offset);
        offset = buf.writeUInt32BE(frameSize, offset);
        offset = buf.writeUInt32BE(0x003c0000, offset);
        offset = buf.writeBigUInt64BE(BigInt(data.bodySize), offset);
        offset = buf.writeUInt16BE(bits, offset);
        for ([key, ptype] of CONTENT_PROPS) {
            val = data.fields[key];
            if (val != null) {
                offset = ptype.encode(buf, val, offset);
            }
        }
        buf.writeUInt8(FRAME_END, offset); // frame end
        return buf;
    }
    else if (data.type === FrameType.BODY) {
        const buf = Buffer.allocUnsafe(8 + data.payload.byteLength);
        let offset = buf.writeUInt8(FrameType.BODY, 0);
        offset = buf.writeUInt16BE(data.channelId, offset);
        offset = buf.writeUInt32BE(data.payload.byteLength, offset);
        offset += data.payload.copy(buf, offset, 0);
        buf.writeUInt8(FRAME_END, offset); // frame end
        return buf;
    }
    else {
        throw new Error('not implemented');
    }
}
codec.encodeFrame = encodeFrame;
/** @internal */
function* genFrame(frame, frameMax) {
    yield encodeFrame(frame, frameMax);
}
codec.genFrame = genFrame;
/** @internal Allocate DataFrame buffers on demand, right before writing to the socket */
function* genContentFrames(channelId, params, body, frameMax) {
    // Immediately encode header frame to catch any codec errors before we send
    // the method frame. If we send the method frame, but can't send the header
    // frame, this will cause a connection-level error and reset. This way the
    // error is contained to the channel-level.
    const methodFrame = encodeFrame({
        type: FrameType.METHOD,
        channelId,
        methodId: Cmd.BasicPublish,
        params
    });
    const headerFrame = encodeFrame({
        type: FrameType.HEADER,
        channelId,
        bodySize: body.length,
        fields: params
    }, frameMax);
    yield methodFrame;
    yield headerFrame;
    const totalContentFrames = Math.ceil(body.length / frameMax);
    for (let index = 0; index < totalContentFrames; ++index) {
        const offset = frameMax * index;
        yield encodeFrame({
            type: FrameType.BODY,
            channelId,
            payload: body.slice(offset, offset + frameMax)
        });
    }
}
codec.genContentFrames = genContentFrames;
function readSimpleType(src, offset) {
    const id = src.readUInt8(offset);
    const etype = TYPE_BY_ID.get(id);
    if (!etype) {
        throw new Error(`unknown AMQP 0.9.1 type code: ${id}`);
    }
    return etype.decode(src, offset + 1);
}
function getBestType(val) {
    if (typeof val === 'string') {
        return TYPE.STRING;
    }
    else if (typeof val === 'boolean') {
        return TYPE.BOOL;
    }
    else if (typeof val === 'number') {
        // 0x4000000000000 (2^50):
        //   insufficient precision to distinguish floats or ints
        //   e.g. Math.pow(2, 50) + 0.1 === Math.pow(2, 50)
        //   so use INT64 instead
        if (val >= 0x8000000000000000
            || val > -0x4000000000000 && val < 0x4000000000000 && Math.floor(val) !== val) {
            return TYPE.DOUBLE;
        }
        else if (val >= -0x80 && val < 0x80) {
            return TYPE.INT8;
        }
        else if (val >= -0x8000 && val < 0x8000) {
            return TYPE.INT16;
        }
        else if (val >= -0x80000000 && val < 0x80000000) {
            return TYPE.INT32;
        }
        else {
            return TYPE.INT64;
        }
    }
    else if (typeof val == 'bigint') {
        return TYPE.INT64;
    }
    else if (Array.isArray(val)) {
        return TYPE.ARRAY;
    }
    else if (val === null) {
        return TYPE.VOID;
    }
    else if (typeof val === 'object') {
        return TYPE.TABLE;
    }
}

var Channel$1 = {};

var __importDefault$1 = (commonjsGlobal && commonjsGlobal.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(Channel$1, "__esModule", { value: true });
Channel$1.Channel = void 0;
const exception_1$2 = exception;
const util_1$2 = util;
const node_events_1$1 = __importDefault$1(require$$2$1);
const codec_1$1 = codec;
var CH_MODE;
(function (CH_MODE) {
    CH_MODE[CH_MODE["NORMAL"] = 0] = "NORMAL";
    CH_MODE[CH_MODE["TRANSACTION"] = 1] = "TRANSACTION";
    CH_MODE[CH_MODE["CONFIRM"] = 2] = "CONFIRM";
})(CH_MODE || (CH_MODE = {}));
/**
 * @see {@link Connection#acquire | Connection#acquire()}
 * @see {@link Connection#createConsumer | Connection#createConsumer()}
 * @see {@link Connection#createPublisher | Connection#createPublisher()}
 * @see {@link Connection#createRPCClient | Connection#createRPCClient()}
 *
 * A raw Channel can be acquired from your Connection, but please consider
 * using a higher level abstraction like a {@link Consumer} or
 * {@link Publisher} for most cases.
 *
 * AMQP is a multi-channelled protocol. Channels provide a way to multiplex a
 * heavyweight TCP/IP connection into several light weight connections. This
 * makes the protocol more “firewall friendly” since port usage is predictable.
 * It also means that traffic shaping and other network QoS features can be
 * easily employed. Channels are independent of each other and can perform
 * different functions simultaneously with other channels, the available
 * bandwidth being shared between the concurrent activities.
 *
 * @example
 * ```
 * const rabbit = new Connection()
 *
 * // Will wait for the connection to establish and then create a Channel
 * const ch = await rabbit.acquire()
 *
 * // Channels can emit some events too (see documentation)
 * ch.on('close', () => {
 *   console.log('channel was closed')
 * })
 *
 * // Create a queue for the duration of this connection
 * await ch.queueDeclare({queue: 'my-queue'})
 *
 * // Enable publisher acknowledgements
 * await ch.confirmSelect()
 *
 * const data = {title: 'just some object'}
 *
 * // Resolves when the data has been flushed through the socket or if
 * // ch.confirmSelect() was called: will wait for an acknowledgement
 * await ch.basicPublish({routingKey: 'my-queue'}, data)
 *
 * const msg = ch.basicGet('my-queue')
 * console.log(msg)
 *
 * await ch.queueDelete('my-queue')
 *
 * // It's your responsibility to close any acquired channels
 * await ch.close()
 * ```
 */
class Channel extends node_events_1$1.default {
    /** @internal */
    _conn;
    id;
    /** False if the channel is closed */
    active;
    /** @internal */
    _state;
    /** @internal */
    constructor(id, conn) {
        super();
        this._conn = conn;
        this.id = id;
        this.active = true;
        this._state = {
            maxFrameSize: conn._opt.frameMax,
            deliveryCount: 1,
            mode: CH_MODE.NORMAL,
            unconfirmed: new Map(),
            rpcBuffer: [],
            cleared: false,
            consumers: new Map(),
            stream: new util_1$2.EncoderStream(conn._socket)
        };
        this._state.stream.on('error', () => {
            // don't need to propagate error here:
            // - if connection ended: already handled by the Connection class
            // - if encoding error: error recieved by write callback
            this.close();
        });
    }
    /** Close the channel */
    async close() {
        if (!this.active) {
            return;
        }
        this.active = false;
        try {
            // wait for encoder stream to end
            if (this._state.stream.writable) {
                if (!this._state.rpc)
                    this._state.stream.end();
                await new Promise(resolve => this._state.stream.on('close', resolve));
            }
            else {
                // if an rpc failed to encode then wait for it to clear
                await new Promise(setImmediate);
            }
            // wait for final rpc, if it was already sent
            if (this._state.rpc) {
                const [dfd] = this._state.rpc;
                this._state.rpc = undefined;
                await dfd.promise;
            }
            // send channel.close
            const dfd = (0, util_1$2.createDeferred)();
            this._state.rpc = [dfd, codec_1$1.Cmd.ChannelClose, codec_1$1.Cmd.ChannelCloseOK];
            this._conn._writeMethod({
                type: codec_1$1.FrameType.METHOD,
                channelId: this.id,
                methodId: codec_1$1.Cmd.ChannelClose,
                params: { replyCode: 200, replyText: '', methodId: 0 }
            });
            await dfd.promise;
        }
        catch (err) {
            // ignored; if write fails because the connection closed then this is
            // technically a success. Can't have a channel without a connection!
        }
        finally {
            this._clear();
        }
    }
    /** @internal */
    _handleRPC(methodId, data) {
        if (methodId === codec_1$1.Cmd.ChannelClose) {
            const params = data;
            this.active = false;
            this._conn._writeMethod({
                type: codec_1$1.FrameType.METHOD,
                channelId: this.id,
                methodId: codec_1$1.Cmd.ChannelCloseOK,
                params: undefined
            });
            const strcode = codec_1$1.ReplyCode[params.replyCode] || String(params.replyCode);
            const msg = codec_1$1.Cmd[params.methodId] + ': ' + params.replyText;
            const err = new exception_1$2.AMQPChannelError(strcode, msg);
            //const badName = SPEC.getFullName(params.classId, params.methodId)
            if (params.methodId === codec_1$1.Cmd.BasicPublish && this._state.unconfirmed.size > 0) {
                // reject first unconfirmed message
                const [tag, dfd] = this._state.unconfirmed.entries().next().value;
                this._state.unconfirmed.delete(tag);
                dfd.reject(err);
            }
            else if (this._state.rpc && params.methodId === this._state.rpc[1]) {
                // or reject the rpc
                const [dfd] = this._state.rpc;
                this._state.rpc = undefined;
                dfd.reject(err);
            }
            else {
                // last resort
                this._conn.emit('error', err);
            }
            this._clear();
            return;
        }
        if (!this._state.rpc) {
            throw new exception_1$2.AMQPConnectionError('UNEXPECTED_FRAME', `client received unexpected method ch${this.id}:${codec_1$1.Cmd[methodId]} ${JSON.stringify(data)}`);
        }
        const [dfd, , expectedId] = this._state.rpc;
        this._state.rpc = undefined;
        if (expectedId !== methodId) {
            throw new exception_1$2.AMQPConnectionError('UNEXPECTED_FRAME', `client received unexpected method ch${this.id}:${codec_1$1.Cmd[methodId]} ${JSON.stringify(data)}`);
        }
        dfd.resolve(data);
        if (this._state.stream.writable) {
            if (!this.active)
                this._state.stream.end();
            else if (this._state.rpcBuffer.length > 0)
                this._rpcNext(this._state.rpcBuffer.shift());
        }
    }
    /**
     * Invoke all pending response handlers with an error
     * @internal
     */
    _clear(err) {
        if (this._state.cleared)
            return;
        this._state.cleared = true;
        if (err == null)
            err = new exception_1$2.AMQPChannelError('CH_CLOSE', 'channel is closed');
        this.active = false;
        if (this._state.rpc) {
            const [dfd] = this._state.rpc;
            this._state.rpc = undefined;
            dfd.reject(err);
        }
        for (const [dfd] of this._state.rpcBuffer) {
            dfd.reject(err);
        }
        this._state.rpcBuffer = [];
        for (const dfd of this._state.unconfirmed.values()) {
            dfd.reject(err);
        }
        this._state.unconfirmed.clear();
        this._state.consumers.clear();
        this._state.stream.destroy(err);
        this.emit('close');
    }
    /** @internal */
    _onMethod(methodFrame) {
        if (this._state.incoming != null) {
            throw new exception_1$2.AMQPConnectionError('UNEXPECTED_FRAME', 'unexpected method frame, already awaiting header/body; this is a bug');
        }
        if ([codec_1$1.Cmd.BasicDeliver, codec_1$1.Cmd.BasicReturn, codec_1$1.Cmd.BasicGetOK].includes(methodFrame.methodId)) {
            this._state.incoming = { methodFrame, headerFrame: undefined, chunks: undefined, received: 0 };
        }
        else if (methodFrame.methodId === codec_1$1.Cmd.BasicGetEmpty) {
            this._handleRPC(codec_1$1.Cmd.BasicGetOK, undefined);
        }
        else if (this._state.mode === CH_MODE.CONFIRM && methodFrame.methodId === codec_1$1.Cmd.BasicAck) {
            const params = methodFrame.params;
            if (params.multiple) {
                for (const [tag, dfd] of this._state.unconfirmed.entries()) {
                    if (tag > params.deliveryTag)
                        break;
                    dfd.resolve();
                    this._state.unconfirmed.delete(tag);
                }
            }
            else {
                const dfd = this._state.unconfirmed.get(params.deliveryTag);
                if (dfd) {
                    dfd.resolve();
                    this._state.unconfirmed.delete(params.deliveryTag);
                }
            }
        }
        else if (this._state.mode === CH_MODE.CONFIRM && methodFrame.methodId === codec_1$1.Cmd.BasicNack) {
            const params = methodFrame.params;
            if (params.multiple) {
                for (const [tag, dfd] of this._state.unconfirmed.entries()) {
                    if (tag > params.deliveryTag)
                        break;
                    dfd.reject(new exception_1$2.AMQPError('NACK', 'message rejected by server'));
                    this._state.unconfirmed.delete(tag);
                }
            }
            else {
                const dfd = this._state.unconfirmed.get(params.deliveryTag);
                if (dfd) {
                    dfd.reject(new exception_1$2.AMQPError('NACK', 'message rejected by server'));
                    this._state.unconfirmed.delete(params.deliveryTag);
                }
            }
        }
        else if (methodFrame.methodId === codec_1$1.Cmd.BasicCancel) {
            const params = methodFrame.params;
            this._state.consumers.delete(params.consumerTag);
            setImmediate(() => {
                this.emit('basic.cancel', params.consumerTag, new exception_1$2.AMQPError('CANCEL_FORCED', 'cancelled by server'));
            });
            //} else if (methodFrame.fullName === 'channel.flow') unsupported; https://blog.rabbitmq.com/posts/2014/04/breaking-things-with-rabbitmq-3-3
        }
        else {
            this._handleRPC(methodFrame.methodId, methodFrame.params);
        }
    }
    /** @internal */
    _onHeader(headerFrame) {
        if (!this._state.incoming || this._state.incoming.headerFrame || this._state.incoming.received > 0)
            throw new exception_1$2.AMQPConnectionError('UNEXPECTED_FRAME', 'unexpected header frame; this is a bug');
        const expectedContentFrameCount = Math.ceil(headerFrame.bodySize / (this._state.maxFrameSize - 8));
        this._state.incoming.headerFrame = headerFrame;
        this._state.incoming.chunks = new Array(expectedContentFrameCount);
        if (expectedContentFrameCount === 0)
            this._onBody();
    }
    /** @internal */
    _onBody(bodyFrame) {
        if (this._state.incoming?.chunks == null || this._state.incoming.headerFrame == null || this._state.incoming.methodFrame == null)
            throw new exception_1$2.AMQPConnectionError('UNEXPECTED_FRAME', 'unexpected AMQP body frame; this is a bug');
        if (bodyFrame)
            this._state.incoming.chunks[this._state.incoming.received++] = bodyFrame.payload;
        if (this._state.incoming.received === this._state.incoming.chunks.length) {
            const { methodFrame, headerFrame, chunks } = this._state.incoming;
            this._state.incoming = undefined;
            let body = Buffer.concat(chunks);
            if (headerFrame.fields.contentType === 'text/plain' && !headerFrame.fields.contentEncoding) {
                body = body.toString();
            }
            else if (headerFrame.fields.contentType === 'application/json' && !headerFrame.fields.contentEncoding) {
                try {
                    body = JSON.parse(body.toString());
                }
                catch (_) {
                    // do nothing; this is a user problem
                }
            }
            const uncastMessage = {
                ...methodFrame.params,
                ...headerFrame.fields,
                durable: headerFrame.fields.deliveryMode === 2,
                body
            };
            if (methodFrame.methodId === codec_1$1.Cmd.BasicDeliver) {
                const message = uncastMessage;
                // setImmediate allows basicConsume to resolve first if
                // basic.consume-ok & basic.deliver are received in the same chunk.
                // Also this resets the stack trace for handler()
                setImmediate(() => {
                    const handler = this._state.consumers.get(message.consumerTag);
                    if (!handler) ;
                    else {
                        // no try-catch; users must handle their own errors
                        handler(message);
                    }
                });
            }
            else if (methodFrame.methodId === codec_1$1.Cmd.BasicReturn) {
                setImmediate(() => {
                    this.emit('basic.return', uncastMessage); // ReturnedMessage
                });
            }
            else if (methodFrame.methodId === codec_1$1.Cmd.BasicGetOK) {
                this._handleRPC(codec_1$1.Cmd.BasicGetOK, uncastMessage); // SyncMessage
            }
        }
    }
    /** @internal
     * AMQP does not support RPC pipelining!
     * C = client
     * S = server
     *
     * C:basic.consume
     * C:queue.declare
     * ...
     * S:queue.declare  <- response may arrive out of order
     * S:basic.consume
     *
     * So we can only have one RPC in-flight at a time:
     * C:basic.consume
     * S:basic.consume
     * C:queue.declare
     * S:queue.declare
     **/
    _invoke(req, res, params) {
        if (!this.active)
            return Promise.reject(new exception_1$2.AMQPChannelError('CH_CLOSE', 'channel is closed'));
        const dfd = (0, util_1$2.createDeferred)();
        const it = (0, codec_1$1.genFrame)({
            type: codec_1$1.FrameType.METHOD,
            channelId: this.id,
            methodId: req,
            params: params
        }, this._state.maxFrameSize);
        const rpc = [dfd, req, res, it];
        if (this._state.rpc)
            this._state.rpcBuffer.push(rpc);
        else
            this._rpcNext(rpc);
        return dfd.promise.catch(util_1$2.recaptureAndThrow);
    }
    /** @internal
     * Start the next RPC */
    _rpcNext([dfd, req, res, it]) {
        this._state.rpc = [dfd, req, res];
        this._state.stream.write(it, (err) => {
            if (err) {
                this._state.rpc = undefined;
                dfd.reject(err);
            }
        });
    }
    /** @internal */
    _invokeNowait(methodId, params) {
        if (!this.active)
            throw new exception_1$2.AMQPChannelError('CH_CLOSE', 'channel is closed');
        const frame = {
            type: codec_1$1.FrameType.METHOD,
            channelId: this.id,
            methodId: methodId,
            params: params
        };
        this._state.stream.write((0, codec_1$1.genFrame)(frame, this._state.maxFrameSize), (err) => {
            if (err) {
                err.message += '; ' + codec_1$1.Cmd[methodId];
                this._conn.emit('error', err);
            }
        });
    }
    async basicPublish(params, body) {
        if (!this.active)
            return Promise.reject(new exception_1$2.AMQPChannelError('CH_CLOSE', 'channel is closed'));
        if (typeof params == 'string') {
            params = { routingKey: params };
        }
        params = Object.assign({ timestamp: Math.floor(Date.now() / 1000) }, params);
        params.deliveryMode = (params.durable || params.deliveryMode === 2) ? 2 : 1;
        params.rsvp1 = 0;
        if (typeof body == 'string') {
            body = Buffer.from(body, 'utf8');
            params.contentType = 'text/plain';
            params.contentEncoding = undefined;
        }
        else if (!Buffer.isBuffer(body)) {
            body = Buffer.from(JSON.stringify(body), 'utf8');
            params.contentType = 'application/json';
            params.contentEncoding = undefined;
        }
        await this._state.stream.writeAsync((0, codec_1$1.genContentFrames)(this.id, params, body, this._state.maxFrameSize));
        if (this._state.mode === CH_MODE.CONFIRM) {
            // wait for basic.ack or basic.nack
            // note: Unroutable mandatory messages are acknowledged right
            //       after the basic.return method. May be ack'd out-of-order.
            const dfd = (0, util_1$2.createDeferred)();
            this._state.unconfirmed.set(this._state.deliveryCount++, dfd);
            return dfd.promise;
        }
    }
    /**
     * This is a low-level method; consider using {@link Connection#createConsumer | Connection#createConsumer()} instead.
     *
     * Begin consuming messages from a queue. Consumers last as long as the
     * channel they were declared on, or until the client cancels them. The
     * callback `cb(msg)` is called for each incoming message. You must call
     * {@link Channel#basicAck} to complete the delivery, usually after you've
     * finished some task. */
    async basicConsume(params, cb) {
        const data = await this._invoke(codec_1$1.Cmd.BasicConsume, codec_1$1.Cmd.BasicConsumeOK, { ...params, rsvp1: 0, nowait: false });
        const consumerTag = data.consumerTag;
        this._state.consumers.set(consumerTag, cb);
        return { consumerTag };
    }
    async basicCancel(params) {
        if (typeof params == 'string') {
            params = { consumerTag: params };
        }
        if (params.consumerTag == null)
            throw new TypeError('consumerTag is undefined; expected a string');
        // note: server may send a few messages before basic.cancel-ok is returned
        const res = await this._invoke(codec_1$1.Cmd.BasicCancel, codec_1$1.Cmd.BasicCancelOK, { ...params, nowait: false });
        this._state.consumers.delete(params.consumerTag);
        return res;
    }
    /**
     * This method sets the channel to use publisher acknowledgements.
     * https://www.rabbitmq.com/confirms.html#publisher-confirms
     */
    async confirmSelect() {
        await this._invoke(codec_1$1.Cmd.ConfirmSelect, codec_1$1.Cmd.ConfirmSelectOK, { nowait: false });
        this._state.mode = CH_MODE.CONFIRM;
    }
    /**
     * Don't use this unless you know what you're doing. This method is provided
     * for the sake of completeness, but you should use `confirmSelect()` instead.
     *
     * Sets the channel to use standard transactions. The client must use this
     * method at least once on a channel before using the Commit or Rollback
     * methods. Mutually exclusive with confirm mode.
     */
    async txSelect() {
        await this._invoke(codec_1$1.Cmd.TxSelect, codec_1$1.Cmd.TxSelectOK, undefined);
        this._state.mode = CH_MODE.TRANSACTION;
    }
    queueDeclare(params = '') {
        if (typeof params == 'string') {
            params = { queue: params };
        }
        return this._invoke(codec_1$1.Cmd.QueueDeclare, codec_1$1.Cmd.QueueDeclareOK, { ...params, rsvp1: 0, nowait: false });
    }
    /** Acknowledge one or more messages. */
    basicAck(params) {
        return this._invokeNowait(codec_1$1.Cmd.BasicAck, params);
    }
    basicGet(params = '') {
        if (typeof params == 'string') {
            params = { queue: params };
        }
        return this._invoke(codec_1$1.Cmd.BasicGet, codec_1$1.Cmd.BasicGetOK, { ...params, rsvp1: 0 });
    }
    /** Reject one or more incoming messages. */
    basicNack(params) {
        this._invokeNowait(codec_1$1.Cmd.BasicNack, { ...params, requeue: typeof params.requeue == 'undefined' ? true : params.requeue });
    }
    /** Specify quality of service. */
    async basicQos(params) {
        await this._invoke(codec_1$1.Cmd.BasicQos, codec_1$1.Cmd.BasicQosOK, params);
    }
    /**
     * This method asks the server to redeliver all unacknowledged messages on a
     * specified channel. Zero or more messages may be redelivered.
     */
    async basicRecover(params) {
        await this._invoke(codec_1$1.Cmd.BasicRecover, codec_1$1.Cmd.BasicRecoverOK, params);
    }
    /** Bind exchange to an exchange. */
    async exchangeBind(params) {
        if (params.destination == null)
            throw new TypeError('destination is undefined; expected a string');
        if (params.source == null)
            throw new TypeError('source is undefined; expected a string');
        await this._invoke(codec_1$1.Cmd.ExchangeBind, codec_1$1.Cmd.ExchangeBindOK, { ...params, rsvp1: 0, nowait: false });
    }
    /** Verify exchange exists, create if needed. */
    async exchangeDeclare(params) {
        if (params.exchange == null)
            throw new TypeError('exchange is undefined; expected a string');
        await this._invoke(codec_1$1.Cmd.ExchangeDeclare, codec_1$1.Cmd.ExchangeDeclareOK, { ...params, type: params.type || 'direct', rsvp1: 0, nowait: false });
    }
    /** Delete an exchange. */
    async exchangeDelete(params) {
        if (params.exchange == null)
            throw new TypeError('exchange is undefined; expected a string');
        await this._invoke(codec_1$1.Cmd.ExchangeDelete, codec_1$1.Cmd.ExchangeDeleteOK, { ...params, rsvp1: 0, nowait: false });
    }
    /** Unbind an exchange from an exchange. */
    async exchangeUnbind(params) {
        if (params.destination == null)
            throw new TypeError('destination is undefined; expected a string');
        if (params.source == null)
            throw new TypeError('source is undefined; expected a string');
        await this._invoke(codec_1$1.Cmd.ExchangeUnbind, codec_1$1.Cmd.ExchangeUnbindOK, { ...params, rsvp1: 0, nowait: false });
    }
    /**
     * This method binds a queue to an exchange. Until a queue is bound it will
     * not receive any messages. In a classic messaging model, store-and-forward
     * queues are bound to a direct exchange and subscription queues are bound to
     * a topic exchange.
     */
    async queueBind(params) {
        if (params.exchange == null)
            throw new TypeError('exchange is undefined; expected a string');
        await this._invoke(codec_1$1.Cmd.QueueBind, codec_1$1.Cmd.QueueBindOK, { ...params, nowait: false });
    }
    queueDelete(params = '') {
        if (typeof params == 'string') {
            params = { queue: params };
        }
        return this._invoke(codec_1$1.Cmd.QueueDelete, codec_1$1.Cmd.QueueDeleteOK, { ...params, rsvp1: 0, nowait: false });
    }
    queuePurge(params = '') {
        if (typeof params == 'string') {
            params = { queue: params };
        }
        return this._invoke(codec_1$1.Cmd.QueuePurge, codec_1$1.Cmd.QueuePurgeOK, { queue: params.queue, rsvp1: 0, nowait: false });
    }
    /** Unbind a queue from an exchange. */
    async queueUnbind(params) {
        if (params.exchange == null)
            throw new TypeError('exchange is undefined; expected a string');
        await this._invoke(codec_1$1.Cmd.QueueUnbind, codec_1$1.Cmd.QueueUnbindOK, { ...params, rsvp1: 0 });
    }
    /**
     * This method commits all message publications and acknowledgments performed
     * in the current transaction. A new transaction starts immediately after a
     * commit.
     */
    async txCommit() {
        await this._invoke(codec_1$1.Cmd.TxCommit, codec_1$1.Cmd.TxCommitOK, undefined);
    }
    /**
     * This method abandons all message publications and acknowledgments
     * performed in the current transaction. A new transaction starts immediately
     * after a rollback. Note that unacked messages will not be automatically
     * redelivered by rollback; if that is required an explicit recover call
     * should be issued.
     */
    async txRollback() {
        await this._invoke(codec_1$1.Cmd.TxRollback, codec_1$1.Cmd.TxRollbackOK, undefined);
    }
}
Channel$1.Channel = Channel;

var normalize = {};

Object.defineProperty(normalize, "__esModule", { value: true });
const DEFAULT_CONNECTION = 'amqp://guest:guest@localhost:5672';
const TLS_PORT = '5671';
const TCP_PORT = '5672';
const DEFAULT_OPTS = {
    acquireTimeout: 20000,
    connectionTimeout: 10000,
    frameMax: 4096,
    heartbeat: 60,
    maxChannels: 0x07ff, // (16bit number so the protocol max is 0xffff)
    retryLow: 1000,
    retryHigh: 30000,
};
/** @internal */
function normalizeOptions(raw) {
    if (typeof raw === 'string') {
        raw = { url: raw };
    }
    const props = { ...DEFAULT_OPTS, ...raw };
    let url;
    if (typeof props.url == 'string') {
        url = new URL(props.url);
        props.username = decodeURIComponent(url.username);
        props.password = decodeURIComponent(url.password);
        props.vhost = decodeURIComponent(url.pathname.split('/')[1] || '/');
        props.hostname = url.hostname;
        if (url.protocol === 'amqp:') {
            props.port = url.port || TCP_PORT;
        }
        else if (url.protocol === 'amqps:') {
            props.port = url.port || TLS_PORT;
            props.tls = props.tls || true;
        }
        else {
            throw new Error('unsupported protocol in connectionString; expected amqp: or amqps:');
        }
        const heartbeat = parseInt(url.searchParams.get('heartbeat'));
        if (!isNaN(heartbeat)) {
            props.heartbeat = Math.max(0, heartbeat);
        }
        const connectionTimeout = parseInt(url.searchParams.get('connection_timeout'));
        if (!isNaN(connectionTimeout)) {
            props.connectionTimeout = Math.max(0, connectionTimeout);
        }
        const maxChannels = parseInt(url.searchParams.get('channel_max'));
        if (!isNaN(maxChannels)) {
            props.maxChannels = Math.min(Math.max(1, maxChannels), props.maxChannels);
        }
    }
    else {
        url = new URL(DEFAULT_CONNECTION);
        if (props.hostname == null)
            props.hostname = url.hostname;
        if (props.port == null)
            props.port = url.port;
        if (props.username == null)
            props.username = url.username;
        if (props.password == null)
            props.password = url.password;
        if (props.vhost == null)
            props.vhost = '/';
    }
    if (props.tls === true)
        props.tls = {};
    if (Array.isArray(props.hosts)) {
        props.hosts = props.hosts.map((host) => {
            let [hostname, port] = host.split(':');
            if (!port) {
                port = props.tls ? TLS_PORT : TCP_PORT;
            }
            return { hostname, port };
        });
    }
    else {
        props.hosts = [{ hostname: props.hostname, port: props.port }];
    }
    assertNumber(props, 'acquireTimeout', 0);
    assertNumber(props, 'connectionTimeout', 0);
    assertNumber(props, 'frameMax', 8, 2 ** 32 - 1);
    assertNumber(props, 'heartbeat', 0);
    assertNumber(props, 'maxChannels', 1, 2 ** 16 - 1);
    assertNumber(props, 'retryLow', 1);
    assertNumber(props, 'retryHigh', 1);
    return props;
}
normalize.default = normalizeOptions;
function assertNumber(props, name, min, max) {
    const val = props[name];
    if (isNaN(val) || !Number.isFinite(val) || val < min || (max != null && val > max)) {
        throw new TypeError(max != null
            ? `${name} must be a number (${min}, ${max})`
            : `${name} must be a number >= ${min}`);
    }
}

var SortedMap$1 = {};

Object.defineProperty(SortedMap$1, "__esModule", { value: true });
class Node {
    key;
    value;
    parent;
    left;
    right;
    size;
    /** The nil node (see the Null Object Pattern), used for leaf nodes or for
     * the parent of the root node. NIL nodes are immutable. This simplifies the
     * rebalancing algorithms. This will throw a TypeError if modifications are
     * attempted. */
    static NIL = Object.freeze(new class extends Node {
        toString() { return '·'; }
        constructor() {
            super(Symbol('nil'), Symbol('nil'));
            this.size = 0;
            this.parent = this.left = this.right = this;
        }
    }());
    constructor(key, value) {
        this.key = key;
        this.value = value;
        this.parent = this.left = this.right = Node.NIL;
        this.size = 1;
    }
}
/**
 * Hirai, Y.; Yamamoto, K. (2011). "Balancing weight-balanced trees" (PDF).
 * Journal of Functional Programming. 21 (3): 287.
 * doi:10.1017/S0956796811000104.
 * https://yoichihirai.com/bst.pdf
 *
 * Delta decides whether any rotation is made at all
 */
const Δ = 3;
/** Gamma chooses a single rotation or a double rotation. */
const Γ = 2;
/**
 * Weight-Balanced Tree.
 * Insertion, deletion and iteration have O(log n) time complexity where n is
 * the number of entries in the tree. Items must have an absolute ordering.
 *
 * @internal
 */
class SortedMap {
    _root;
    _compare;
    /**
     * @param source An inital list of values
     * @param compare Sorting criterum: Should run in O(1) time
     */
    constructor(source, compare = (a, b) => a === b ? 0 : a < b ? -1 : 1) {
        this._compare = compare;
        this._root = Node.NIL;
        if (source)
            for (const [key, val] of source)
                this._insertNode(new Node(key, val));
    }
    get size() { return this._root.size; }
    get [Symbol.toStringTag]() { return 'SortedMap'; }
    /** Traverse keys, breadth-first */
    *bfs() {
        if (this._root === Node.NIL)
            return;
        let queue = [this._root];
        while (queue.length) {
            const next = queue.shift();
            yield next.key;
            if (next.left !== Node.NIL)
                queue.push(next.left);
            if (next.right !== Node.NIL)
                queue.push(next.right);
        }
    }
    toString() {
        return `[${this[Symbol.toStringTag]} size:${this.size}]`;
    }
    has(key) {
        return this._findNode(key) !== Node.NIL;
    }
    get(key) {
        const node = this._findNode(key);
        return node === Node.NIL ? undefined : node.value;
    }
    set(key, value) {
        this._insertNode(new Node(key, value));
        return this;
    }
    delete(key) {
        const node = this._findNode(key);
        const result = this._deleteNode(node);
        return result;
    }
    clear() {
        this._root = Node.NIL;
    }
    forEach(cb, self) {
        for (const [key, val] of this.entries())
            cb.call(self, val, key, this);
    }
    [Symbol.iterator]() {
        return this.entries();
    }
    values() {
        return this._iterator(node => node.value);
    }
    keys() {
        return this._iterator(node => node.key);
    }
    entries() {
        return this._iterator(node => [node.key, node.value]);
    }
    /** Return a missing value from the set. If {4} then result = 3 so it's not
     * always the LOWEST missing number but that's not necessary here. */
    pick(min = 1) {
        // n.b.
        // to find the LOWEST missing number in [min ... STORED_VALUES] (inclusive)
        // requires checking the value at rank 0 at the cost of an extra
        // ~O(log n) steps, or extra book-keeping to track the stored min value.
        if (this._root === Node.NIL)
            return min;
        let dir = 0;
        // FIXME Kind of a rude typecast, but this only works when K is a number.
        //       Maybe a subclass makes more sense.
        let node = this._root;
        let parent = node;
        do {
            dir = (node.left.size + min) - node.key;
            parent = node;
            if (dir < 0) {
                node = node.left;
            }
            else {
                min += node.left.size + 1;
                node = node.right;
            }
        } while (node !== Node.NIL);
        return dir < 0 ? parent.key - 1 : parent.key + 1;
    }
    _iterator(get) {
        const tree = this;
        let node = Node.NIL;
        let started = false;
        return {
            [Symbol.iterator]() { return this; },
            next() {
                if (node === Node.NIL)
                    node = tree._firstNode();
                if (started)
                    node = tree._nextNode(node);
                started = true;
                const done = node === Node.NIL;
                const value = done ? undefined : get(node);
                return { done, value };
                //                     ^^^^^^^^^^^^^^^^^^^^
                // See https://github.com/Microsoft/TypeScript/issues/11375
            }
        };
    }
    _firstNode(node = this._root) {
        while (node.left !== Node.NIL)
            node = node.left;
        return node;
    }
    _nextNode(node) {
        if (node === Node.NIL)
            return node;
        if (node.right !== Node.NIL)
            return this._firstNode(node.right);
        let parent = node.parent;
        while (parent !== Node.NIL && node === parent.right) {
            node = parent;
            parent = parent.parent;
        }
        return parent;
    }
    _findNode(key, node = this._root) {
        let dir;
        while (node !== Node.NIL && (dir = this._compare(key, node.key))) {
            node = dir < 0 ? node.left : node.right;
        }
        return node;
    }
    _leftRotate(node) {
        // assert node !== Node.NIL
        // assert node.right !== Node.NIL
        const child = node.right;
        node.right = child.left;
        // don't attempt to modify NIL
        if (child.left !== Node.NIL)
            child.left.parent = node;
        child.parent = node.parent;
        if (node === this._root)
            this._root = child;
        else if (node === node.parent.left)
            node.parent.left = child;
        else
            node.parent.right = child;
        node.parent = child;
        child.left = node;
        child.size = node.size;
        node.size = node.left.size + node.right.size + 1;
        return child;
    }
    _rightRotate(node) {
        // assert node !== Node.NIL
        // assert node.left !== Node.NIL
        const child = node.left;
        node.left = child.right;
        // don't attempt to modify NIL
        if (child.right !== Node.NIL)
            child.right.parent = node;
        child.parent = node.parent;
        if (node === this._root)
            this._root = child;
        else if (node === node.parent.left)
            node.parent.left = child;
        else
            node.parent.right = child;
        node.parent = child;
        child.right = node;
        child.size = node.size;
        node.size = node.left.size + node.right.size + 1;
        return child;
    }
    _isUnbalanced(a, b) {
        return Δ * (a.size + 1) < b.size + 1;
    }
    _isSingle(a, b) {
        return a.size + 1 < Γ * (b.size + 1);
    }
    _insertNode(node) {
        // assert node !== Node.NIL
        if (this._root === Node.NIL) {
            this._root = node;
            return;
        }
        let parent = Node.NIL;
        let root = this._root;
        let dir;
        // find insertion point
        do {
            dir = this._compare(node.key, root.key);
            if (dir === 0) {
                return; // element is already in the tree!
            }
            parent = root;
            root = dir < 0 ? root.left : root.right;
        } while (root !== Node.NIL);
        // replace leaf
        node.parent = parent;
        if (dir < 0)
            parent.left = node;
        else
            parent.right = node;
        // walk back down the tree and rebalance
        do {
            parent.size += 1;
            if (parent.right === node) {
                if (this._isUnbalanced(parent.left, parent.right)) {
                    if (this._isSingle(parent.right.left, parent.right.right)) {
                        parent = this._leftRotate(parent);
                    }
                    else {
                        this._rightRotate(parent.right);
                        parent = this._leftRotate(parent);
                    }
                }
            }
            else {
                if (this._isUnbalanced(parent.right, parent.left)) {
                    if (this._isSingle(parent.left.right, parent.left.left)) {
                        parent = this._rightRotate(parent);
                    }
                    else {
                        this._leftRotate(parent.left);
                        parent = this._rightRotate(parent);
                    }
                }
            }
            node = parent;
            parent = parent.parent;
        } while (parent !== Node.NIL);
        // in case the root node was rotated away
        this._root = node;
    }
    _deleteNode(node) {
        if (node === Node.NIL)
            return false;
        let child;
        let parent;
        if (node.left !== Node.NIL && node.right !== Node.NIL) {
            // find the first child with a NIL left-pointer (in the right-hand tree)
            // this will replace the deleted node
            let next = node.right;
            while (next.left !== Node.NIL)
                next = next.left;
            next.left = node.left;
            next.left.parent = next;
            if (node === this._root)
                this._root = next;
            else if (node === node.parent.left)
                node.parent.left = next;
            else
                node.parent.right = next;
            child = next.right; // may be NIL
            parent = next.parent;
            if (node === parent)
                parent = next;
            else {
                if (child !== Node.NIL)
                    child.parent = parent;
                parent.left = child;
                next.right = node.right;
                node.right.parent = next;
            }
            next.parent = node.parent;
        }
        else {
            child = node.left === Node.NIL ? node.right : node.left; // may be NIL
            parent = node.parent; // may be NIL
            if (child !== Node.NIL)
                child.parent = parent;
            if (node === this._root)
                this._root = child;
            else if (parent.left === node)
                parent.left = child;
            else
                parent.right = child;
        }
        node = child;
        while (parent !== Node.NIL) {
            parent.size = parent.left.size + parent.right.size + 1;
            // left rotation is performed when an element is deleted from the left subtree
            if (parent.left === node) {
                if (this._isUnbalanced(parent.left, parent.right)) {
                    if (this._isSingle(parent.right.left, parent.right.right)) {
                        parent = this._leftRotate(parent);
                    }
                    else {
                        this._rightRotate(parent.right);
                        parent = this._leftRotate(parent);
                    }
                }
            }
            else {
                if (this._isUnbalanced(parent.right, parent.left)) {
                    if (this._isSingle(parent.left.right, parent.left.left)) {
                        parent = this._rightRotate(parent);
                    }
                    else {
                        this._leftRotate(parent.left);
                        parent = this._rightRotate(parent);
                    }
                }
            }
            node = parent;
            parent = parent.parent;
        }
        // in case the root node was rotated away
        this._root = node;
        return true;
    }
}
SortedMap$1.default = SortedMap;

var Consumer = {};

(function (exports) {
	var __importDefault = (commonjsGlobal && commonjsGlobal.__importDefault) || function (mod) {
	    return (mod && mod.__esModule) ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Consumer = exports.ConsumerStatus = exports.PREFETCH_EVENT = exports.IDLE_EVENT = void 0;
	const node_events_1 = __importDefault(require$$2$1);
	const util_1 = util;
	/** @internal */
	exports.IDLE_EVENT = Symbol('idle');
	/** @internal */
	exports.PREFETCH_EVENT = Symbol('prefetch');
	var ConsumerStatus;
	(function (ConsumerStatus) {
	    /** BasicAck */
	    ConsumerStatus[ConsumerStatus["ACK"] = 0] = "ACK";
	    /** BasicNack(requeue=true). The message is returned to the queue. */
	    ConsumerStatus[ConsumerStatus["REQUEUE"] = 1] = "REQUEUE";
	    /** BasicNack(requeue=false). The message is sent to the
	     * configured dead-letter exchange, if any, or discarded. */
	    ConsumerStatus[ConsumerStatus["DROP"] = 2] = "DROP";
	})(ConsumerStatus || (exports.ConsumerStatus = ConsumerStatus = {}));
	/**
	 * @see {@link Connection#createConsumer | Connection#createConsumer()}
	 * @see {@link ConsumerProps}
	 * @see {@link ConsumerHandler}
	 *
	 * This will create a dedicated Channel, declare a queue, declare exchanges,
	 * declare bindings, establish QoS, and finally start consuming messages. If
	 * the connection is reset, then all of this setup will re-run on a new
	 * Channel. This uses the same retry-delay logic as the Connection.
	 *
	 * The callback is called for each incoming message. If it throws an error then
	 * the message is rejected (BasicNack) and possibly requeued, or sent to a
	 * dead-letter exchange. The error is then emitted as an event. The callback
	 * can also return a numeric status code to control the ACK/NACK behavior. The
	 * {@link ConsumerStatus} enum is provided for convenience.
	 *
	 * ACK/NACK behavior when the callback:
	 * - throws an error - BasicNack(requeue=ConsumerProps.requeue)
	 * - returns 0 or undefined - BasicAck
	 * - returns 1 - BasicNack(requeue=true)
	 * - returns 2 - BasicNack(requeue=false)
	 *
	 * About concurency: For best performance, you'll likely want to start with
	 * concurrency=X and qos.prefetchCount=2X. In other words, up to 2X messages
	 * are loaded into memory, but only X ConsumerHandlers are running
	 * concurrently. The consumer won't need to wait for a new message if one has
	 * alredy been prefetched, minimizing idle time. With more worker processes,
	 * you will want a lower prefetchCount to avoid worker-starvation.
	 *
	 * The 2nd argument of `handler(msg, reply)` can be used to reply to RPC
	 * requests. e.g. `await reply('my-response-body')`. This acts like
	 * basicPublish() except the message body comes first. Some fields are also set
	 * automaticaly. See ConsumerHandler for more detail.
	 *
	 * This is an EventEmitter that may emit errors. Also, since this wraps a
	 * Channel, this must be closed before closing the Connection.
	 *
	 * @example
	 * ```
	 * const sub = rabbit.createConsumer({queue: 'my-queue'}, async (msg, reply) => {
	 *   console.log(msg)
	 *   // ... do some work ...
	 *
	 *   // optionally reply to an RPC-type message
	 *   await reply('my-response-data')
	 *
	 *   // optionally return a status code
	 *   if (somethingBad) {
	 *     return ConsumerStatus.DROP
	 *   }
	 * })
	 *
	 * sub.on('error', (err) => {
	 *   console.log('consumer error (my-queue)', err)
	 * })
	 *
	 * // when closing the application
	 * await sub.close()
	 * ```
	 */
	class Consumer extends node_events_1.default {
	    /** Maximum number of messages to process at once. Non-zero positive integer.
	     * Writeable. */
	    concurrency;
	    /** Get current queue name. If the queue name was left blank in
	     * ConsumerProps, then this will change whenever the channel is reset, as the
	     * name is randomly generated. */
	    get queue() { return this._queue; }
	    /** Get the current consumer ID. If generated by the broker, then this will
	     * change each time the consumer is ready. */
	    get consumerTag() { return this._consumerTag; }
	    /** Some statistics about this Consumer */
	    stats = {
	        /** Total acknowledged messages */
	        acknowledged: 0,
	        /** Total messages rejected BasicNack(requeue=false) */
	        dropped: 0,
	        /** Size of the queue when this consumer started */
	        initialMessageCount: 0,
	        /** How many messages are in memory, waiting to be processed */
	        prefetched: 0,
	        /** Total messages rejected with BasicNack(requeue=true) */
	        requeued: 0,
	    };
	    /** @internal */
	    _conn;
	    /** @internal */
	    _ch;
	    /** @internal */
	    _handler;
	    /** @internal */
	    _props;
	    /** @internal */
	    _queue = '';
	    /** @internal */
	    _consumerTag = '';
	    /** @internal */
	    _prefetched = [];
	    /** @internal */
	    _processing = new Set();
	    /** @internal */
	    _readyState = util_1.READY_STATE.CONNECTING;
	    /** @internal */
	    _retryCount = 1;
	    /** @internal */
	    _retryTimer;
	    /** @internal */
	    _pendingSetup;
	    /** @internal */
	    constructor(conn, props, handler) {
	        super();
	        this._conn = conn;
	        this._handler = handler;
	        this._props = props;
	        this._connect = this._connect.bind(this);
	        this.concurrency = props.concurrency && Number.isInteger(props.concurrency)
	            ? Math.max(1, props.concurrency) : Infinity;
	        Object.defineProperty(this.stats, 'prefetched', { get: () => this._prefetched.length });
	        if (props.lazy) {
	            this._readyState = util_1.READY_STATE.CLOSED;
	        }
	        else {
	            this._connect();
	        }
	    }
	    /** @internal */
	    _makeReplyfn(req) {
	        return (body, envelope) => {
	            if (!req.replyTo)
	                throw new Error('attempted to reply to a non-RPC message');
	            return this._ch.basicPublish({
	                correlationId: req.correlationId,
	                ...envelope,
	                routingKey: req.replyTo,
	            }, body);
	        };
	    }
	    /** @internal */
	    async _execHandler(msg) {
	        // n.b. message MUST ack/nack on the same channel to which it is delivered
	        const { _ch: ch } = this;
	        if (!ch)
	            return; // satisfy the type checker but this should never happen
	        try {
	            let retval;
	            try {
	                retval = await this._handler(msg, this._makeReplyfn(msg));
	            }
	            catch (err) {
	                if (!this._props.noAck) {
	                    ch.basicNack({ deliveryTag: msg.deliveryTag, requeue: this._props.requeue });
	                    if (this._props.requeue) {
	                        ++this.stats.requeued;
	                    }
	                    else {
	                        ++this.stats.dropped;
	                    }
	                }
	                this.emit('error', err);
	                return;
	            }
	            if (!this._props.noAck) {
	                if (retval === ConsumerStatus.DROP) {
	                    ch.basicNack({ deliveryTag: msg.deliveryTag, requeue: false });
	                    ++this.stats.dropped;
	                }
	                else if (retval === ConsumerStatus.REQUEUE) {
	                    ch.basicNack({ deliveryTag: msg.deliveryTag, requeue: true });
	                    ++this.stats.requeued;
	                }
	                else {
	                    ch.basicAck({ deliveryTag: msg.deliveryTag });
	                    ++this.stats.acknowledged;
	                }
	            }
	        }
	        catch (err) {
	            // ack/nack can fail if the connection dropped
	            err.message = 'failed to ack/nack message; ' + err.message;
	            this.emit('error', err);
	        }
	    }
	    /** @internal*/
	    _prepareMessage(msg) {
	        const prom = this._execHandler(msg);
	        this._processing.add(prom);
	        prom.finally(() => {
	            this._processing.delete(prom);
	            if (this._processing.size < this.concurrency && this._prefetched.length) {
	                this._prepareMessage(this._prefetched.shift());
	            }
	            else if (!this._processing.size) {
	                this.emit(exports.IDLE_EVENT);
	            }
	        });
	    }
	    /** @internal */
	    async _setup() {
	        // wait for in-progress jobs to complete before retrying
	        await Promise.allSettled(this._processing);
	        if (this._readyState === util_1.READY_STATE.CLOSING) {
	            return; // abort setup
	        }
	        let { _ch: ch, _props: props } = this;
	        if (!ch || !ch.active) {
	            ch = this._ch = await this._conn.acquire();
	            ch.once('close', () => {
	                if (!this._props.noAck) {
	                    // clear any buffered messages since they can't be ACKd on a new channel
	                    this._prefetched = [];
	                }
	                if (this._readyState >= util_1.READY_STATE.CLOSING) {
	                    return;
	                }
	                this._readyState = util_1.READY_STATE.CONNECTING;
	                this._reconnect();
	                // the channel may close unexpectedly when:
	                // - setup failed                               (error already emitted)
	                // - connection lost                            (error already emitted)
	                // - tried to ack/nack with invalid deliveryTag (error already emitted)
	                // - channel forced to close by server action   (NOT emitted)
	                //this.emit('error', err)
	            });
	        }
	        const { queue, messageCount } = await ch.queueDeclare({ ...props.queueOptions, queue: props.queue });
	        this.stats.initialMessageCount = messageCount;
	        this._queue = queue;
	        if (props.exchanges)
	            for (const params of props.exchanges) {
	                await ch.exchangeDeclare(params);
	            }
	        if (props.queueBindings)
	            for (const params of props.queueBindings) {
	                await ch.queueBind(params);
	            }
	        if (props.exchangeBindings)
	            for (const params of props.exchangeBindings) {
	                await ch.exchangeBind(params);
	            }
	        if (props.qos)
	            await ch.basicQos(props.qos);
	        const { consumerTag } = await ch.basicConsume(props, (msg) => {
	            const shouldBuffer = (this._prefetched.length) // don't skip the queue
	                || (this._processing.size >= this.concurrency) // honor the concurrency limit
	                || (!this._props.noAck && this._readyState === util_1.READY_STATE.CLOSING); // prevent new work while closing
	            if (shouldBuffer && Number.isFinite(this.concurrency)) {
	                this._prefetched.push(msg);
	                this.emit(exports.PREFETCH_EVENT);
	            }
	            else {
	                this._prepareMessage(msg);
	            }
	        });
	        this._consumerTag = consumerTag;
	        // n.b. a "basic.cancel" event means the Channel is still usable
	        //      e.g. for ack/nack
	        // server will send this if the queue is deleted
	        ch.once('basic.cancel', (tag, err) => {
	            if (this._readyState === util_1.READY_STATE.CLOSING)
	                return;
	            this._readyState = util_1.READY_STATE.CONNECTING;
	            this._reconnect();
	            this.emit('error', err);
	        });
	        this._retryCount = 1;
	        // close() may have been called while setup() is running
	        if (this._readyState === util_1.READY_STATE.CONNECTING)
	            this._readyState = util_1.READY_STATE.OPEN;
	        // user errors in attached event handlers should not cause setup to fail
	        process.nextTick(() => this.emit('ready'));
	    }
	    /** @internal */
	    _connect() {
	        this._retryTimer = undefined;
	        this._pendingSetup = this._setup().finally(() => {
	            this._pendingSetup = undefined;
	        }).catch(err => {
	            if (this._readyState >= util_1.READY_STATE.CLOSING)
	                return;
	            this._readyState = util_1.READY_STATE.CONNECTING;
	            err.message = 'consumer setup failed; ' + err.message;
	            // suppress spam if, for example, passive queue declaration is failing
	            if (this._retryCount <= 1)
	                process.nextTick(() => { this.emit('error', err); });
	            this._reconnect();
	        });
	    }
	    /** @internal
	     * reconnect when:
	     * - setup fails
	     * - basic.cancel
	     * - channel closed
	     * - connection closed (triggers channel close)
	     */
	    _reconnect() {
	        this._consumerTag = '';
	        this._queue = '';
	        if (this._conn._state.readyState >= util_1.READY_STATE.CLOSING || this._retryTimer || this._pendingSetup)
	            return;
	        const { retryLow, retryHigh } = this._conn._opt;
	        const delay = (0, util_1.expBackoff)(retryLow, retryHigh, this._retryCount++);
	        this._retryTimer = setTimeout(this._connect, delay);
	    }
	    /**
	     * Starts the consumer if it is currently stopped.
	     * When created with lazy=true, begin consuming.
	     */
	    start() {
	        if (this._readyState !== util_1.READY_STATE.CLOSED) {
	            return;
	        }
	        this._readyState = util_1.READY_STATE.CONNECTING;
	        this._connect();
	    }
	    /** Stop consuming messages. Close the channel once all pending message
	     * handlers have settled. If called while the Connection is reconnecting,
	     * then this may be delayed by {@link ConnectionOptions.acquireTimeout} */
	    async close() {
	        if (this._readyState === util_1.READY_STATE.CLOSED)
	            return;
	        this._readyState = util_1.READY_STATE.CLOSING;
	        if (this._retryTimer)
	            clearTimeout(this._retryTimer);
	        this._retryTimer = undefined;
	        await this._pendingSetup;
	        const { _ch: ch } = this;
	        if (ch?.active && this._consumerTag) {
	            // n.b. Some messages may arrive before basic.cancel-ok is received
	            const consumerTag = this._consumerTag;
	            this._consumerTag = '';
	            await ch.basicCancel({ consumerTag });
	        }
	        if (!this._props.noAck && this._prefetched.length) {
	            // any buffered/unacknowledged messages will be redelivered by the broker
	            // after the channel is closed
	            this._prefetched = [];
	        }
	        else if (this._props.noAck && this._prefetched.length) {
	            // in this case, buffered messages will not be requeued so we must wait
	            // for them to process
	            await (0, util_1.expectEvent)(this, exports.IDLE_EVENT);
	        }
	        await Promise.allSettled(this._processing);
	        await ch?.close();
	        this._readyState = util_1.READY_STATE.CLOSED;
	    }
	}
	exports.Consumer = Consumer; 
} (Consumer));

var RPCClient$1 = {};

Object.defineProperty(RPCClient$1, "__esModule", { value: true });
RPCClient$1.RPCClient = void 0;
const util_1$1 = util;
const exception_1$1 = exception;
const DEFAULT_TIMEOUT = 30000;
/**
 * @see {@link Connection#createRPCClient | Connection#createRPCClient()}
 * @see {@link RPCProps}
 * @see {@link https://www.rabbitmq.com/direct-reply-to.html}
 *
 * This will create a single "client" `Channel` on which you may publish
 * messages and listen for direct responses. This can allow, for example, two
 * micro-services to communicate with each other using RabbitMQ as the
 * middleman instead of directly via HTTP.
 *
 * If you're using the createConsumer() helper, then you can reply to RPC
 * requests simply by using the `reply()` argument of
 * the {@link ConsumerHandler}.
 *
 * Also, since this wraps a Channel, this must be closed before closing the
 * Connection: `RPCClient.close()`
 *
 * @example
 * ```
 * // rpc-client.js
 * const rabbit = new Connection()
 *
 * const rpcClient = rabbit.createRPCClient({confirm: true})
 *
 * const res = await rpcClient.send('my-rpc-queue', 'ping')
 * console.log('response:', res.body) // pong
 *
 * await rpcClient.close()
 * await rabbit.close()
 * ```
 *
 * ```
 * // rpc-server.js
 * const rabbit = new Connection()
 *
 * const rpcServer = rabbit.createConsumer({
 *   queue: 'my-rpc-queue'
 * }, async (req, reply) => {
 *   console.log('request:', req.body)
 *   await reply('pong')
 * })
 *
 * process.on('SIGINT', async () => {
 *   await rpcServer.close()
 *   await rabbit.close()
 * })
 * ```
 *
 * If you're communicating with a different rabbitmq client implementation
 * (maybe in a different language) then the consumer should send responses
 * like this:
 * ```
 * ch.basicPublish({
 *   routingKey: req.replyTo,
 *   correlationId: req.correlationId,
 *   exchange: ""
 * }, responseBody)
 * ```
 */
class RPCClient {
    /** @internal */
    _conn;
    /** @internal */
    _ch;
    /** @internal */
    _props;
    /** @internal */
    _requests = new Map();
    /** @internal */
    _pendingSetup;
    /** @internal CorrelationId counter */
    _id = 0;
    /** True while the client has not been explicitly closed */
    active = true;
    /** @internal */
    constructor(conn, props) {
        this._conn = conn;
        this._props = props;
    }
    /** @internal */
    async _setup() {
        let { _ch: ch, _props: props } = this;
        if (!ch || !ch.active) {
            ch = this._ch = await this._conn.acquire();
            ch.once('close', () => {
                // request-response MUST be on the same channel, so if the channel dies
                // so does all pending requests
                for (const dfd of this._requests.values())
                    dfd.reject(new exception_1$1.AMQPChannelError('RPC_CLOSED', 'RPC channel closed unexpectedly'));
                this._requests.clear();
            });
        }
        if (props.queues)
            for (const params of props.queues) {
                await ch.queueDeclare(params);
            }
        if (props.exchanges)
            for (const params of props.exchanges) {
                await ch.exchangeDeclare(params);
            }
        if (props.queueBindings)
            for (const params of props.queueBindings) {
                await ch.queueBind(params);
            }
        if (props.exchangeBindings)
            for (const params of props.exchangeBindings) {
                await ch.exchangeBind(params);
            }
        if (props.confirm) {
            await ch.confirmSelect();
        }
        // n.b. This is not a real queue & this consumer will not appear in the management UI
        await ch.basicConsume({
            noAck: true,
            queue: 'amq.rabbitmq.reply-to'
        }, (res) => {
            if (res.correlationId) {
                // resolve an exact request
                const dfd = this._requests.get(res.correlationId);
                if (dfd != null) {
                    this._requests.delete(res.correlationId);
                    dfd.resolve(res);
                }
            }
            // otherwise the response is discarded
        });
        // ch.once('basic.cancel') shouldn't happen
    }
    async send(envelope, body) {
        const maxAttempts = this._props.maxAttempts || 1;
        let attempts = 0;
        while (true)
            try {
                if (!this.active)
                    throw new exception_1$1.AMQPChannelError('RPC_CLOSED', 'RPC client is closed');
                if (!this._ch?.active) {
                    if (!this._pendingSetup)
                        this._pendingSetup = this._setup().finally(() => { this._pendingSetup = undefined; });
                    await this._pendingSetup;
                }
                const id = String(++this._id);
                const timeout = this._props.timeout == null ? DEFAULT_TIMEOUT : this._props.timeout;
                await this._ch.basicPublish({
                    ...(typeof envelope === 'string' ? { routingKey: envelope } : envelope),
                    replyTo: 'amq.rabbitmq.reply-to',
                    correlationId: id,
                    expiration: String(timeout)
                }, body);
                const dfd = (0, util_1$1.createDeferred)();
                const timer = setTimeout(() => {
                    dfd.reject(new exception_1$1.AMQPError('RPC_TIMEOUT', 'RPC response timed out'));
                    this._requests.delete(id);
                }, timeout);
                this._requests.set(id, dfd);
                // remember to stop the timer if we get a response or if there is some other failure
                return await dfd.promise.finally(() => { clearTimeout(timer); });
            }
            catch (err) {
                if (++attempts >= maxAttempts) {
                    Error.captureStackTrace(err); // original async trace is likely not useful to users
                    throw err;
                }
                // else loop; notify with event?
            }
    }
    /** @deprecated Alias for {@link RPCClient#send} */
    publish(envelope, body) {
        return this.send(envelope, body);
    }
    /** Stop consuming messages. Close the channel once all pending message
     * handlers have settled. If called while the Connection is reconnecting,
     * then this may be delayed by {@link ConnectionOptions.acquireTimeout} */
    async close() {
        this.active = false;
        try {
            await this._pendingSetup;
            await Promise.allSettled(Array.from(this._requests.values()).map(dfd => dfd.promise));
        }
        catch (err) {
            // do nothing; task failed successfully
        }
        // Explicitly not cancelling the consumer; it's not necessary.
        await this._ch?.close();
    }
}
RPCClient$1.RPCClient = RPCClient;

var __importDefault = (commonjsGlobal && commonjsGlobal.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(Connection$2, "__esModule", { value: true });
Connection$2.Connection = void 0;
const node_net_1 = __importDefault(require$$0);
const node_tls_1 = __importDefault(require$$1$1);
const node_events_1 = __importDefault(require$$2$1);
const exception_1 = exception;
const util_1 = util;
const codec_1 = codec;
const Channel_1 = Channel$1;
const normalize_1 = __importDefault(normalize);
const SortedMap_1 = __importDefault(SortedMap$1);
const Consumer_1 = Consumer;
const RPCClient_1 = RPCClient$1;
/** @internal */
function raceWithTimeout(promise, ms, msg) {
    let timer;
    return Promise.race([
        promise,
        new Promise((resolve, reject) => timer = setTimeout(() => reject(new exception_1.AMQPError('TIMEOUT', msg)), ms))
    ]).finally(() => {
        clearTimeout(timer);
    });
}
const CLIENT_PROPERTIES = {
    product: 'rabbitmq-client',
    version: '4.5.3',
    platform: `node.js-${process.version}`,
    capabilities: {
        'basic.nack': true,
        'connection.blocked': true,
        publisher_confirms: true,
        exchange_exchange_bindings: true,
        // https://www.rabbitmq.com/consumer-cancel.html
        consumer_cancel_notify: true,
        // https://www.rabbitmq.com/auth-notification.html
        authentication_failure_close: true,
    }
};
/**
 * This represents a single connection to a RabbitMQ server (or cluster). Once
 * created, it will immediately attempt to establish a connection. When the
 * connection is lost, for whatever reason, it will reconnect. This implements
 * the EventEmitter interface and may emit `error` events. Close it with
 * {@link Connection#close | Connection#close()}
 *
 * @example
 * ```
 * const rabbit = new Connection('amqp://guest:guest@localhost:5672')
 * rabbit.on('error', (err) => {
 *   console.log('RabbitMQ connection error', err)
 * })
 * rabbit.on('connection', () => {
 *   console.log('RabbitMQ (re)connected')
 * })
 * process.on('SIGINT', () => {
 *   rabbit.close()
 * })
 * ```
 */
let Connection$1 = class Connection extends node_events_1.default {
    /** @internal */
    _opt;
    /** @internal */
    _socket;
    /** @internal */
    _state;
    constructor(propsOrUrl) {
        super();
        this._connect = this._connect.bind(this);
        this._opt = (0, normalize_1.default)(propsOrUrl);
        this._state = {
            channelMax: this._opt.maxChannels,
            frameMax: this._opt.frameMax,
            onEmpty: (0, util_1.createDeferred)(),
            // ignore unhandled rejection e.g. no one is waiting for a channel
            onConnect: (0, util_1.createDeferred)(true),
            connectionTimer: undefined,
            hostIndex: 0,
            leased: new SortedMap_1.default(),
            readyState: util_1.READY_STATE.CONNECTING,
            retryCount: 1,
            retryTimer: undefined
        };
        this._socket = this._connect();
    }
    /**
     * Allocate and return a new AMQP Channel. You MUST close the channel
     * yourself. Will wait for connect/reconnect when necessary.
     */
    async acquire() {
        if (this._state.readyState >= util_1.READY_STATE.CLOSING)
            throw new exception_1.AMQPConnectionError('CLOSING', 'channel creation failed; connection is closing');
        if (this._state.readyState === util_1.READY_STATE.CONNECTING) {
            // TODO also wait for connection.unblocked
            await raceWithTimeout(this._state.onConnect.promise, this._opt.acquireTimeout, 'channel aquisition timed out').catch(util_1.recaptureAndThrow);
        }
        // choosing an available channel id from this SortedMap is certainly slower
        // than incrementing a counter from 1 to MAX_CHANNEL_ID. However
        // this method allows for safely reclaiming old IDs once MAX_CHANNEL_ID+1
        // channels have been created. Also this function runs in O(log n) time
        // where n <= 0xffff. Which means ~16 tree nodes in the worst case. So it
        // shouldn't be noticable. And who needs that many Channels anyway!?
        const id = this._state.leased.pick();
        if (id > this._state.channelMax)
            throw new Error('maximum number of AMQP Channels already open');
        const ch = new Channel_1.Channel(id, this);
        this._state.leased.set(id, ch);
        ch.once('close', () => {
            this._state.leased.delete(id);
            this._checkEmpty();
        });
        await ch._invoke(codec_1.Cmd.ChannelOpen, codec_1.Cmd.ChannelOpenOK, { rsvp1: '' });
        return ch;
    }
    /**
     * Wait for channels to close and then end the connection. Will not
     * automatically close any channels, giving you the chance to ack/nack any
     * outstanding messages while preventing new channels.
     */
    async close() {
        if (this._state.readyState === util_1.READY_STATE.CLOSED)
            return;
        if (this._state.readyState === util_1.READY_STATE.CLOSING)
            return new Promise(resolve => this._socket.once('close', resolve));
        if (this._state.readyState === util_1.READY_STATE.CONNECTING) {
            this._state.readyState = util_1.READY_STATE.CLOSING;
            if (this._state.retryTimer)
                clearTimeout(this._state.retryTimer);
            this._state.retryTimer = undefined;
            this._state.onConnect.reject(new exception_1.AMQPConnectionError('CLOSING', 'channel creation failed; connection is closing'));
            this._socket.destroy();
            return;
        }
        this._state.readyState = util_1.READY_STATE.CLOSING;
        if (this._state.lazyChannel instanceof Promise) {
            this._state.lazyChannel.then(ch => ch.close());
        }
        else if (this._state.lazyChannel) {
            this._state.lazyChannel.close();
        }
        this._checkEmpty();
        // wait for all channels to close
        await this._state.onEmpty.promise;
        clearInterval(this._state.heartbeatTimer);
        this._state.heartbeatTimer = undefined;
        // might have transitioned to CLOSED while waiting for channels
        if (this._socket.writable) {
            this._writeMethod({
                type: codec_1.FrameType.METHOD,
                channelId: 0,
                methodId: codec_1.Cmd.ConnectionClose,
                params: { replyCode: 200, methodId: 0, replyText: '' }
            });
            this._socket.end();
            await new Promise(resolve => this._socket.once('close', resolve));
        }
    }
    /** Immediately destroy the connection. All channels are closed. All pending
     * actions are rejected. */
    unsafeDestroy() {
        if (this._state.readyState === util_1.READY_STATE.CLOSED)
            return;
        // CLOSING, CONNECTING, OPEN
        this._state.readyState = util_1.READY_STATE.CLOSING;
        if (this._state.retryTimer)
            clearTimeout(this._state.retryTimer);
        this._state.retryTimer = undefined;
        this._state.onConnect.reject(new exception_1.AMQPConnectionError('CLOSING', 'channel creation failed; connection is closing'));
        this._socket.destroy();
    }
    /** Create a message consumer that can recover from dropped connections.
     * @param cb Process an incoming message. */
    createConsumer(props, cb) {
        return new Consumer_1.Consumer(this, props, cb);
    }
    /** This will create a single "client" `Channel` on which you may publish
     * messages and listen for direct responses. This can allow, for example, two
     * micro-services to communicate with each other using RabbitMQ as the
     * middleman instead of directly via HTTP. */
    createRPCClient(props) {
        return new RPCClient_1.RPCClient(this, props || {});
    }
    /**
     * Create a message publisher that can recover from dropped connections.
     * This will create a dedicated Channel, declare queues, declare exchanges,
     * and declare bindings. If the connection is reset, then all of this setup
     * will rerun on a new Channel. This also supports retries.
     */
    createPublisher(props = {}) {
        let _ch;
        let pendingSetup;
        let isClosed = false;
        let maxAttempts = props.maxAttempts || 1;
        const emitter = new node_events_1.default();
        const setup = async () => {
            const ch = _ch = await this.acquire();
            ch.on('basic.return', (msg) => emitter.emit('basic.return', msg));
            if (props.queues)
                for (const params of props.queues) {
                    await ch.queueDeclare(params);
                }
            if (props.exchanges)
                for (const params of props.exchanges) {
                    await ch.exchangeDeclare(params);
                }
            if (props.queueBindings)
                for (const params of props.queueBindings) {
                    await ch.queueBind(params);
                }
            if (props.exchangeBindings)
                for (const params of props.exchangeBindings) {
                    await ch.exchangeBind(params);
                }
            if (props.confirm)
                await ch.confirmSelect();
            return ch;
        };
        const send = async (envelope, body) => {
            let attempts = 0;
            while (true)
                try {
                    if (isClosed)
                        throw new exception_1.AMQPChannelError('CLOSED', 'publisher is closed');
                    if (!_ch?.active) {
                        if (!pendingSetup)
                            pendingSetup = setup().finally(() => { pendingSetup = undefined; });
                        _ch = await pendingSetup;
                    }
                    return await _ch.basicPublish(envelope, body);
                }
                catch (err) {
                    Error.captureStackTrace(err); // original async trace is likely not useful to users
                    if (++attempts >= maxAttempts) {
                        throw err;
                    }
                    else { // notify & loop
                        emitter.emit('retry', err, envelope, body);
                    }
                }
        };
        return Object.assign(emitter, {
            publish: send,
            send: send,
            close() {
                isClosed = true;
                if (pendingSetup)
                    return pendingSetup.then(ch => ch.close());
                return _ch ? _ch.close() : Promise.resolve();
            }
        });
    }
    /** @internal */
    _connect() {
        this._state.retryTimer = undefined;
        // get next host, round-robin
        const host = this._opt.hosts[this._state.hostIndex];
        this._state.hostIndex = (this._state.hostIndex + 1) % this._opt.hosts.length;
        // assume any previously opened socket is already fully closed
        let socket;
        if (this._opt.tls) {
            socket = node_tls_1.default.connect({
                port: host.port,
                host: host.hostname,
                ...this._opt.socket,
                ...this._opt.tls
            });
        }
        else {
            socket = node_net_1.default.connect({
                port: host.port,
                host: host.hostname,
                ...this._opt.socket
            });
        }
        this._socket = socket;
        socket.setNoDelay(!!this._opt.noDelay);
        let connectionError;
        // create connection timeout
        if (this._opt.connectionTimeout > 0) {
            this._state.connectionTimer = setTimeout(() => {
                socket.destroy(new exception_1.AMQPConnectionError('CONNECTION_TIMEOUT', 'connection timed out'));
            }, this._opt.connectionTimeout);
        }
        socket.on('error', err => {
            connectionError = connectionError || err;
        });
        socket.on('close', () => {
            if (this._state.readyState === util_1.READY_STATE.CLOSING) {
                this._state.readyState = util_1.READY_STATE.CLOSED;
                this._reset(connectionError || new exception_1.AMQPConnectionError('CLOSING', 'connection is closed'));
            }
            else {
                connectionError = connectionError || new exception_1.AMQPConnectionError('CONN_CLOSE', 'socket closed unexpectedly by server');
                if (this._state.readyState === util_1.READY_STATE.OPEN)
                    this._state.onConnect = (0, util_1.createDeferred)(true);
                this._state.readyState = util_1.READY_STATE.CONNECTING;
                this._reset(connectionError);
                const retryCount = this._state.retryCount++;
                const delay = (0, util_1.expBackoff)(this._opt.retryLow, this._opt.retryHigh, retryCount);
                this._state.retryTimer = setTimeout(this._connect, delay);
                // emit & cede control to user only as final step
                // suppress spam during reconnect
                if (retryCount <= 1)
                    this.emit('error', connectionError);
            }
        });
        const ogwrite = socket.write;
        socket.write = (...args) => {
            this._state.hasWrite = true;
            return ogwrite.apply(socket, args);
        };
        const readerLoop = async () => {
            try {
                const read = (0, util_1.createAsyncReader)(socket);
                await this._negotiate(read);
                // consume AMQP DataFrames until the socket is closed
                while (true)
                    this._handleChunk(await (0, codec_1.decodeFrame)(read));
            }
            catch (err) {
                // TODO if err instanceof AMQPConnectionError then invoke connection.close + socket.end() + socket.resume()
                // all bets are off when we get a codec error; just kill the socket
                if (err.code !== 'READ_END')
                    socket.destroy(err);
            }
        };
        socket.write(codec_1.PROTOCOL_HEADER);
        readerLoop();
        return socket;
    }
    /** @internal Establish connection parameters with the server. */
    async _negotiate(read) {
        const readFrame = async (methodId) => {
            const frame = await (0, codec_1.decodeFrame)(read);
            if (frame.channelId === 0 && frame.type === codec_1.FrameType.METHOD && frame.methodId === methodId)
                return frame.params;
            if (frame.type === codec_1.FrameType.METHOD && frame.methodId === codec_1.Cmd.ConnectionClose) {
                const strcode = codec_1.ReplyCode[frame.params.replyCode] || String(frame.params.replyCode);
                const msg = codec_1.Cmd[frame.params.methodId] + ': ' + frame.params.replyText;
                throw new exception_1.AMQPConnectionError(strcode, msg);
            }
            throw new exception_1.AMQPConnectionError('COMMAND_INVALID', 'received unexpected frame during negotiation: ' + JSON.stringify(frame));
        };
        // check for version mismatch (only on first chunk)
        const chunk = await read(8);
        if (chunk.toString('utf-8', 0, 4) === 'AMQP') {
            const version = chunk.slice(4).join('-');
            const message = `this version of AMQP is not supported; the server suggests ${version}`;
            throw new exception_1.AMQPConnectionError('VERSION_MISMATCH', message);
        }
        this._socket.unshift(chunk);
        /*const serverParams = */ await readFrame(codec_1.Cmd.ConnectionStart);
        // TODO support EXTERNAL mechanism, i.e. x509 peer verification
        // https://github.com/rabbitmq/rabbitmq-auth-mechanism-ssl
        // serverParams.mechanisms === 'EXTERNAL PLAIN AMQPLAIN'
        this._writeMethod({
            type: codec_1.FrameType.METHOD,
            channelId: 0,
            methodId: codec_1.Cmd.ConnectionStartOK,
            params: {
                locale: 'en_US',
                mechanism: 'PLAIN',
                response: [null, this._opt.username, this._opt.password].join(String.fromCharCode(0)),
                clientProperties: this._opt.connectionName
                    ? { ...CLIENT_PROPERTIES, connection_name: this._opt.connectionName }
                    : CLIENT_PROPERTIES
            }
        });
        const params = await readFrame(codec_1.Cmd.ConnectionTune);
        const channelMax = params.channelMax > 0
            ? Math.min(this._opt.maxChannels, params.channelMax)
            : this._opt.maxChannels;
        this._state.channelMax = channelMax;
        this._socket.setMaxListeners(channelMax); // prevent MaxListenersExceededWarning with >10 channels
        const frameMax = params.frameMax > 0
            ? Math.min(this._opt.frameMax, params.frameMax)
            : this._opt.frameMax;
        this._state.frameMax = frameMax;
        const heartbeat = determineHeartbeat(params.heartbeat, this._opt.heartbeat);
        this._writeMethod({
            type: codec_1.FrameType.METHOD,
            channelId: 0,
            methodId: codec_1.Cmd.ConnectionTuneOK,
            params: { channelMax, frameMax, heartbeat }
        });
        this._writeMethod({
            type: codec_1.FrameType.METHOD,
            channelId: 0,
            methodId: codec_1.Cmd.ConnectionOpen,
            params: { virtualHost: this._opt.vhost || '/', rsvp1: '' }
        });
        await readFrame(codec_1.Cmd.ConnectionOpenOK);
        // create heartbeat timeout, or disable when 0
        if (heartbeat > 0) {
            let miss = 0;
            this._state.hasWrite = this._state.hasRead = false;
            this._state.heartbeatTimer = setInterval(() => {
                if (!this._state.hasRead) {
                    if (++miss >= 4)
                        this._socket.destroy(new exception_1.AMQPConnectionError('SOCKET_TIMEOUT', 'socket timed out (no heartbeat)'));
                }
                else {
                    this._state.hasRead = false;
                    miss = 0;
                }
                if (!this._state.hasWrite) {
                    // if connection.blocked then heartbeat monitoring is disabled
                    if (this._socket.writable && !this._socket.writableCorked)
                        this._socket.write(codec_1.HEARTBEAT_FRAME);
                }
                this._state.hasWrite = false;
            }, Math.ceil(heartbeat * 1000 / 2));
        }
        this._state.readyState = util_1.READY_STATE.OPEN;
        this._state.retryCount = 1;
        this._state.onConnect.resolve();
        if (this._state.connectionTimer)
            clearTimeout(this._state.connectionTimer);
        this._state.connectionTimer = undefined;
        this.emit('connection');
    }
    /** @internal */
    _writeMethod(params) {
        const frame = (0, codec_1.encodeFrame)(params, this._state.frameMax);
        this._socket.write(frame);
    }
    /** @internal */
    _handleChunk(frame) {
        this._state.hasRead = true;
        let ch;
        if (frame) {
            if (frame.type === codec_1.FrameType.HEARTBEAT) ;
            else if (frame.type === codec_1.FrameType.METHOD) {
                switch (frame.methodId) {
                    case codec_1.Cmd.ConnectionClose:
                        if (this._socket.writable) {
                            this._writeMethod({
                                type: codec_1.FrameType.METHOD,
                                channelId: 0,
                                methodId: codec_1.Cmd.ConnectionCloseOK,
                                params: undefined
                            });
                            this._socket.end();
                            this._socket.uncork();
                        }
                        const strcode = codec_1.ReplyCode[frame.params.replyCode] || String(frame.params.replyCode);
                        const souceMethod = frame.params.methodId ? codec_1.Cmd[frame.params.methodId] + ': ' : '';
                        const msg = souceMethod + frame.params.replyText;
                        this._socket.emit('error', new exception_1.AMQPConnectionError(strcode, msg));
                        break;
                    case codec_1.Cmd.ConnectionCloseOK:
                        // just wait for the socket to fully close
                        break;
                    case codec_1.Cmd.ConnectionBlocked:
                        this._socket.cork();
                        this.emit('connection.blocked', frame.params.reason);
                        break;
                    case codec_1.Cmd.ConnectionUnblocked:
                        this._socket.uncork();
                        this.emit('connection.unblocked');
                        break;
                    default:
                        ch = this._state.leased.get(frame.channelId);
                        if (ch == null) {
                            throw new exception_1.AMQPConnectionError('UNEXPECTED_FRAME', 'client received a method frame for an unexpected channel');
                        }
                        ch._onMethod(frame);
                }
            }
            else if (frame.type === codec_1.FrameType.HEADER) {
                const ch = this._state.leased.get(frame.channelId);
                if (ch == null) {
                    // TODO test me
                    throw new exception_1.AMQPConnectionError('UNEXPECTED_FRAME', 'client received a header frame for an unexpected channel');
                }
                ch._onHeader(frame);
            }
            else if (frame.type === codec_1.FrameType.BODY) {
                const ch = this._state.leased.get(frame.channelId);
                if (ch == null) {
                    // TODO test me
                    throw new exception_1.AMQPConnectionError('UNEXPECTED_FRAME', 'client received a body frame for an unexpected channel');
                }
                ch._onBody(frame);
            }
        }
    }
    /** @internal */
    _reset(err) {
        for (let ch of this._state.leased.values())
            ch._clear(err);
        this._state.leased.clear();
        this._checkEmpty();
        if (this._state.connectionTimer)
            clearTimeout(this._state.connectionTimer);
        this._state.connectionTimer = undefined;
        clearInterval(this._state.heartbeatTimer);
        this._state.heartbeatTimer = undefined;
    }
    /** @internal */
    _checkEmpty() {
        if (!this._state.leased.size && this._state.readyState === util_1.READY_STATE.CLOSING)
            this._state.onEmpty.resolve();
    }
    /** @internal */
    async _lazy() {
        let ch = this._state.lazyChannel;
        if (ch instanceof Promise) {
            return ch;
        }
        if (ch == null || !ch.active) {
            return this._state.lazyChannel = await (this._state.lazyChannel = this.acquire());
        }
        return ch;
    }
    basicGet(params) {
        return this._lazy().then(ch => ch.basicGet(params));
    }
    queueDeclare(params) {
        return this._lazy().then(ch => ch.queueDeclare(params));
    }
    /** {@inheritDoc Channel#exchangeBind} */
    exchangeBind(params) {
        return this._lazy().then(ch => ch.exchangeBind(params));
    }
    /** {@inheritDoc Channel#exchangeDeclare} */
    exchangeDeclare(params) {
        return this._lazy().then(ch => ch.exchangeDeclare(params));
    }
    /** {@inheritDoc Channel#exchangeDelete} */
    exchangeDelete(params) {
        return this._lazy().then(ch => ch.exchangeDelete(params));
    }
    /** {@inheritDoc Channel#exchangeUnbind} */
    exchangeUnbind(params) {
        return this._lazy().then(ch => ch.exchangeUnbind(params));
    }
    /** {@inheritDoc Channel#queueBind} */
    queueBind(params) {
        return this._lazy().then(ch => ch.queueBind(params));
    }
    queueDelete(params) {
        return this._lazy().then(ch => ch.queueDelete(params));
    }
    queuePurge(params) {
        return this._lazy().then(ch => ch.queuePurge(params));
    }
    /** {@inheritDoc Channel#queueUnbind} */
    queueUnbind(params) {
        return this._lazy().then(ch => ch.queueUnbind(params));
    }
    /** True if the connection is established and unblocked. See also {@link Connection#on:BLOCKED | Connection#on('connection.blocked')}) */
    get ready() {
        return this._state.readyState === util_1.READY_STATE.OPEN && !this._socket.writableCorked;
    }
};
Connection$2.Connection = Connection$1;
function determineHeartbeat(x, y) {
    if (x && y)
        return Math.min(x, y);
    // according to the AMQP spec, BOTH the client and server must set heartbeat to 0
    if (!x && !y)
        return 0;
    // otherwise the higher number is used
    return Math.max(x, y);
}

(function (exports) {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.ConsumerStatus = exports.AMQPError = exports.AMQPChannelError = exports.AMQPConnectionError = exports.Connection = void 0;
	const Connection_1 = Connection$2;
	Object.defineProperty(exports, "Connection", { enumerable: true, get: function () { return Connection_1.Connection; } });
	exports.default = Connection_1.Connection;
	var exception_1 = exception;
	Object.defineProperty(exports, "AMQPConnectionError", { enumerable: true, get: function () { return exception_1.AMQPConnectionError; } });
	Object.defineProperty(exports, "AMQPChannelError", { enumerable: true, get: function () { return exception_1.AMQPChannelError; } });
	Object.defineProperty(exports, "AMQPError", { enumerable: true, get: function () { return exception_1.AMQPError; } });
	var Consumer_1 = Consumer;
	Object.defineProperty(exports, "ConsumerStatus", { enumerable: true, get: function () { return Consumer_1.ConsumerStatus; } }); 
} (lib));

const originCache = new Map()
    , originStackCache = new Map()
    , originError = Symbol('OriginError');

const CLOSE = {};
class Query extends Promise {
  constructor(strings, args, handler, canceller, options = {}) {
    let resolve
      , reject;

    super((a, b) => {
      resolve = a;
      reject = b;
    });

    this.tagged = Array.isArray(strings.raw);
    this.strings = strings;
    this.args = args;
    this.handler = handler;
    this.canceller = canceller;
    this.options = options;

    this.state = null;
    this.statement = null;

    this.resolve = x => (this.active = false, resolve(x));
    this.reject = x => (this.active = false, reject(x));

    this.active = false;
    this.cancelled = null;
    this.executed = false;
    this.signature = '';

    this[originError] = this.handler.debug
      ? new Error()
      : this.tagged && cachedError(this.strings);
  }

  get origin() {
    return (this.handler.debug
      ? this[originError].stack
      : this.tagged && originStackCache.has(this.strings)
        ? originStackCache.get(this.strings)
        : originStackCache.set(this.strings, this[originError].stack).get(this.strings)
    ) || ''
  }

  static get [Symbol.species]() {
    return Promise
  }

  cancel() {
    return this.canceller && (this.canceller(this), this.canceller = null)
  }

  simple() {
    this.options.simple = true;
    this.options.prepare = false;
    return this
  }

  async readable() {
    this.simple();
    this.streaming = true;
    return this
  }

  async writable() {
    this.simple();
    this.streaming = true;
    return this
  }

  cursor(rows = 1, fn) {
    this.options.simple = false;
    if (typeof rows === 'function') {
      fn = rows;
      rows = 1;
    }

    this.cursorRows = rows;

    if (typeof fn === 'function')
      return (this.cursorFn = fn, this)

    let prev;
    return {
      [Symbol.asyncIterator]: () => ({
        next: () => {
          if (this.executed && !this.active)
            return { done: true }

          prev && prev();
          const promise = new Promise((resolve, reject) => {
            this.cursorFn = value => {
              resolve({ value, done: false });
              return new Promise(r => prev = r)
            };
            this.resolve = () => (this.active = false, resolve({ done: true }));
            this.reject = x => (this.active = false, reject(x));
          });
          this.execute();
          return promise
        },
        return() {
          prev && prev(CLOSE);
          return { done: true }
        }
      })
    }
  }

  describe() {
    this.options.simple = false;
    this.onlyDescribe = this.options.prepare = true;
    return this
  }

  stream() {
    throw new Error('.stream has been renamed to .forEach')
  }

  forEach(fn) {
    this.forEachFn = fn;
    this.handle();
    return this
  }

  raw() {
    this.isRaw = true;
    return this
  }

  values() {
    this.isRaw = 'values';
    return this
  }

  async handle() {
    !this.executed && (this.executed = true) && await 1 && this.handler(this);
  }

  execute() {
    this.handle();
    return this
  }

  then() {
    this.handle();
    return super.then.apply(this, arguments)
  }

  catch() {
    this.handle();
    return super.catch.apply(this, arguments)
  }

  finally() {
    this.handle();
    return super.finally.apply(this, arguments)
  }
}

function cachedError(xs) {
  if (originCache.has(xs))
    return originCache.get(xs)

  const x = Error.stackTraceLimit;
  Error.stackTraceLimit = 4;
  originCache.set(xs, new Error());
  Error.stackTraceLimit = x;
  return originCache.get(xs)
}

class PostgresError extends Error {
  constructor(x) {
    super(x.message);
    this.name = this.constructor.name;
    Object.assign(this, x);
  }
}

const Errors = {
  connection,
  postgres,
  generic,
  notSupported
};

function connection(x, options, socket) {
  const { host, port } = socket || options;
  const error = Object.assign(
    new Error(('write ' + x + ' ' + (options.path || (host + ':' + port)))),
    {
      code: x,
      errno: x,
      address: options.path || host
    }, options.path ? {} : { port: port }
  );
  Error.captureStackTrace(error, connection);
  return error
}

function postgres(x) {
  const error = new PostgresError(x);
  Error.captureStackTrace(error, postgres);
  return error
}

function generic(code, message) {
  const error = Object.assign(new Error(code + ': ' + message), { code });
  Error.captureStackTrace(error, generic);
  return error
}

/* c8 ignore next 10 */
function notSupported(x) {
  const error = Object.assign(
    new Error(x + ' (B) is not supported'),
    {
      code: 'MESSAGE_NOT_SUPPORTED',
      name: x
    }
  );
  Error.captureStackTrace(error, notSupported);
  return error
}

const types = {
  string: {
    to: 25,
    from: null,             // defaults to string
    serialize: x => '' + x
  },
  number: {
    to: 0,
    from: [21, 23, 26, 700, 701],
    serialize: x => '' + x,
    parse: x => +x
  },
  json: {
    to: 114,
    from: [114, 3802],
    serialize: x => JSON.stringify(x),
    parse: x => JSON.parse(x)
  },
  boolean: {
    to: 16,
    from: 16,
    serialize: x => x === true ? 't' : 'f',
    parse: x => x === 't'
  },
  date: {
    to: 1184,
    from: [1082, 1114, 1184],
    serialize: x => (x instanceof Date ? x : new Date(x)).toISOString(),
    parse: x => new Date(x)
  },
  bytea: {
    to: 17,
    from: 17,
    serialize: x => '\\x' + Buffer.from(x).toString('hex'),
    parse: x => Buffer.from(x.slice(2), 'hex')
  }
};

class NotTagged { then() { notTagged(); } catch() { notTagged(); } finally() { notTagged(); }}

class Identifier extends NotTagged {
  constructor(value) {
    super();
    this.value = escapeIdentifier(value);
  }
}

class Parameter extends NotTagged {
  constructor(value, type, array) {
    super();
    this.value = value;
    this.type = type;
    this.array = array;
  }
}

class Builder extends NotTagged {
  constructor(first, rest) {
    super();
    this.first = first;
    this.rest = rest;
  }

  build(before, parameters, types, options) {
    const keyword = builders.map(([x, fn]) => ({ fn, i: before.search(x) })).sort((a, b) => a.i - b.i).pop();
    return keyword.i === -1
      ? escapeIdentifiers(this.first, options)
      : keyword.fn(this.first, this.rest, parameters, types, options)
  }
}

function handleValue(x, parameters, types, options) {
  let value = x instanceof Parameter ? x.value : x;
  if (value === undefined) {
    x instanceof Parameter
      ? x.value = options.transform.undefined
      : value = x = options.transform.undefined;

    if (value === undefined)
      throw Errors.generic('UNDEFINED_VALUE', 'Undefined values are not allowed')
  }

  return '$' + (types.push(
    x instanceof Parameter
      ? (parameters.push(x.value), x.array
        ? x.array[x.type || inferType(x.value)] || x.type || firstIsString(x.value)
        : x.type
      )
      : (parameters.push(x), inferType(x))
  ))
}

const defaultHandlers = typeHandlers(types);

function stringify(q, string, value, parameters, types, options) { // eslint-disable-line
  for (let i = 1; i < q.strings.length; i++) {
    string += (stringifyValue(string, value, parameters, types, options)) + q.strings[i];
    value = q.args[i];
  }

  return string
}

function stringifyValue(string, value, parameters, types, o) {
  return (
    value instanceof Builder ? value.build(string, parameters, types, o) :
    value instanceof Query ? fragment(value, parameters, types, o) :
    value instanceof Identifier ? value.value :
    value && value[0] instanceof Query ? value.reduce((acc, x) => acc + ' ' + fragment(x, parameters, types, o), '') :
    handleValue(value, parameters, types, o)
  )
}

function fragment(q, parameters, types, options) {
  q.fragment = true;
  return stringify(q, q.strings[0], q.args[0], parameters, types, options)
}

function valuesBuilder(first, parameters, types, columns, options) {
  return first.map(row =>
    '(' + columns.map(column =>
      stringifyValue('values', row[column], parameters, types, options)
    ).join(',') + ')'
  ).join(',')
}

function values(first, rest, parameters, types, options) {
  const multi = Array.isArray(first[0]);
  const columns = rest.length ? rest.flat() : Object.keys(multi ? first[0] : first);
  return valuesBuilder(multi ? first : [first], parameters, types, columns, options)
}

function select(first, rest, parameters, types, options) {
  typeof first === 'string' && (first = [first].concat(rest));
  if (Array.isArray(first))
    return escapeIdentifiers(first, options)

  let value;
  const columns = rest.length ? rest.flat() : Object.keys(first);
  return columns.map(x => {
    value = first[x];
    return (
      value instanceof Query ? fragment(value, parameters, types, options) :
      value instanceof Identifier ? value.value :
      handleValue(value, parameters, types, options)
    ) + ' as ' + escapeIdentifier(options.transform.column.to ? options.transform.column.to(x) : x)
  }).join(',')
}

const builders = Object.entries({
  values,
  in: (...xs) => {
    const x = values(...xs);
    return x === '()' ? '(null)' : x
  },
  select,
  as: select,
  returning: select,
  '\\(': select,

  update(first, rest, parameters, types, options) {
    return (rest.length ? rest.flat() : Object.keys(first)).map(x =>
      escapeIdentifier(options.transform.column.to ? options.transform.column.to(x) : x) +
      '=' + stringifyValue('values', first[x], parameters, types, options)
    )
  },

  insert(first, rest, parameters, types, options) {
    const columns = rest.length ? rest.flat() : Object.keys(Array.isArray(first) ? first[0] : first);
    return '(' + escapeIdentifiers(columns, options) + ')values' +
    valuesBuilder(Array.isArray(first) ? first : [first], parameters, types, columns, options)
  }
}).map(([x, fn]) => ([new RegExp('((?:^|[\\s(])' + x + '(?:$|[\\s(]))(?![\\s\\S]*\\1)', 'i'), fn]));

function notTagged() {
  throw Errors.generic('NOT_TAGGED_CALL', 'Query not called as a tagged template literal')
}

const serializers = defaultHandlers.serializers;
const parsers = defaultHandlers.parsers;

function firstIsString(x) {
  if (Array.isArray(x))
    return firstIsString(x[0])
  return typeof x === 'string' ? 1009 : 0
}

const mergeUserTypes = function(types) {
  const user = typeHandlers(types || {});
  return {
    serializers: Object.assign({}, serializers, user.serializers),
    parsers: Object.assign({}, parsers, user.parsers)
  }
};

function typeHandlers(types) {
  return Object.keys(types).reduce((acc, k) => {
    types[k].from && [].concat(types[k].from).forEach(x => acc.parsers[x] = types[k].parse);
    if (types[k].serialize) {
      acc.serializers[types[k].to] = types[k].serialize;
      types[k].from && [].concat(types[k].from).forEach(x => acc.serializers[x] = types[k].serialize);
    }
    return acc
  }, { parsers: {}, serializers: {} })
}

function escapeIdentifiers(xs, { transform: { column } }) {
  return xs.map(x => escapeIdentifier(column.to ? column.to(x) : x)).join(',')
}

const escapeIdentifier = function escape(str) {
  return '"' + str.replace(/"/g, '""').replace(/\./g, '"."') + '"'
};

const inferType = function inferType(x) {
  return (
    x instanceof Parameter ? x.type :
    x instanceof Date ? 1184 :
    x instanceof Uint8Array ? 17 :
    (x === true || x === false) ? 16 :
    typeof x === 'bigint' ? 20 :
    Array.isArray(x) ? inferType(x[0]) :
    0
  )
};

const escapeBackslash = /\\/g;
const escapeQuote = /"/g;

function arrayEscape(x) {
  return x
    .replace(escapeBackslash, '\\\\')
    .replace(escapeQuote, '\\"')
}

const arraySerializer = function arraySerializer(xs, serializer, options, typarray) {
  if (Array.isArray(xs) === false)
    return xs

  if (!xs.length)
    return '{}'

  const first = xs[0];
  // Only _box (1020) has the ';' delimiter for arrays, all other types use the ',' delimiter
  const delimiter = typarray === 1020 ? ';' : ',';

  if (Array.isArray(first) && !first.type)
    return '{' + xs.map(x => arraySerializer(x, serializer, options, typarray)).join(delimiter) + '}'

  return '{' + xs.map(x => {
    if (x === undefined) {
      x = options.transform.undefined;
      if (x === undefined)
        throw Errors.generic('UNDEFINED_VALUE', 'Undefined values are not allowed')
    }

    return x === null
      ? 'null'
      : '"' + arrayEscape(serializer ? serializer(x.type ? x.value : x) : '' + x) + '"'
  }).join(delimiter) + '}'
};

const arrayParserState = {
  i: 0,
  char: null,
  str: '',
  quoted: false,
  last: 0
};

const arrayParser = function arrayParser(x, parser, typarray) {
  arrayParserState.i = arrayParserState.last = 0;
  return arrayParserLoop(arrayParserState, x, parser, typarray)
};

function arrayParserLoop(s, x, parser, typarray) {
  const xs = [];
  // Only _box (1020) has the ';' delimiter for arrays, all other types use the ',' delimiter
  const delimiter = typarray === 1020 ? ';' : ',';
  for (; s.i < x.length; s.i++) {
    s.char = x[s.i];
    if (s.quoted) {
      if (s.char === '\\') {
        s.str += x[++s.i];
      } else if (s.char === '"') {
        xs.push(parser ? parser(s.str) : s.str);
        s.str = '';
        s.quoted = x[s.i + 1] === '"';
        s.last = s.i + 2;
      } else {
        s.str += s.char;
      }
    } else if (s.char === '"') {
      s.quoted = true;
    } else if (s.char === '{') {
      s.last = ++s.i;
      xs.push(arrayParserLoop(s, x, parser, typarray));
    } else if (s.char === '}') {
      s.quoted = false;
      s.last < s.i && xs.push(parser ? parser(x.slice(s.last, s.i)) : x.slice(s.last, s.i));
      s.last = s.i + 1;
      break
    } else if (s.char === delimiter && s.p !== '}' && s.p !== '"') {
      xs.push(parser ? parser(x.slice(s.last, s.i)) : x.slice(s.last, s.i));
      s.last = s.i + 1;
    }
    s.p = s.char;
  }
  s.last < s.i && xs.push(parser ? parser(x.slice(s.last, s.i + 1)) : x.slice(s.last, s.i + 1));
  return xs
}

const toCamel = x => {
  let str = x[0];
  for (let i = 1; i < x.length; i++)
    str += x[i] === '_' ? x[++i].toUpperCase() : x[i];
  return str
};

const toPascal = x => {
  let str = x[0].toUpperCase();
  for (let i = 1; i < x.length; i++)
    str += x[i] === '_' ? x[++i].toUpperCase() : x[i];
  return str
};

const toKebab = x => x.replace(/_/g, '-');

const fromCamel = x => x.replace(/([A-Z])/g, '_$1').toLowerCase();
const fromPascal = x => (x.slice(0, 1) + x.slice(1).replace(/([A-Z])/g, '_$1')).toLowerCase();
const fromKebab = x => x.replace(/-/g, '_');

function createJsonTransform(fn) {
  return function jsonTransform(x, column) {
    return typeof x === 'object' && x !== null && (column.type === 114 || column.type === 3802)
      ? Array.isArray(x)
        ? x.map(x => jsonTransform(x, column))
        : Object.entries(x).reduce((acc, [k, v]) => Object.assign(acc, { [fn(k)]: jsonTransform(v, column) }), {})
      : x
  }
}

toCamel.column = { from: toCamel };
toCamel.value = { from: createJsonTransform(toCamel) };
fromCamel.column = { to: fromCamel };

const camel = { ...toCamel };
camel.column.to = fromCamel;

toPascal.column = { from: toPascal };
toPascal.value = { from: createJsonTransform(toPascal) };
fromPascal.column = { to: fromPascal };

const pascal = { ...toPascal };
pascal.column.to = fromPascal;

toKebab.column = { from: toKebab };
toKebab.value = { from: createJsonTransform(toKebab) };
fromKebab.column = { to: fromKebab };

const kebab = { ...toKebab };
kebab.column.to = fromKebab;

class Result extends Array {
  constructor() {
    super();
    Object.defineProperties(this, {
      count: { value: null, writable: true },
      state: { value: null, writable: true },
      command: { value: null, writable: true },
      columns: { value: null, writable: true },
      statement: { value: null, writable: true }
    });
  }

  static get [Symbol.species]() {
    return Array
  }
}

function Queue(initial = []) {
  let xs = initial.slice();
  let index = 0;

  return {
    get length() {
      return xs.length - index
    },
    remove: (x) => {
      const index = xs.indexOf(x);
      return index === -1
        ? null
        : (xs.splice(index, 1), x)
    },
    push: (x) => (xs.push(x), x),
    shift: () => {
      const out = xs[index++];

      if (index === xs.length) {
        index = 0;
        xs = [];
      } else {
        xs[index - 1] = undefined;
      }

      return out
    }
  }
}

const size = 256;
let buffer = Buffer.allocUnsafe(size);

const messages = 'BCcDdEFfHPpQSX'.split('').reduce((acc, x) => {
  const v = x.charCodeAt(0);
  acc[x] = () => {
    buffer[0] = v;
    b.i = 5;
    return b
  };
  return acc
}, {});

const b = Object.assign(reset, messages, {
  N: String.fromCharCode(0),
  i: 0,
  inc(x) {
    b.i += x;
    return b
  },
  str(x) {
    const length = Buffer.byteLength(x);
    fit(length);
    b.i += buffer.write(x, b.i, length, 'utf8');
    return b
  },
  i16(x) {
    fit(2);
    buffer.writeUInt16BE(x, b.i);
    b.i += 2;
    return b
  },
  i32(x, i) {
    if (i || i === 0) {
      buffer.writeUInt32BE(x, i);
      return b
    }
    fit(4);
    buffer.writeUInt32BE(x, b.i);
    b.i += 4;
    return b
  },
  z(x) {
    fit(x);
    buffer.fill(0, b.i, b.i + x);
    b.i += x;
    return b
  },
  raw(x) {
    buffer = Buffer.concat([buffer.subarray(0, b.i), x]);
    b.i = buffer.length;
    return b
  },
  end(at = 1) {
    buffer.writeUInt32BE(b.i - at, at);
    const out = buffer.subarray(0, b.i);
    b.i = 0;
    buffer = Buffer.allocUnsafe(size);
    return out
  }
});

function fit(x) {
  if (buffer.length - b.i < x) {
    const prev = buffer
        , length = prev.length;

    buffer = Buffer.allocUnsafe(length + (length >> 1) + x);
    prev.copy(buffer);
  }
}

function reset() {
  b.i = 0;
  return b
}

let uid = 1;

const Sync = b().S().end()
    , Flush = b().H().end()
    , SSLRequest = b().i32(8).i32(80877103).end(8)
    , ExecuteUnnamed = Buffer.concat([b().E().str(b.N).i32(0).end(), Sync])
    , DescribeUnnamed = b().D().str('S').str(b.N).end()
    , noop$1 = () => { /* noop */ };

const retryRoutines = new Set([
  'FetchPreparedStatement',
  'RevalidateCachedQuery',
  'transformAssignedExpr'
]);

const errorFields = {
  83  : 'severity_local',    // S
  86  : 'severity',          // V
  67  : 'code',              // C
  77  : 'message',           // M
  68  : 'detail',            // D
  72  : 'hint',              // H
  80  : 'position',          // P
  112 : 'internal_position', // p
  113 : 'internal_query',    // q
  87  : 'where',             // W
  115 : 'schema_name',       // s
  116 : 'table_name',        // t
  99  : 'column_name',       // c
  100 : 'data type_name',    // d
  110 : 'constraint_name',   // n
  70  : 'file',              // F
  76  : 'line',              // L
  82  : 'routine'            // R
};

function Connection(options, queues = {}, { onopen = noop$1, onend = noop$1, onclose = noop$1 } = {}) {
  const {
    ssl,
    max,
    user,
    host,
    port,
    database,
    parsers,
    transform,
    onnotice,
    onnotify,
    onparameter,
    max_pipeline,
    keep_alive,
    backoff,
    target_session_attrs
  } = options;

  const sent = Queue()
      , id = uid++
      , backend = { pid: null, secret: null }
      , idleTimer = timer(end, options.idle_timeout)
      , lifeTimer = timer(end, options.max_lifetime)
      , connectTimer = timer(connectTimedOut, options.connect_timeout);

  let socket = null
    , cancelMessage
    , result = new Result()
    , incoming = Buffer.alloc(0)
    , needsTypes = options.fetch_types
    , backendParameters = {}
    , statements = {}
    , statementId = Math.random().toString(36).slice(2)
    , statementCount = 1
    , closedDate = 0
    , remaining = 0
    , hostIndex = 0
    , retries = 0
    , length = 0
    , delay = 0
    , rows = 0
    , serverSignature = null
    , nextWriteTimer = null
    , terminated = false
    , incomings = null
    , results = null
    , initial = null
    , ending = null
    , stream = null
    , chunk = null
    , ended = null
    , nonce = null
    , query = null
    , final = null;

  const connection = {
    queue: queues.closed,
    idleTimer,
    connect(query) {
      initial = query || true;
      reconnect();
    },
    terminate,
    execute,
    cancel,
    end,
    count: 0,
    id
  };

  queues.closed && queues.closed.push(connection);

  return connection

  async function createSocket() {
    let x;
    try {
      x = options.socket
        ? (await Promise.resolve(options.socket(options)))
        : new net.Socket();
    } catch (e) {
      error(e);
      return
    }
    x.on('error', error);
    x.on('close', closed);
    x.on('drain', drain);
    return x
  }

  async function cancel({ pid, secret }, resolve, reject) {
    try {
      cancelMessage = b().i32(16).i32(80877102).i32(pid).i32(secret).end(16);
      await connect();
      socket.once('error', reject);
      socket.once('close', resolve);
    } catch (error) {
      reject(error);
    }
  }

  function execute(q) {
    if (terminated)
      return queryError(q, Errors.connection('CONNECTION_DESTROYED', options))

    if (q.cancelled)
      return

    try {
      q.state = backend;
      query
        ? sent.push(q)
        : (query = q, query.active = true);

      build(q);
      return write(toBuffer(q))
        && !q.describeFirst
        && !q.cursorFn
        && sent.length < max_pipeline
        && (!q.options.onexecute || q.options.onexecute(connection))
    } catch (error) {
      sent.length === 0 && write(Sync);
      errored(error);
      return true
    }
  }

  function toBuffer(q) {
    if (q.parameters.length >= 65534)
      throw Errors.generic('MAX_PARAMETERS_EXCEEDED', 'Max number of parameters (65534) exceeded')

    return q.options.simple
      ? b().Q().str(q.statement.string + b.N).end()
      : q.describeFirst
        ? Buffer.concat([describe(q), Flush])
        : q.prepare
          ? q.prepared
            ? prepared(q)
            : Buffer.concat([describe(q), prepared(q)])
          : unnamed(q)
  }

  function describe(q) {
    return Buffer.concat([
      Parse(q.statement.string, q.parameters, q.statement.types, q.statement.name),
      Describe('S', q.statement.name)
    ])
  }

  function prepared(q) {
    return Buffer.concat([
      Bind(q.parameters, q.statement.types, q.statement.name, q.cursorName),
      q.cursorFn
        ? Execute('', q.cursorRows)
        : ExecuteUnnamed
    ])
  }

  function unnamed(q) {
    return Buffer.concat([
      Parse(q.statement.string, q.parameters, q.statement.types),
      DescribeUnnamed,
      prepared(q)
    ])
  }

  function build(q) {
    const parameters = []
        , types = [];

    const string = stringify(q, q.strings[0], q.args[0], parameters, types, options);

    !q.tagged && q.args.forEach(x => handleValue(x, parameters, types, options));

    q.prepare = options.prepare && ('prepare' in q.options ? q.options.prepare : true);
    q.string = string;
    q.signature = q.prepare && types + string;
    q.onlyDescribe && (delete statements[q.signature]);
    q.parameters = q.parameters || parameters;
    q.prepared = q.prepare && q.signature in statements;
    q.describeFirst = q.onlyDescribe || (parameters.length && !q.prepared);
    q.statement = q.prepared
      ? statements[q.signature]
      : { string, types, name: q.prepare ? statementId + statementCount++ : '' };

    typeof options.debug === 'function' && options.debug(id, string, parameters, types);
  }

  function write(x, fn) {
    chunk = chunk ? Buffer.concat([chunk, x]) : Buffer.from(x);
    if (chunk.length >= 1024)
      return nextWrite(fn)
    nextWriteTimer === null && (nextWriteTimer = setImmediate(nextWrite));
    return true
  }

  function nextWrite(fn) {
    const x = socket.write(chunk, fn);
    nextWriteTimer !== null && clearImmediate(nextWriteTimer);
    chunk = nextWriteTimer = null;
    return x
  }

  function connectTimedOut() {
    errored(Errors.connection('CONNECT_TIMEOUT', options, socket));
    socket.destroy();
  }

  async function secure() {
    write(SSLRequest);
    const canSSL = await new Promise(r => socket.once('data', x => r(x[0] === 83))); // S

    if (!canSSL && ssl === 'prefer')
      return connected()

    socket.removeAllListeners();
    socket = tls.connect({
      socket,
      servername: net.isIP(socket.host) ? undefined : socket.host,
      ...(ssl === 'require' || ssl === 'allow' || ssl === 'prefer'
        ? { rejectUnauthorized: false }
        : ssl === 'verify-full'
          ? {}
          : typeof ssl === 'object'
            ? ssl
            : {}
      )
    });
    socket.on('secureConnect', connected);
    socket.on('error', error);
    socket.on('close', closed);
    socket.on('drain', drain);
  }

  /* c8 ignore next 3 */
  function drain() {
    !query && onopen(connection);
  }

  function data(x) {
    if (incomings) {
      incomings.push(x);
      remaining -= x.length;
      if (remaining >= 0)
        return
    }

    incoming = incomings
      ? Buffer.concat(incomings, length - remaining)
      : incoming.length === 0
        ? x
        : Buffer.concat([incoming, x], incoming.length + x.length);

    while (incoming.length > 4) {
      length = incoming.readUInt32BE(1);
      if (length >= incoming.length) {
        remaining = length - incoming.length;
        incomings = [incoming];
        break
      }

      try {
        handle(incoming.subarray(0, length + 1));
      } catch (e) {
        query && (query.cursorFn || query.describeFirst) && write(Sync);
        errored(e);
      }
      incoming = incoming.subarray(length + 1);
      remaining = 0;
      incomings = null;
    }
  }

  async function connect() {
    terminated = false;
    backendParameters = {};
    socket || (socket = await createSocket());

    if (!socket)
      return

    connectTimer.start();

    if (options.socket)
      return ssl ? secure() : connected()

    socket.on('connect', ssl ? secure : connected);

    if (options.path)
      return socket.connect(options.path)

    socket.ssl = ssl;
    socket.connect(port[hostIndex], host[hostIndex]);
    socket.host = host[hostIndex];
    socket.port = port[hostIndex];

    hostIndex = (hostIndex + 1) % port.length;
  }

  function reconnect() {
    setTimeout(connect, closedDate ? closedDate + delay - performance$1.now() : 0);
  }

  function connected() {
    try {
      statements = {};
      needsTypes = options.fetch_types;
      statementId = Math.random().toString(36).slice(2);
      statementCount = 1;
      lifeTimer.start();
      socket.on('data', data);
      keep_alive && socket.setKeepAlive && socket.setKeepAlive(true, 1000 * keep_alive);
      const s = StartupMessage();
      write(s);
    } catch (err) {
      error(err);
    }
  }

  function error(err) {
    if (connection.queue === queues.connecting && options.host[retries + 1])
      return

    errored(err);
    while (sent.length)
      queryError(sent.shift(), err);
  }

  function errored(err) {
    stream && (stream.destroy(err), stream = null);
    query && queryError(query, err);
    initial && (queryError(initial, err), initial = null);
  }

  function queryError(query, err) {
    Object.defineProperties(err, {
      stack: { value: err.stack + query.origin.replace(/.*\n/, '\n'), enumerable: options.debug },
      query: { value: query.string, enumerable: options.debug },
      parameters: { value: query.parameters, enumerable: options.debug },
      args: { value: query.args, enumerable: options.debug },
      types: { value: query.statement && query.statement.types, enumerable: options.debug }
    });
    query.reject(err);
  }

  function end() {
    return ending || (
      !connection.reserved && onend(connection),
      !connection.reserved && !initial && !query && sent.length === 0
        ? (terminate(), new Promise(r => socket && socket.readyState !== 'closed' ? socket.once('close', r) : r()))
        : ending = new Promise(r => ended = r)
    )
  }

  function terminate() {
    terminated = true;
    if (stream || query || initial || sent.length)
      error(Errors.connection('CONNECTION_DESTROYED', options));

    clearImmediate(nextWriteTimer);
    if (socket) {
      socket.removeListener('data', data);
      socket.removeListener('connect', connected);
      socket.readyState === 'open' && socket.end(b().X().end());
    }
    ended && (ended(), ending = ended = null);
  }

  async function closed(hadError) {
    incoming = Buffer.alloc(0);
    remaining = 0;
    incomings = null;
    clearImmediate(nextWriteTimer);
    socket.removeListener('data', data);
    socket.removeListener('connect', connected);
    idleTimer.cancel();
    lifeTimer.cancel();
    connectTimer.cancel();

    socket.removeAllListeners();
    socket = null;

    if (initial)
      return reconnect()

    !hadError && (query || sent.length) && error(Errors.connection('CONNECTION_CLOSED', options, socket));
    closedDate = performance$1.now();
    hadError && options.shared.retries++;
    delay = (typeof backoff === 'function' ? backoff(options.shared.retries) : backoff) * 1000;
    onclose(connection, Errors.connection('CONNECTION_CLOSED', options, socket));
  }

  /* Handlers */
  function handle(xs, x = xs[0]) {
    (
      x === 68 ? DataRow :                   // D
      x === 100 ? CopyData :                 // d
      x === 65 ? NotificationResponse :      // A
      x === 83 ? ParameterStatus :           // S
      x === 90 ? ReadyForQuery :             // Z
      x === 67 ? CommandComplete :           // C
      x === 50 ? BindComplete :              // 2
      x === 49 ? ParseComplete :             // 1
      x === 116 ? ParameterDescription :     // t
      x === 84 ? RowDescription :            // T
      x === 82 ? Authentication :            // R
      x === 110 ? NoData :                   // n
      x === 75 ? BackendKeyData :            // K
      x === 69 ? ErrorResponse :             // E
      x === 115 ? PortalSuspended :          // s
      x === 51 ? CloseComplete :             // 3
      x === 71 ? CopyInResponse :            // G
      x === 78 ? NoticeResponse :            // N
      x === 72 ? CopyOutResponse :           // H
      x === 99 ? CopyDone :                  // c
      x === 73 ? EmptyQueryResponse :        // I
      x === 86 ? FunctionCallResponse :      // V
      x === 118 ? NegotiateProtocolVersion : // v
      x === 87 ? CopyBothResponse :          // W
      /* c8 ignore next */
      UnknownMessage
    )(xs);
  }

  function DataRow(x) {
    let index = 7;
    let length;
    let column;
    let value;

    const row = query.isRaw ? new Array(query.statement.columns.length) : {};
    for (let i = 0; i < query.statement.columns.length; i++) {
      column = query.statement.columns[i];
      length = x.readInt32BE(index);
      index += 4;

      value = length === -1
        ? null
        : query.isRaw === true
          ? x.subarray(index, index += length)
          : column.parser === undefined
            ? x.toString('utf8', index, index += length)
            : column.parser.array === true
              ? column.parser(x.toString('utf8', index + 1, index += length))
              : column.parser(x.toString('utf8', index, index += length));

      query.isRaw
        ? (row[i] = query.isRaw === true
          ? value
          : transform.value.from ? transform.value.from(value, column) : value)
        : (row[column.name] = transform.value.from ? transform.value.from(value, column) : value);
    }

    query.forEachFn
      ? query.forEachFn(transform.row.from ? transform.row.from(row) : row, result)
      : (result[rows++] = transform.row.from ? transform.row.from(row) : row);
  }

  function ParameterStatus(x) {
    const [k, v] = x.toString('utf8', 5, x.length - 1).split(b.N);
    backendParameters[k] = v;
    if (options.parameters[k] !== v) {
      options.parameters[k] = v;
      onparameter && onparameter(k, v);
    }
  }

  function ReadyForQuery(x) {
    query && query.options.simple && query.resolve(results || result);
    query = results = null;
    result = new Result();
    connectTimer.cancel();

    if (initial) {
      if (target_session_attrs) {
        if (!backendParameters.in_hot_standby || !backendParameters.default_transaction_read_only)
          return fetchState()
        else if (tryNext(target_session_attrs, backendParameters))
          return terminate()
      }

      if (needsTypes) {
        initial === true && (initial = null);
        return fetchArrayTypes()
      }

      initial !== true && execute(initial);
      options.shared.retries = retries = 0;
      initial = null;
      return
    }

    while (sent.length && (query = sent.shift()) && (query.active = true, query.cancelled))
      Connection(options).cancel(query.state, query.cancelled.resolve, query.cancelled.reject);

    if (query)
      return // Consider opening if able and sent.length < 50

    connection.reserved
      ? !connection.reserved.release && x[5] === 73 // I
        ? ending
          ? terminate()
          : (connection.reserved = null, onopen(connection))
        : connection.reserved()
      : ending
        ? terminate()
        : onopen(connection);
  }

  function CommandComplete(x) {
    rows = 0;

    for (let i = x.length - 1; i > 0; i--) {
      if (x[i] === 32 && x[i + 1] < 58 && result.count === null)
        result.count = +x.toString('utf8', i + 1, x.length - 1);
      if (x[i - 1] >= 65) {
        result.command = x.toString('utf8', 5, i);
        result.state = backend;
        break
      }
    }

    final && (final(), final = null);

    if (result.command === 'BEGIN' && max !== 1 && !connection.reserved)
      return errored(Errors.generic('UNSAFE_TRANSACTION', 'Only use sql.begin, sql.reserved or max: 1'))

    if (query.options.simple)
      return BindComplete()

    if (query.cursorFn) {
      result.count && query.cursorFn(result);
      write(Sync);
    }

    query.resolve(result);
  }

  function ParseComplete() {
    query.parsing = false;
  }

  function BindComplete() {
    !result.statement && (result.statement = query.statement);
    result.columns = query.statement.columns;
  }

  function ParameterDescription(x) {
    const length = x.readUInt16BE(5);

    for (let i = 0; i < length; ++i)
      !query.statement.types[i] && (query.statement.types[i] = x.readUInt32BE(7 + i * 4));

    query.prepare && (statements[query.signature] = query.statement);
    query.describeFirst && !query.onlyDescribe && (write(prepared(query)), query.describeFirst = false);
  }

  function RowDescription(x) {
    if (result.command) {
      results = results || [result];
      results.push(result = new Result());
      result.count = null;
      query.statement.columns = null;
    }

    const length = x.readUInt16BE(5);
    let index = 7;
    let start;

    query.statement.columns = Array(length);

    for (let i = 0; i < length; ++i) {
      start = index;
      while (x[index++] !== 0);
      const table = x.readUInt32BE(index);
      const number = x.readUInt16BE(index + 4);
      const type = x.readUInt32BE(index + 6);
      query.statement.columns[i] = {
        name: transform.column.from
          ? transform.column.from(x.toString('utf8', start, index - 1))
          : x.toString('utf8', start, index - 1),
        parser: parsers[type],
        table,
        number,
        type
      };
      index += 18;
    }

    result.statement = query.statement;
    if (query.onlyDescribe)
      return (query.resolve(query.statement), write(Sync))
  }

  async function Authentication(x, type = x.readUInt32BE(5)) {
    (
      type === 3 ? AuthenticationCleartextPassword :
      type === 5 ? AuthenticationMD5Password :
      type === 10 ? SASL :
      type === 11 ? SASLContinue :
      type === 12 ? SASLFinal :
      type !== 0 ? UnknownAuth :
      noop$1
    )(x, type);
  }

  /* c8 ignore next 5 */
  async function AuthenticationCleartextPassword() {
    const payload = await Pass();
    write(
      b().p().str(payload).z(1).end()
    );
  }

  async function AuthenticationMD5Password(x) {
    const payload = 'md5' + (
      await md5(
        Buffer.concat([
          Buffer.from(await md5((await Pass()) + user)),
          x.subarray(9)
        ])
      )
    );
    write(
      b().p().str(payload).z(1).end()
    );
  }

  async function SASL() {
    nonce = (await crypto.randomBytes(18)).toString('base64');
    b().p().str('SCRAM-SHA-256' + b.N);
    const i = b.i;
    write(b.inc(4).str('n,,n=*,r=' + nonce).i32(b.i - i - 4, i).end());
  }

  async function SASLContinue(x) {
    const res = x.toString('utf8', 9).split(',').reduce((acc, x) => (acc[x[0]] = x.slice(2), acc), {});

    const saltedPassword = await crypto.pbkdf2Sync(
      await Pass(),
      Buffer.from(res.s, 'base64'),
      parseInt(res.i), 32,
      'sha256'
    );

    const clientKey = await hmac(saltedPassword, 'Client Key');

    const auth = 'n=*,r=' + nonce + ','
               + 'r=' + res.r + ',s=' + res.s + ',i=' + res.i
               + ',c=biws,r=' + res.r;

    serverSignature = (await hmac(await hmac(saltedPassword, 'Server Key'), auth)).toString('base64');

    const payload = 'c=biws,r=' + res.r + ',p=' + xor(
      clientKey, Buffer.from(await hmac(await sha256(clientKey), auth))
    ).toString('base64');

    write(
      b().p().str(payload).end()
    );
  }

  function SASLFinal(x) {
    if (x.toString('utf8', 9).split(b.N, 1)[0].slice(2) === serverSignature)
      return
    /* c8 ignore next 5 */
    errored(Errors.generic('SASL_SIGNATURE_MISMATCH', 'The server did not return the correct signature'));
    socket.destroy();
  }

  function Pass() {
    return Promise.resolve(typeof options.pass === 'function'
      ? options.pass()
      : options.pass
    )
  }

  function NoData() {
    result.statement = query.statement;
    result.statement.columns = [];
    if (query.onlyDescribe)
      return (query.resolve(query.statement), write(Sync))
  }

  function BackendKeyData(x) {
    backend.pid = x.readUInt32BE(5);
    backend.secret = x.readUInt32BE(9);
  }

  async function fetchArrayTypes() {
    needsTypes = false;
    const types = await new Query([`
      select b.oid, b.typarray
      from pg_catalog.pg_type a
      left join pg_catalog.pg_type b on b.oid = a.typelem
      where a.typcategory = 'A'
      group by b.oid, b.typarray
      order by b.oid
    `], [], execute);
    types.forEach(({ oid, typarray }) => addArrayType(oid, typarray));
  }

  function addArrayType(oid, typarray) {
    if (!!options.parsers[typarray] && !!options.serializers[typarray]) return
    const parser = options.parsers[oid];
    options.shared.typeArrayMap[oid] = typarray;
    options.parsers[typarray] = (xs) => arrayParser(xs, parser, typarray);
    options.parsers[typarray].array = true;
    options.serializers[typarray] = (xs) => arraySerializer(xs, options.serializers[oid], options, typarray);
  }

  function tryNext(x, xs) {
    return (
      (x === 'read-write' && xs.default_transaction_read_only === 'on') ||
      (x === 'read-only' && xs.default_transaction_read_only === 'off') ||
      (x === 'primary' && xs.in_hot_standby === 'on') ||
      (x === 'standby' && xs.in_hot_standby === 'off') ||
      (x === 'prefer-standby' && xs.in_hot_standby === 'off' && options.host[retries])
    )
  }

  function fetchState() {
    const query = new Query([`
      show transaction_read_only;
      select pg_catalog.pg_is_in_recovery()
    `], [], execute, null, { simple: true });
    query.resolve = ([[a], [b]]) => {
      backendParameters.default_transaction_read_only = a.transaction_read_only;
      backendParameters.in_hot_standby = b.pg_is_in_recovery ? 'on' : 'off';
    };
    query.execute();
  }

  function ErrorResponse(x) {
    query && (query.cursorFn || query.describeFirst) && write(Sync);
    const error = Errors.postgres(parseError(x));
    query && query.retried
      ? errored(query.retried)
      : query && query.prepared && retryRoutines.has(error.routine)
        ? retry(query, error)
        : errored(error);
  }

  function retry(q, error) {
    delete statements[q.signature];
    q.retried = error;
    execute(q);
  }

  function NotificationResponse(x) {
    if (!onnotify)
      return

    let index = 9;
    while (x[index++] !== 0);
    onnotify(
      x.toString('utf8', 9, index - 1),
      x.toString('utf8', index, x.length - 1)
    );
  }

  async function PortalSuspended() {
    try {
      const x = await Promise.resolve(query.cursorFn(result));
      rows = 0;
      x === CLOSE
        ? write(Close(query.portal))
        : (result = new Result(), write(Execute('', query.cursorRows)));
    } catch (err) {
      write(Sync);
      query.reject(err);
    }
  }

  function CloseComplete() {
    result.count && query.cursorFn(result);
    query.resolve(result);
  }

  function CopyInResponse() {
    stream = new Stream.Writable({
      autoDestroy: true,
      write(chunk, encoding, callback) {
        socket.write(b().d().raw(chunk).end(), callback);
      },
      destroy(error, callback) {
        callback(error);
        socket.write(b().f().str(error + b.N).end());
        stream = null;
      },
      final(callback) {
        socket.write(b().c().end());
        final = callback;
      }
    });
    query.resolve(stream);
  }

  function CopyOutResponse() {
    stream = new Stream.Readable({
      read() { socket.resume(); }
    });
    query.resolve(stream);
  }

  /* c8 ignore next 3 */
  function CopyBothResponse() {
    stream = new Stream.Duplex({
      autoDestroy: true,
      read() { socket.resume(); },
      /* c8 ignore next 11 */
      write(chunk, encoding, callback) {
        socket.write(b().d().raw(chunk).end(), callback);
      },
      destroy(error, callback) {
        callback(error);
        socket.write(b().f().str(error + b.N).end());
        stream = null;
      },
      final(callback) {
        socket.write(b().c().end());
        final = callback;
      }
    });
    query.resolve(stream);
  }

  function CopyData(x) {
    stream && (stream.push(x.subarray(5)) || socket.pause());
  }

  function CopyDone() {
    stream && stream.push(null);
    stream = null;
  }

  function NoticeResponse(x) {
    onnotice
      ? onnotice(parseError(x))
      : console.log(parseError(x)); // eslint-disable-line

  }

  /* c8 ignore next 3 */
  function EmptyQueryResponse() {
    /* noop */
  }

  /* c8 ignore next 3 */
  function FunctionCallResponse() {
    errored(Errors.notSupported('FunctionCallResponse'));
  }

  /* c8 ignore next 3 */
  function NegotiateProtocolVersion() {
    errored(Errors.notSupported('NegotiateProtocolVersion'));
  }

  /* c8 ignore next 3 */
  function UnknownMessage(x) {
    console.error('Postgres.js : Unknown Message:', x[0]); // eslint-disable-line
  }

  /* c8 ignore next 3 */
  function UnknownAuth(x, type) {
    console.error('Postgres.js : Unknown Auth:', type); // eslint-disable-line
  }

  /* Messages */
  function Bind(parameters, types, statement = '', portal = '') {
    let prev
      , type;

    b().B().str(portal + b.N).str(statement + b.N).i16(0).i16(parameters.length);

    parameters.forEach((x, i) => {
      if (x === null)
        return b.i32(0xFFFFFFFF)

      type = types[i];
      parameters[i] = x = type in options.serializers
        ? options.serializers[type](x)
        : '' + x;

      prev = b.i;
      b.inc(4).str(x).i32(b.i - prev - 4, prev);
    });

    b.i16(0);

    return b.end()
  }

  function Parse(str, parameters, types, name = '') {
    b().P().str(name + b.N).str(str + b.N).i16(parameters.length);
    parameters.forEach((x, i) => b.i32(types[i] || 0));
    return b.end()
  }

  function Describe(x, name = '') {
    return b().D().str(x).str(name + b.N).end()
  }

  function Execute(portal = '', rows = 0) {
    return Buffer.concat([
      b().E().str(portal + b.N).i32(rows).end(),
      Flush
    ])
  }

  function Close(portal = '') {
    return Buffer.concat([
      b().C().str('P').str(portal + b.N).end(),
      b().S().end()
    ])
  }

  function StartupMessage() {
    return cancelMessage || b().inc(4).i16(3).z(2).str(
      Object.entries(Object.assign({
        user,
        database,
        client_encoding: 'UTF8'
      },
        options.connection
      )).filter(([, v]) => v).map(([k, v]) => k + b.N + v).join(b.N)
    ).z(2).end(0)
  }

}

function parseError(x) {
  const error = {};
  let start = 5;
  for (let i = 5; i < x.length - 1; i++) {
    if (x[i] === 0) {
      error[errorFields[x[start]]] = x.toString('utf8', start + 1, i);
      start = i + 1;
    }
  }
  return error
}

function md5(x) {
  return crypto.createHash('md5').update(x).digest('hex')
}

function hmac(key, x) {
  return crypto.createHmac('sha256', key).update(x).digest()
}

function sha256(x) {
  return crypto.createHash('sha256').update(x).digest()
}

function xor(a, b) {
  const length = Math.max(a.length, b.length);
  const buffer = Buffer.allocUnsafe(length);
  for (let i = 0; i < length; i++)
    buffer[i] = a[i] ^ b[i];
  return buffer
}

function timer(fn, seconds) {
  seconds = typeof seconds === 'function' ? seconds() : seconds;
  if (!seconds)
    return { cancel: noop$1, start: noop$1 }

  let timer;
  return {
    cancel() {
      timer && (clearTimeout(timer), timer = null);
    },
    start() {
      timer && clearTimeout(timer);
      timer = setTimeout(done, seconds * 1000, arguments);
    }
  }

  function done(args) {
    fn.apply(null, args);
    timer = null;
  }
}

const noop = () => { /* noop */ };

function Subscribe(postgres, options) {
  const subscribers = new Map()
      , slot = 'postgresjs_' + Math.random().toString(36).slice(2)
      , state = {};

  let connection
    , stream
    , ended = false;

  const sql = subscribe.sql = postgres({
    ...options,
    transform: { column: {}, value: {}, row: {} },
    max: 1,
    fetch_types: false,
    idle_timeout: null,
    max_lifetime: null,
    connection: {
      ...options.connection,
      replication: 'database'
    },
    onclose: async function() {
      if (ended)
        return
      stream = null;
      state.pid = state.secret = undefined;
      connected(await init(sql, slot, options.publications));
      subscribers.forEach(event => event.forEach(({ onsubscribe }) => onsubscribe()));
    },
    no_subscribe: true
  });

  const end = sql.end
      , close = sql.close;

  sql.end = async() => {
    ended = true;
    stream && (await new Promise(r => (stream.once('close', r), stream.end())));
    return end()
  };

  sql.close = async() => {
    stream && (await new Promise(r => (stream.once('close', r), stream.end())));
    return close()
  };

  return subscribe

  async function subscribe(event, fn, onsubscribe = noop, onerror = noop) {
    event = parseEvent(event);

    if (!connection)
      connection = init(sql, slot, options.publications);

    const subscriber = { fn, onsubscribe };
    const fns = subscribers.has(event)
      ? subscribers.get(event).add(subscriber)
      : subscribers.set(event, new Set([subscriber])).get(event);

    const unsubscribe = () => {
      fns.delete(subscriber);
      fns.size === 0 && subscribers.delete(event);
    };

    return connection.then(x => {
      connected(x);
      onsubscribe();
      stream && stream.on('error', onerror);
      return { unsubscribe, state, sql }
    })
  }

  function connected(x) {
    stream = x.stream;
    state.pid = x.state.pid;
    state.secret = x.state.secret;
  }

  async function init(sql, slot, publications) {
    if (!publications)
      throw new Error('Missing publication names')

    const xs = await sql.unsafe(
      `CREATE_REPLICATION_SLOT ${ slot } TEMPORARY LOGICAL pgoutput NOEXPORT_SNAPSHOT`
    );

    const [x] = xs;

    const stream = await sql.unsafe(
      `START_REPLICATION SLOT ${ slot } LOGICAL ${
        x.consistent_point
      } (proto_version '1', publication_names '${ publications }')`
    ).writable();

    const state = {
      lsn: Buffer.concat(x.consistent_point.split('/').map(x => Buffer.from(('00000000' + x).slice(-8), 'hex')))
    };

    stream.on('data', data);
    stream.on('error', error);
    stream.on('close', sql.close);

    return { stream, state: xs.state }

    function error(e) {
      console.error('Unexpected error during logical streaming - reconnecting', e); // eslint-disable-line
    }

    function data(x) {
      if (x[0] === 0x77) {
        parse(x.subarray(25), state, sql.options.parsers, handle, options.transform);
      } else if (x[0] === 0x6b && x[17]) {
        state.lsn = x.subarray(1, 9);
        pong();
      }
    }

    function handle(a, b) {
      const path = b.relation.schema + '.' + b.relation.table;
      call('*', a, b);
      call('*:' + path, a, b);
      b.relation.keys.length && call('*:' + path + '=' + b.relation.keys.map(x => a[x.name]), a, b);
      call(b.command, a, b);
      call(b.command + ':' + path, a, b);
      b.relation.keys.length && call(b.command + ':' + path + '=' + b.relation.keys.map(x => a[x.name]), a, b);
    }

    function pong() {
      const x = Buffer.alloc(34);
      x[0] = 'r'.charCodeAt(0);
      x.fill(state.lsn, 1);
      x.writeBigInt64BE(BigInt(Date.now() - Date.UTC(2000, 0, 1)) * BigInt(1000), 25);
      stream.write(x);
    }
  }

  function call(x, a, b) {
    subscribers.has(x) && subscribers.get(x).forEach(({ fn }) => fn(a, b, x));
  }
}

function Time(x) {
  return new Date(Date.UTC(2000, 0, 1) + Number(x / BigInt(1000)))
}

function parse(x, state, parsers, handle, transform) {
  const char = (acc, [k, v]) => (acc[k.charCodeAt(0)] = v, acc);

  Object.entries({
    R: x => {  // Relation
      let i = 1;
      const r = state[x.readUInt32BE(i)] = {
        schema: x.toString('utf8', i += 4, i = x.indexOf(0, i)) || 'pg_catalog',
        table: x.toString('utf8', i + 1, i = x.indexOf(0, i + 1)),
        columns: Array(x.readUInt16BE(i += 2)),
        keys: []
      };
      i += 2;

      let columnIndex = 0
        , column;

      while (i < x.length) {
        column = r.columns[columnIndex++] = {
          key: x[i++],
          name: transform.column.from
            ? transform.column.from(x.toString('utf8', i, i = x.indexOf(0, i)))
            : x.toString('utf8', i, i = x.indexOf(0, i)),
          type: x.readUInt32BE(i += 1),
          parser: parsers[x.readUInt32BE(i)],
          atttypmod: x.readUInt32BE(i += 4)
        };

        column.key && r.keys.push(column);
        i += 4;
      }
    },
    Y: () => { /* noop */ }, // Type
    O: () => { /* noop */ }, // Origin
    B: x => { // Begin
      state.date = Time(x.readBigInt64BE(9));
      state.lsn = x.subarray(1, 9);
    },
    I: x => { // Insert
      let i = 1;
      const relation = state[x.readUInt32BE(i)];
      const { row } = tuples(x, relation.columns, i += 7, transform);

      handle(row, {
        command: 'insert',
        relation
      });
    },
    D: x => { // Delete
      let i = 1;
      const relation = state[x.readUInt32BE(i)];
      i += 4;
      const key = x[i] === 75;
      handle(key || x[i] === 79
        ? tuples(x, relation.columns, i += 3, transform).row
        : null
      , {
        command: 'delete',
        relation,
        key
      });
    },
    U: x => { // Update
      let i = 1;
      const relation = state[x.readUInt32BE(i)];
      i += 4;
      const key = x[i] === 75;
      const xs = key || x[i] === 79
        ? tuples(x, relation.columns, i += 3, transform)
        : null;

      xs && (i = xs.i);

      const { row } = tuples(x, relation.columns, i + 3, transform);

      handle(row, {
        command: 'update',
        relation,
        key,
        old: xs && xs.row
      });
    },
    T: () => { /* noop */ }, // Truncate,
    C: () => { /* noop */ }  // Commit
  }).reduce(char, {})[x[0]](x);
}

function tuples(x, columns, xi, transform) {
  let type
    , column
    , value;

  const row = transform.raw ? new Array(columns.length) : {};
  for (let i = 0; i < columns.length; i++) {
    type = x[xi++];
    column = columns[i];
    value = type === 110 // n
      ? null
      : type === 117 // u
        ? undefined
        : column.parser === undefined
          ? x.toString('utf8', xi + 4, xi += 4 + x.readUInt32BE(xi))
          : column.parser.array === true
            ? column.parser(x.toString('utf8', xi + 5, xi += 4 + x.readUInt32BE(xi)))
            : column.parser(x.toString('utf8', xi + 4, xi += 4 + x.readUInt32BE(xi)));

    transform.raw
      ? (row[i] = transform.raw === true
        ? value
        : transform.value.from ? transform.value.from(value, column) : value)
      : (row[column.name] = transform.value.from
        ? transform.value.from(value, column)
        : value
      );
  }

  return { i: xi, row: transform.row.from ? transform.row.from(row) : row }
}

function parseEvent(x) {
  const xs = x.match(/^(\*|insert|update|delete)?:?([^.]+?\.?[^=]+)?=?(.+)?/i) || [];

  if (!xs)
    throw new Error('Malformed subscribe pattern: ' + x)

  const [, command, path, key] = xs;

  return (command || '*')
       + (path ? ':' + (path.indexOf('.') === -1 ? 'public.' + path : path) : '')
       + (key ? '=' + key : '')
}

function largeObject(sql, oid, mode = 0x00020000 | 0x00040000) {
  return new Promise(async(resolve, reject) => {
    await sql.begin(async sql => {
      let finish;
      !oid && ([{ oid }] = await sql`select lo_creat(-1) as oid`);
      const [{ fd }] = await sql`select lo_open(${ oid }, ${ mode }) as fd`;

      const lo = {
        writable,
        readable,
        close     : () => sql`select lo_close(${ fd })`.then(finish),
        tell      : () => sql`select lo_tell64(${ fd })`,
        read      : (x) => sql`select loread(${ fd }, ${ x }) as data`,
        write     : (x) => sql`select lowrite(${ fd }, ${ x })`,
        truncate  : (x) => sql`select lo_truncate64(${ fd }, ${ x })`,
        seek      : (x, whence = 0) => sql`select lo_lseek64(${ fd }, ${ x }, ${ whence })`,
        size      : () => sql`
          select
            lo_lseek64(${ fd }, location, 0) as position,
            seek.size
          from (
            select
              lo_lseek64($1, 0, 2) as size,
              tell.location
            from (select lo_tell64($1) as location) tell
          ) seek
        `
      };

      resolve(lo);

      return new Promise(async r => finish = r)

      async function readable({
        highWaterMark = 2048 * 8,
        start = 0,
        end = Infinity
      } = {}) {
        let max = end - start;
        start && await lo.seek(start);
        return new Stream.Readable({
          highWaterMark,
          async read(size) {
            const l = size > max ? size - max : size;
            max -= size;
            const [{ data }] = await lo.read(l);
            this.push(data);
            if (data.length < size)
              this.push(null);
          }
        })
      }

      async function writable({
        highWaterMark = 2048 * 8,
        start = 0
      } = {}) {
        start && await lo.seek(start);
        return new Stream.Writable({
          highWaterMark,
          write(chunk, encoding, callback) {
            lo.write(chunk).then(() => callback(), callback);
          }
        })
      }
    }).catch(reject);
  })
}

Object.assign(Postgres, {
  PostgresError,
  toPascal,
  pascal,
  toCamel,
  camel,
  toKebab,
  kebab,
  fromPascal,
  fromCamel,
  fromKebab,
  BigInt: {
    to: 20,
    from: [20],
    parse: x => BigInt(x), // eslint-disable-line
    serialize: x => x.toString()
  }
});

function Postgres(a, b) {
  const options = parseOptions(a, b)
      , subscribe = options.no_subscribe || Subscribe(Postgres, { ...options });

  let ending = false;

  const queries = Queue()
      , connecting = Queue()
      , reserved = Queue()
      , closed = Queue()
      , ended = Queue()
      , open = Queue()
      , busy = Queue()
      , full = Queue()
      , queues = { connecting, reserved, closed, ended, open, busy, full };

  const connections = [...Array(options.max)].map(() => Connection(options, queues, { onopen, onend, onclose }));

  const sql = Sql(handler);

  Object.assign(sql, {
    get parameters() { return options.parameters },
    largeObject: largeObject.bind(null, sql),
    subscribe,
    CLOSE,
    END: CLOSE,
    PostgresError,
    options,
    reserve,
    listen,
    begin,
    close,
    end
  });

  return sql

  function Sql(handler) {
    handler.debug = options.debug;

    Object.entries(options.types).reduce((acc, [name, type]) => {
      acc[name] = (x) => new Parameter(x, type.to);
      return acc
    }, typed);

    Object.assign(sql, {
      types: typed,
      typed,
      unsafe,
      notify,
      array,
      json,
      file
    });

    return sql

    function typed(value, type) {
      return new Parameter(value, type)
    }

    function sql(strings, ...args) {
      const query = strings && Array.isArray(strings.raw)
        ? new Query(strings, args, handler, cancel)
        : typeof strings === 'string' && !args.length
          ? new Identifier(options.transform.column.to ? options.transform.column.to(strings) : strings)
          : new Builder(strings, args);
      return query
    }

    function unsafe(string, args = [], options = {}) {
      arguments.length === 2 && !Array.isArray(args) && (options = args, args = []);
      const query = new Query([string], args, handler, cancel, {
        prepare: false,
        ...options,
        simple: 'simple' in options ? options.simple : args.length === 0
      });
      return query
    }

    function file(path, args = [], options = {}) {
      arguments.length === 2 && !Array.isArray(args) && (options = args, args = []);
      const query = new Query([], args, (query) => {
        fs.readFile(path, 'utf8', (err, string) => {
          if (err)
            return query.reject(err)

          query.strings = [string];
          handler(query);
        });
      }, cancel, {
        ...options,
        simple: 'simple' in options ? options.simple : args.length === 0
      });
      return query
    }
  }

  async function listen(name, fn, onlisten) {
    const listener = { fn, onlisten };

    const sql = listen.sql || (listen.sql = Postgres({
      ...options,
      max: 1,
      idle_timeout: null,
      max_lifetime: null,
      fetch_types: false,
      onclose() {
        Object.entries(listen.channels).forEach(([name, { listeners }]) => {
          delete listen.channels[name];
          Promise.all(listeners.map(l => listen(name, l.fn, l.onlisten).catch(() => { /* noop */ })));
        });
      },
      onnotify(c, x) {
        c in listen.channels && listen.channels[c].listeners.forEach(l => l.fn(x));
      }
    }));

    const channels = listen.channels || (listen.channels = {})
        , exists = name in channels;

    if (exists) {
      channels[name].listeners.push(listener);
      const result = await channels[name].result;
      listener.onlisten && listener.onlisten();
      return { state: result.state, unlisten }
    }

    channels[name] = { result: sql`listen ${
      sql.unsafe('"' + name.replace(/"/g, '""') + '"')
    }`, listeners: [listener] };
    const result = await channels[name].result;
    listener.onlisten && listener.onlisten();
    return { state: result.state, unlisten }

    async function unlisten() {
      if (name in channels === false)
        return

      channels[name].listeners = channels[name].listeners.filter(x => x !== listener);
      if (channels[name].listeners.length)
        return

      delete channels[name];
      return sql`unlisten ${
        sql.unsafe('"' + name.replace(/"/g, '""') + '"')
      }`
    }
  }

  async function notify(channel, payload) {
    return await sql`select pg_notify(${ channel }, ${ '' + payload })`
  }

  async function reserve() {
    const queue = Queue();
    const c = open.length
      ? open.shift()
      : await new Promise(r => {
        queries.push({ reserve: r });
        closed.length && connect(closed.shift());
      });

    move(c, reserved);
    c.reserved = () => queue.length
      ? c.execute(queue.shift())
      : move(c, reserved);
    c.reserved.release = true;

    const sql = Sql(handler);
    sql.release = () => {
      c.reserved = null;
      onopen(c);
    };

    return sql

    function handler(q) {
      c.queue === full
        ? queue.push(q)
        : c.execute(q) || move(c, full);
    }
  }

  async function begin(options, fn) {
    !fn && (fn = options, options = '');
    const queries = Queue();
    let savepoints = 0
      , connection
      , prepare = null;

    try {
      await sql.unsafe('begin ' + options.replace(/[^a-z ]/ig, ''), [], { onexecute }).execute();
      return await Promise.race([
        scope(connection, fn),
        new Promise((_, reject) => connection.onclose = reject)
      ])
    } catch (error) {
      throw error
    }

    async function scope(c, fn, name) {
      const sql = Sql(handler);
      sql.savepoint = savepoint;
      sql.prepare = x => prepare = x.replace(/[^a-z0-9$-_. ]/gi);
      let uncaughtError
        , result;

      name && await sql`savepoint ${ sql(name) }`;
      try {
        result = await new Promise((resolve, reject) => {
          const x = fn(sql);
          Promise.resolve(Array.isArray(x) ? Promise.all(x) : x).then(resolve, reject);
        });

        if (uncaughtError)
          throw uncaughtError
      } catch (e) {
        await (name
          ? sql`rollback to ${ sql(name) }`
          : sql`rollback`
        );
        throw e instanceof PostgresError && e.code === '25P02' && uncaughtError || e
      }

      if (!name) {
        prepare
          ? await sql`prepare transaction '${ sql.unsafe(prepare) }'`
          : await sql`commit`;
      }

      return result

      function savepoint(name, fn) {
        if (name && Array.isArray(name.raw))
          return savepoint(sql => sql.apply(sql, arguments))

        arguments.length === 1 && (fn = name, name = null);
        return scope(c, fn, 's' + savepoints++ + (name ? '_' + name : ''))
      }

      function handler(q) {
        q.catch(e => uncaughtError || (uncaughtError = e));
        c.queue === full
          ? queries.push(q)
          : c.execute(q) || move(c, full);
      }
    }

    function onexecute(c) {
      connection = c;
      move(c, reserved);
      c.reserved = () => queries.length
        ? c.execute(queries.shift())
        : move(c, reserved);
    }
  }

  function move(c, queue) {
    c.queue.remove(c);
    queue.push(c);
    c.queue = queue;
    queue === open
      ? c.idleTimer.start()
      : c.idleTimer.cancel();
    return c
  }

  function json(x) {
    return new Parameter(x, 3802)
  }

  function array(x, type) {
    if (!Array.isArray(x))
      return array(Array.from(arguments))

    return new Parameter(x, type || (x.length ? inferType(x) || 25 : 0), options.shared.typeArrayMap)
  }

  function handler(query) {
    if (ending)
      return query.reject(Errors.connection('CONNECTION_ENDED', options, options))

    if (open.length)
      return go(open.shift(), query)

    if (closed.length)
      return connect(closed.shift(), query)

    busy.length
      ? go(busy.shift(), query)
      : queries.push(query);
  }

  function go(c, query) {
    return c.execute(query)
      ? move(c, busy)
      : move(c, full)
  }

  function cancel(query) {
    return new Promise((resolve, reject) => {
      query.state
        ? query.active
          ? Connection(options).cancel(query.state, resolve, reject)
          : query.cancelled = { resolve, reject }
        : (
          queries.remove(query),
          query.cancelled = true,
          query.reject(Errors.generic('57014', 'canceling statement due to user request')),
          resolve()
        );
    })
  }

  async function end({ timeout = null } = {}) {
    if (ending)
      return ending

    await 1;
    let timer;
    return ending = Promise.race([
      new Promise(r => timeout !== null && (timer = setTimeout(destroy, timeout * 1000, r))),
      Promise.all(connections.map(c => c.end()).concat(
        listen.sql ? listen.sql.end({ timeout: 0 }) : [],
        subscribe.sql ? subscribe.sql.end({ timeout: 0 }) : []
      ))
    ]).then(() => clearTimeout(timer))
  }

  async function close() {
    await Promise.all(connections.map(c => c.end()));
  }

  async function destroy(resolve) {
    await Promise.all(connections.map(c => c.terminate()));
    while (queries.length)
      queries.shift().reject(Errors.connection('CONNECTION_DESTROYED', options));
    resolve();
  }

  function connect(c, query) {
    move(c, connecting);
    c.connect(query);
    return c
  }

  function onend(c) {
    move(c, ended);
  }

  function onopen(c) {
    if (queries.length === 0)
      return move(c, open)

    let max = Math.ceil(queries.length / (connecting.length + 1))
      , ready = true;

    while (ready && queries.length && max-- > 0) {
      const query = queries.shift();
      if (query.reserve)
        return query.reserve(c)

      ready = c.execute(query);
    }

    ready
      ? move(c, busy)
      : move(c, full);
  }

  function onclose(c, e) {
    move(c, closed);
    c.reserved = null;
    c.onclose && (c.onclose(e), c.onclose = null);
    options.onclose && options.onclose(c.id);
    queries.length && connect(c, queries.shift());
  }
}

function parseOptions(a, b) {
  if (a && a.shared)
    return a

  const env = process.env // eslint-disable-line
      , o = (!a || typeof a === 'string' ? b : a) || {}
      , { url, multihost } = parseUrl(a)
      , query = [...url.searchParams].reduce((a, [b, c]) => (a[b] = c, a), {})
      , host = o.hostname || o.host || multihost || url.hostname || env.PGHOST || 'localhost'
      , port = o.port || url.port || env.PGPORT || 5432
      , user = o.user || o.username || url.username || env.PGUSERNAME || env.PGUSER || osUsername();

  o.no_prepare && (o.prepare = false);
  query.sslmode && (query.ssl = query.sslmode, delete query.sslmode);
  'timeout' in o && (console.log('The timeout option is deprecated, use idle_timeout instead'), o.idle_timeout = o.timeout); // eslint-disable-line
  query.sslrootcert === 'system' && (query.ssl = 'verify-full');

  const ints = ['idle_timeout', 'connect_timeout', 'max_lifetime', 'max_pipeline', 'backoff', 'keep_alive'];
  const defaults = {
    max             : 10,
    ssl             : false,
    idle_timeout    : null,
    connect_timeout : 30,
    max_lifetime    : max_lifetime,
    max_pipeline    : 100,
    backoff         : backoff,
    keep_alive      : 60,
    prepare         : true,
    debug           : false,
    fetch_types     : true,
    publications    : 'alltables',
    target_session_attrs: null
  };

  return {
    host            : Array.isArray(host) ? host : host.split(',').map(x => x.split(':')[0]),
    port            : Array.isArray(port) ? port : host.split(',').map(x => parseInt(x.split(':')[1] || port)),
    path            : o.path || host.indexOf('/') > -1 && host + '/.s.PGSQL.' + port,
    database        : o.database || o.db || (url.pathname || '').slice(1) || env.PGDATABASE || user,
    user            : user,
    pass            : o.pass || o.password || url.password || env.PGPASSWORD || '',
    ...Object.entries(defaults).reduce(
      (acc, [k, d]) => {
        const value = k in o ? o[k] : k in query
          ? (query[k] === 'disable' || query[k] === 'false' ? false : query[k])
          : env['PG' + k.toUpperCase()] || d;
        acc[k] = typeof value === 'string' && ints.includes(k)
          ? +value
          : value;
        return acc
      },
      {}
    ),
    connection      : {
      application_name: 'postgres.js',
      ...o.connection,
      ...Object.entries(query).reduce((acc, [k, v]) => (k in defaults || (acc[k] = v), acc), {})
    },
    types           : o.types || {},
    target_session_attrs: tsa(o, url, env),
    onnotice        : o.onnotice,
    onnotify        : o.onnotify,
    onclose         : o.onclose,
    onparameter     : o.onparameter,
    socket          : o.socket,
    transform       : parseTransform(o.transform || { undefined: undefined }),
    parameters      : {},
    shared          : { retries: 0, typeArrayMap: {} },
    ...mergeUserTypes(o.types)
  }
}

function tsa(o, url, env) {
  const x = o.target_session_attrs || url.searchParams.get('target_session_attrs') || env.PGTARGETSESSIONATTRS;
  if (!x || ['read-write', 'read-only', 'primary', 'standby', 'prefer-standby'].includes(x))
    return x

  throw new Error('target_session_attrs ' + x + ' is not supported')
}

function backoff(retries) {
  return (0.5 + Math.random() / 2) * Math.min(3 ** retries / 100, 20)
}

function max_lifetime() {
  return 60 * (30 + Math.random() * 30)
}

function parseTransform(x) {
  return {
    undefined: x.undefined,
    column: {
      from: typeof x.column === 'function' ? x.column : x.column && x.column.from,
      to: x.column && x.column.to
    },
    value: {
      from: typeof x.value === 'function' ? x.value : x.value && x.value.from,
      to: x.value && x.value.to
    },
    row: {
      from: typeof x.row === 'function' ? x.row : x.row && x.row.from,
      to: x.row && x.row.to
    }
  }
}

function parseUrl(url) {
  if (!url || typeof url !== 'string')
    return { url: { searchParams: new Map() } }

  let host = url;
  host = host.slice(host.indexOf('://') + 3).split(/[?/]/)[0];
  host = decodeURIComponent(host.slice(host.indexOf('@') + 1));

  const urlObj = new URL(url.replace(host, host.split(',')[0]));

  return {
    url: {
      username: decodeURIComponent(urlObj.username),
      password: decodeURIComponent(urlObj.password),
      host: urlObj.host,
      hostname: urlObj.hostname,
      port: urlObj.port,
      pathname: urlObj.pathname,
      searchParams: urlObj.searchParams
    },
    multihost: host.indexOf(',') > -1 && host
  }
}

function osUsername() {
  try {
    return os.userInfo().username // eslint-disable-line
  } catch (_) {
    return process.env.USERNAME || process.env.USER || process.env.LOGNAME  // eslint-disable-line
  }
}

const MQInvocationEvent = z.object({
  rmqMessagesByQueue: z.object({
    "task_invocations::/": z.array(
      z.object({
        data: z.string()
      })
    )
  })
});
const MQTaskContext = z.object({
  id: z.string(),
  // invocation id
  task_id: z.string(),
  // this will be handler_0, handler_1, etc.
  args: z.any(),
  // args passed to task
  state: z.record(z.string(), z.any()),
  // TODO: change name to state
  continuation: z.nullable(z.string()),
  // deprecated
  continuation_args: z.array(z.any())
  // deprecated
});
const MQ_HOST = process.env.MQ_HOST || "b-33245d09-61e4-4119-84ae-13dcdd945031.mq.eu-west-2.amazonaws.com";
const MQ_PORT = process.env.MQ_PORT || "5671";
const MQ_USER = process.env.MQ_USER || "admin";
const MQ_PASS = process.env.MQ_PASS || "ishouldmakethissecure";
const rabbit = new lib.Connection(
  `amqps://${MQ_USER}:${MQ_PASS}@${MQ_HOST}:${MQ_PORT}`
);
function onRabbitConnError(err) {
  console.log("RabbitMQ connection error", err);
}
function onRabbitConnOpen() {
  console.log("Connection successfully (re)established");
}
rabbit.on("error", onRabbitConnError);
rabbit.on("connection", onRabbitConnOpen);
const pub = rabbit.createPublisher({
  confirm: true,
  maxAttempts: 2
});
async function entrypoint(event, ctx) {
  try {
    const mqInvocEvent = MQInvocationEvent.parse(event);
    const { rmqMessagesByQueue } = mqInvocEvent;
    const { "task_invocations::/": msgs } = rmqMessagesByQueue;
    const mqTaskCtxs = msgs.map((msg) => msg.data).map(atob).map((str) => JSON.parse(str)).map((json) => MQTaskContext.parse(json)).map(handle);
    await Promise.all(mqTaskCtxs);
    return "processed";
  } catch (err) {
    console.error("Invalid event", err);
    throw new Error("Invalid event schema");
  }
}
function continuation(taskId, taskArgs, taskScope) {
  return {
    status: "continuation",
    taskId,
    taskArgs,
    taskScope
  };
}
function result(data) {
  return {
    status: "done",
    data
  };
}
const handlers = {
  handler_0,
  handler_1
};
async function handle(mqTaskCtx) {
  console.log("Responding to invocation", mqTaskCtx.id);
  const taskId = mqTaskCtx.task_id;
  const handler = handlers[taskId];
  try {
    if (handler) {
      const res = await handler(
        { id: mqTaskCtx.id, data: mqTaskCtx.args ?? {} },
        mqTaskCtx.state
      );
      if (res.status == "done") {
        await invokeResponse(mqTaskCtx, res.data);
      } else {
        await invokeContinuation(
          mqTaskCtx,
          res.taskId,
          res.taskArgs,
          res.taskScope
        );
      }
    } else {
      throw new Error("Unknown handler");
    }
  } catch (err) {
    if (err instanceof Error) {
      await invokeError(mqTaskCtx, err);
    } else {
      await invokeError(mqTaskCtx, new Error("Unknown error"));
    }
  }
}
async function invokeResponse(mqTaskCtx, data) {
  const exchange = "amq.direct";
  const routingKey = `mq.gateway.invocations.${mqTaskCtx.id}`;
  const publishStart = performance.now();
  await pub.send({ exchange, routingKey }, data);
  const publishEnd = performance.now();
  console.log("Publish response took", publishEnd - publishStart, "ms");
}
async function invokeContinuation(mqTaskCtx, taskId, taskArgs, taskScope) {
  const exchange = "amq.direct";
  const routingKey = `mq.invocations.${taskId}`;
  const mqContinuationTaskCtx = {
    id: mqTaskCtx.id,
    task_id: taskId,
    args: taskArgs,
    continuation: null,
    continuation_args: [],
    state: taskScope
  };
  const publishStart = performance.now();
  await pub.send({ exchange, routingKey }, mqContinuationTaskCtx);
  const publishEnd = performance.now();
  console.log("Publish continuation took", publishEnd - publishStart, "ms");
}
async function invokeError(mqTaskCtx, err) {
  const exchange = "amq.direct";
  const routingKey = `mq.gateway.invocations.${mqTaskCtx.id}`;
  const publishStart = performance.now();
  await pub.send({ exchange, routingKey }, err.toString());
  const publishEnd = performance.now();
  console.log("Publish err response took", publishEnd - publishStart, "ms");
}
async function onShutdown() {
  await pub.close();
  await rabbit.close();
}
process.on("SIGINT", onShutdown);
process.on("SIGTERM", onShutdown);
z.object({
  id: z.string(),
  data: z.string()
});
const sql = Postgres({
  host: "postgres-db.cno4eviwxzxv.eu-west-2.rds.amazonaws.com",
  port: 5432,
  username: "faaasuser",
  password: "securepassword",
  database: "postgres",
  ssl: { rejectUnauthorized: false }
});
async function handler_0(ctx, _) {
  const name = ctx.data;
  console.log("Invoking first part with", name);
  const queryStart = performance.now();
  const data = await sql`SELECT * FROM pets`;
  const dataStr = data.toString();
  const queryEnd = performance.now();
  console.log("Query took", queryEnd - queryStart, "ms");
  console.log("Query returned", dataStr);
  return continuation(
    "proxy.sql.pg",
    ["handler", "handler_1", "SELECT * FROM pets"],
    {}
  );
}
async function handler_1(ctx, state) {
  const res = JSON.parse(ctx.data);
  console.log("data", res);
  console.log("state", state);
  return result(res);
}

export { entrypoint };
